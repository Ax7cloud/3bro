<div class="layout-content">
    <div class="layout-content-body">        
        <div class="panel">
            <div class="panel-body container-fluid">
                <div class="row row-lg">
                    <div class="page-not-found">
                        <h1>404</h1>
                        <h2>Page Not Found</h2>
                        <h5>We are sorry</h5>
                        <h5>the page you requested cannot be found or you don't have permission to view this page</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<style type="text/css">
.page-not-found{margin-top: 7%;min-height: 300px;text-align: center;}
.page-not-found h2 {color: #0000ff;margin-bottom: 25px;}
.page-not-found h1 {font-family: "Comic Sans MS",cursive,sans-serif;font-size: 75px;font-style: italic;color: #ff0000;}
.page-not-found > h5 {margin-left: 35%;width: 30%;color: #858585;}
@media (max-width: 770px){
    .page-not-found > h5 {margin-left: 0;width: 100%;}
}
</style>