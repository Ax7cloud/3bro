<div class="layout-content">
    <div class="layout-content-body">
        <div class="title-bar">
            <h1 class="title-bar-title">
                <span class="d-ib">Contact US Request</span>
            </h1>
        </div>
        <div class="panel">
            <div class="panel-body container-fluid">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <th>#</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone Number</th>
                                <th>Website</th>
                                <th>Time</th>
                                <th>Action</th>
                            </thead>
                            <tbody>
                                <?php
                                $i = $this->page_record;
                                foreach($record as $rec){
                                    echo '<tr id="contact-us-'.$rec->contactUsId.'" class="'.($rec->status == '0' ? 'info' : '').'">';
                                        echo '<td>'.++$i.'</td>';
                                        echo '<td>'.$rec->fromName.'</br><small>'.$rec->ipAddress.'</small></td>';
                                        echo '<td><a href="mailto:'.$cus->fromEmail.'?subject=Rep: '.substr(strip_tags($rec->description),0,100).'">'.$rec->fromEmail.'</a></td>';
                                        echo '<td>'.$rec->phoneNumber.'</td>';
                                        echo '<td>'.$rec->website.'</td>';
                                        echo '<td>'.$rec->createdTime.'</td>';
                                        echo '<td>';
                                            echo '<a href="'.base_url(ADMIN_PATH.'/contact-us/'.$rec->contactUsId).'"><i class="icon icon-eye"></i></a>';
                                            echo '&nbsp;&nbsp;&nbsp;';
                                            echo '<a href="javascript:;" onclick="deleteContactUS('.$rec->contactUsId.')"><i class="icon icon-trash"></i></a>';
                                        echo '</td>';
                                    echo '</tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<style type="text/css">
</style>
<script type="text/javascript">
$(document).ready(function(){
});
function deleteContactUS(contactUsId){
    swal({
        type: 'warning',
        title: 'Are you sure to delete this?',
        text: '',
        showConfirmButton: true,
        showCancelButton: true,
        confirmButtonText: 'Delete',
        confirmButtonColor: '#CD0000'
    },function(){
        $.ajax({
            type: 'post',
            data: {contactUsId: contactUsId},
            url: '<?= base_url('adminPanel/deleteContactUS') ?>',
            success: function(response){
                if($.trim(response) != 'success'){
                    toastr.error(response,'',{timeOut: 5000, positionClass: 'toast-top-center'});
                }else{
                    toastr.success('Action performed successfully','',{timeOut: 5000, positionClass: 'toast-top-center'});
                    $('#contact-us-'+contactUsId).remove();
                }
            },
            error: function(err){
                toastr.error('Unable to process your request','',{timeOut: 5000, positionClass: 'toast-top-center'});
            }
        })
    });
}
</script>