<div class="layout-content">
    <div class="layout-content-body">
        <div class="title-bar">
            <h1 class="title-bar-title">
                <span class="d-ib">CMS</span>
                <a href="<?= base_url(ADMIN_PATH.'/cms/add') ?>" class="btn btn-primary pull-right">Add Page</a>
            </h1>
        </div>
        <div class="panel">
            <div class="panel-body container-fluid">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <th>#</th>
                                <th>Title</th>
                                <th>Slug</th>
                                <th>Created Time</th>
                                <th>Status</th>
                                <th>Action</th>
                            </thead>
                            <tbody>
                                <?php
                                $i = $this->page_record;
                                foreach($record as $rec){
                                    $sStatus = $rec->status == 'Active' ? 'success' : 'danger';
                                    echo '<tr id="page-'.$rec->pageId.'">';
                                        echo '<td>'.++$i.'</td>';
                                        echo '<td>'.$rec->pageTitle.'</td>';
                                        echo '<td>'.($rec->pageType == '1' ? '<a href="'.base_url($rec->slugUrl).'" target="_blank">'.$rec->slugUrl.'</a>' : 'N/A').'</td>';
                                        echo '<td>'.$rec->createdTime.'</td>';
                                        echo '<td><label class="label label-'.$sStatus.'">'.$rec->status.'</label></td>';
                                        echo '<td>';
                                            echo '<a href="'.base_url(ADMIN_PATH.'/cms/edit/'.$rec->pageId).'"><i class="icon icon-pencil"></i></a>&nbsp;&nbsp;';
                                            if($rec->pageType == '1'){
                                                echo '<a href="javascript:;" onclick="deletePage('.$rec->pageId.')"><i class="icon icon-trash"></i></a>';
                                            }
                                        echo '</td>';
                                    echo '</tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<style type="text/css">
.feature-col {margin-bottom: 10px;}
.feature-col .input-group-addon {min-width: 170px;text-align: left;}
.switch.switch-primary {margin-top: 8px;}
</style>
<script type="text/javascript">
function deletePage(pageId){
    swal({
        type: 'warning',
        title: 'Are you sure to delete this?',
        text: '',
        showConfirmButton: true,
        showCancelButton: true,
        confirmButtonText: 'Delete',
        confirmButtonColor: '#CD0000'
    },function(){
        $.ajax({
            type: 'post',
            data: {pageId: pageId},
            url: '<?= base_url('adminPanel/deletePage') ?>',
            success: function(response){
                if($.trim(response) != 'success'){
                    toastr.error(response,'',{timeOut: 5000, positionClass: 'toast-top-center'});
                }else{
                    toastr.success('Action performed successfully','',{timeOut: 5000, positionClass: 'toast-top-center'});
                    $('#page-'+pageId).remove();
                }
            },
            error: function(err){
                toastr.error('Unable to process your request','',{timeOut: 5000, positionClass: 'toast-top-center'});
            }
        })
    });
}
</script>