<?php
$post_link = postUrl(getPost($comment->postId));
?>
<div class="layout-content">
    <div class="layout-content-body">
        <div class="title-bar">
            <h1 class="title-bar-title">
                <span class="d-ib">Comment Threads</span>
                <button class="btn btn-info pull-right" onclick="replyComment(<?= $comment->commentId ?>)">Add Comment</button>
                <a href="<?= base_url(ADMIN_PATH.'/comments') ?>" style="margin-right: 10px;" class="btn btn-default pull-right">Back</a>
            </h1>
        </div>
        <div class="panel">
            <div class="panel-body container-fluid">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <th width="20%">Post</th>
                                <th width="80%"><a href="<?= $post_link ?>#comments" target="_blank"><?= $comment->postTitle ?></a></th>
                            </thead>
                            <thead>
                                <th colspan="2"><h3 style="margin-top: 5px;margin-bottom: 5px;">Comments</h3></th>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="2">
                                        <?php
                                        echo '<b>Name</b> : '.$comment->fromName.'<br>';
                                        echo '<b>Email</b> : '.$comment->fromEmail.'<br>';
                                        echo '<b>IP Address</b> : '.$comment->ipAddress.'<br>';
                                        echo '<b>Time</b> : '.$comment->commentTime.'<hr style="margin-top: 5px;margin-bottom: 5px;">';
                                        echo $comment->comment;
                                        ?>
                                    </td>
                                </tr>
                                <?php
                                foreach($commentrecord as $srec){
                                    echo '<tr id="comment-'.$srec->commentId.'">';
                                        echo '<td colspan="2">';
                                            if($srec->userId != '0'){
                                                echo '<b>Name</b> : '.userName($srec->userId).'<br>';
                                            }else{
                                                echo '<b>Name</b> : '.$srec->fromName.'<br>';
                                                echo '<b>Email</b> : '.$srec->fromEmail.'<br>';
                                                echo '<b>IP Address</b> : '.$srec->ipAddress.'<br>';
                                            }
                                            echo '<b>Time</b> : '.$srec->commentTime.'<a href="javascript:;" class="pull-right" onclick="deleteComment('.$srec->commentId.')"><i class="icon icon-trash"></i></a><hr style="margin-top: 5px;margin-bottom: 5px;">';
                                            echo $srec->comment;
                                        echo '</td>';
                                    echo '</tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" tabindex="-1" role="dialog" id="comment-modal" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title">Comment</h4>
            </div>
            <form action="" class="comment-form" method="post">
                <div class="modal-body">
                    <input type="hidden" name="commentId" value="">
                    <div class="form-group">
                        <textarea name="comment" cols="30" rows="10" class="form-control" required=""></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
<style type="text/css">
</style>
<script type="text/javascript">
$(document).ready(function(){
});
function replyComment(commentId){
    $('.comment-form input[name="commentId"]').val(commentId);
    $('.comment-form textarea[name="comment"]').val('');
    $('#comment-modal').modal();
}
$('.comment-form').submit(function(e){
    var btnObj = $(this).find('button[type="submit"]');
    btnObj.addClass('spinner spinner-inverse').prop('disabled',true);

    $.ajax({
        type: 'post',
        data: $(this).serialize(),
        url: '<?= base_url('adminPanel/postComment') ?>',
        success: function(response){
            btnObj.removeClass('spinner spinner-inverse').prop('disabled',false);
            if($.trim(response) != 'success'){
                toastr.error(response,'',{timeOut: 5000, positionClass: 'toast-top-center'});
            }else{
                toastr.success('Action performed successfully','',{timeOut: 5000, positionClass: 'toast-top-center'});
            }
            window.location.reload();
        },
        error: function(err){
            btnObj.removeClass('spinner spinner-inverse').prop('disabled',false);
        }
    })
    e.preventDefault();
});
function deleteComment(commentId){
    swal({
        type: 'warning',
        title: 'Are you sure to delete this comment?',
        text: '',
        showConfirmButton: true,
        showCancelButton: true,
        confirmButtonText: 'Delete',
        confirmButtonColor: '#CD0000'
    },function(){
        $.ajax({
            type: 'post',
            data: {commentId: commentId},
            url: '<?= base_url('adminPanel/deleteComment') ?>',
            success: function(response){
                if($.trim(response) != 'success'){
                    toastr.error(response,'',{timeOut: 5000, positionClass: 'toast-top-center'});
                }else{
                    toastr.success('Action performed successfully','',{timeOut: 5000, positionClass: 'toast-top-center'});
                    $('#comment-'+commentId).remove();
                }
            },
            error: function(err){
                toastr.error('Unable to process your request','',{timeOut: 5000, positionClass: 'toast-top-center'});
            }
        })
    });
}
</script>