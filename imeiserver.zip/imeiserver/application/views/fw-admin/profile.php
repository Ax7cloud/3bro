<div class="layout-content">
    <div class="layout-content-body">
        <div class="title-bar">
            <h1 class="title-bar-title">
                <span class="d-ib">Profile</span>
            </h1>
        </div>
        <div class="panel">
            <div class="panel-body container-fluid">
                <div class="row row-lg">
                    <div class="col-md-12">
                        <form method="post" class="form-horizontal profile-form" enctype="multipart/form-data">
                            <input type="hidden" name="save" value="yes">
                        	<div class="form-group">
                        		<label class="control-label col-md-3 text-right">Name <span class="is-req">*</span></label>
                        		<div class="col-md-6">
                        			<input type="text" class="form-control" name="name" value="<?= $uuser->name ?>">
                        		</div>
                        	</div>
							<div class="form-group">
                        		<label class="control-label col-md-3 text-right">Phone Number <span class="is-req">*</span></label>
                        		<div class="col-md-6">
                        			<input type="text" class="form-control" name="phoneNumber" value="<?= $uuser->phoneNumber ?>" onkeypress="return isNumber(event)">
                        		</div>
                        	</div>
                        	<div class="form-group">
                        		<label class="control-label col-md-3 text-right">Email</label>
                        		<div class="col-md-6">
                        			<input type="email" class="form-control" name="email" value="<?= $uuser->email ?>" data-inputmask="'alias': 'email'">
                        		</div>
                        	</div>
                            <div class="form-group">
                                <label class="control-label col-md-3 text-right">Username <span class="is-req">*</span></label>
                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="username" value="<?= $uuser->username ?>" maxlength="10" readonly="">
                                </div>
                            </div>
                        	<div class="form-group">
                        		<label class="control-label col-md-3 text-right">Password</label>
                        		<div class="col-md-6">
                        			<input type="password" class="form-control" name="password" placeholder="******">
                        		</div>
                        	</div>
                        	<div class="form-group">
                        		<label class="control-label col-md-3 text-right">&nbsp;</label>
                        		<div class="col-md-6">
                        			<button class="btn btn-block btn-primary do-save">Save</button>
                        		</div>
                        	</div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
$(document).ready(function(){
    $('[data-inputmask]').inputmask();
});
//profile-form
$("form.profile-form").submit(function(e){
    var btnOnj = $('.profile-form .do-save');
    btnOnj.addClass('spinner spinner-inverse').prop('disabled',true);

    $.ajax({
        url: window.location.href,
        type: 'POST',
        data: $('.profile-form').serialize(),
        success: function(response) {
            if(response != '1'){
                toastr.error(response,'',{timeOut: 5000, positionClass: 'toast-top-center'});
            }else{
                toastr.success('Action perfrom successfully.','',{timeOut: 5000, positionClass: 'toast-top-center'});
                window.location.reload();
            }
            btnOnj.removeClass('spinner spinner-inverse').prop('disabled',false);
        },
        error: function(err){
            toastr.error('Unable to process your request','',{timeOut: 5000, positionClass: 'toast-top-center'});
            btnOnj.removeClass('spinner spinner-inverse').prop('disabled',false);
        }
    });
    e.preventDefault();
});
function isNumber(e){
    var numberArr = [8,48,49,50,51,52,53,54,55,56,57];
    if($.inArray(e.which,numberArr) != '-1'){
        return true;
    }else{
        return false;
    }
}
</script>