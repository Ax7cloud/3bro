<?php
$actionType = $this->uri->segment(3);
?>
<div class="layout-content">
    <div class="layout-content-body">
        <div class="title-bar">
            <h1 class="title-bar-title">
                <span class="d-ib"><?= ucfirst($actionType) ?> Post</span>
                <a href="<?= base_url(ADMIN_PATH.'/posts') ?>" class="btn btn-default pull-right">Back</a>
            </h1>
        </div>
        <div class="panel">
            <div class="panel-body container-fluid">
                <div class="row row-lg">
                    <div class="col-md-12">
                        <form method="post" class="form-horizontal post-form">
                            <input type="hidden" name="postId" value="<?= $post->postId ?>">
                            <input type="hidden" name="postSlug" value="<?= $post->postSlug ?>">
                            <textarea name="template" class="template" style="display: none;"></textarea>
                        	<div class="form-group">
                        		<label class="control-label col-md-2 text-right">Title</label>
                        		<div class="col-md-6">
                        			<input type="text" class="form-control post-title" name="title" value="<?= $post->postTitle ?>" onchange="updateSlug()">
                                    <p class="help-block post-permalink"><?= $post->postSlug != '' ? base_url($post->postSlug).'<a href="javascript:;" class="pull-right" onclick="changeSlug(this)"><b>Edit</b></a>' : '' ?></p>
                        		</div>
                        	</div>
                            <div class="form-group">
                                <label class="control-label col-md-2 text-right">Categories</label>
                                <div class="col-md-8">
                                    <select class="form-control select-tags" name="category[]" multiple="">
                                        <?php
                                        $post_categories = @json_decode($post->category,true);
                                        foreach($getCategoreis as $category){
                                            $sel = in_array($category, $post_categories) ? 'selected=""' : '';
                                            echo '<option value="'.$category.'" '.$sel.'>'.$category.'</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-2 text-right">Tags</label>
                                <div class="col-md-8">
                                    <select class="form-control select-tags" name="tags[]" multiple="">
                                        <?php
                                        $post_tags = @json_decode($post->tags,true);
                                        foreach($getTags as $tag){
                                            $sel = in_array($tag, $post_tags) ? 'selected=""' : '';
                                            echo '<option value="'.$tag.'" '.$sel.'>'.$tag.'</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                        	<div class="form-group">
                        		<label class="control-label col-md-2 text-right">Post Content</label>
                        		<div class="col-md-10">
                        			<textarea name="content" id="ckedit" cols="30" rows="10"><?= $post->postContent ?></textarea>
                        		</div>
                        	</div>
                            <div class="form-group">
                                <label class="control-label col-md-2 text-right">&nbsp;</label>
                                <div class="col-md-3">
                                    <label>Version</label>
                                    <input type="text" class="form-control" name="version" value="<?= $post->version ?>">
                                </div>
                                <div class="col-md-3">
                                    <label>OS</label>
                                    <input type="text" class="form-control" name="os" value="<?= $post->os ?>">
                                </div>
                                <div class="col-md-2">
                                    <label>BIT (BINARY/U)</label>
                                    <input type="text" class="form-control" name="bit" value="<?= $post->bit ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-2 text-right">&nbsp;</label>
                                <div class="col-md-3">
                                    <label>Device</label>
                                    <input type="text" class="form-control" name="device" value="<?= $post->device ?>">
                                </div>
                                <div class="col-md-3">
                                    <label>Model</label>
                                    <input type="text" class="form-control" name="model" value="<?= $post->model ?>">
                                    <p class="help-block">
                                        <label class="custom-control custom-control-primary custom-checkbox">
                                            <input name="isRecentModel" class="custom-control-input" type="checkbox" value="Yes" <?= $post->isRecentModel == 'Yes' ? 'checked=""' : '' ?>>
                                            <span class="custom-control-indicator"></span>
                                            <span class="custom-control-label">Is Recent Model?</span>
                                        </label>
                                    </p>
                                </div>
                                <div class="col-md-2">
                                    <label>File Type</label>
                                    <input type="text" class="form-control" name="fileType" value="Firmware">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-2 text-right">&nbsp;</label>
                                <div class="col-md-3">
                                    <label>CSC Version</label>
                                    <input type="text" class="form-control" name="cscversion" value="<?= $post->cscversion ?>">
                                </div>
                                <div class="col-md-3">
                                    <label>Country</label>
                                    <select class="form-control select2-country-flag" name="country">
                                        <?php
                                        $defCountry = $post->country == '' || $post->country == undefined ? 'USA' : $post->country;
                                        foreach(worldCountries() as $cId => $pc){
                                            $sel = $cId == $defCountry ? 'selected=""' : '';
                                            echo '<option country-iso2="'.$pc['code'].'" value="'.$cId.'" '.$sel.'>'.$pc['name'].' ('.$pc['code'].')</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <label>CSC</label>
                                    <input type="text" class="form-control" name="csc" value="<?= $post->csc ?>">
                                </div>
                            </div>
                            <?php $downloadButton = @json_decode($post->downloadButton,true); ?>
                            <div class="form-group">
                                <label class="control-label col-md-2 text-right">Download Button</label>
                                <div class="col-md-4">
                                    <label>Button URL</label>
                                    <input type="text" name="buttonUrl" class="form-control" value="<?= $downloadButton['buttonUrl'] ?>" data-url="<?= $downloadButton['buttonUrl'] ?>">
                                </div>
                                <div class="col-md-4">
                                    <label>Button Text</label>
                                    <input type="text" name="buttonText" class="form-control" value="<?= $downloadButton['buttonText'] ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-2 text-right">Meta Title</label>
                                <div class="col-md-8">
                                    <input type="text" name="metaTitle" class="form-control" value="<?= $post->metaTitle ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-2 text-right">Meta Tags</label>
                                <div class="col-md-8">
                                    <select class="form-control select-tags" name="metaTags[]" multiple="">
                                        <?php
                                        $metaTags = @explode(',',$post->metaTags);
                                        if($post->metaTags != ''){
                                            foreach($metaTags as $tag){
                                                echo '<option value="'.$tag.'" selected="">'.$tag.'</option>';
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-2 text-right">Meta Description</label>
                                <div class="col-md-8">
                                    <textarea name="metaDesription" class="form-control" style="resize: vertical;"><?= $post->metaDesription ?></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-2 text-right">Comment</label>
                                <div class="col-md-6" style="margin-top: 6px;">
                                    <label class="custom-control custom-control-primary custom-radio">
                                        <input name="commentStatus" class="commentStatus custom-control-input" type="radio" value="Enabled" <?= $post->commentStatus != 'Disabled' ? 'checked=""' : '' ?>>
                                        <span class="custom-control-indicator"></span>
                                        <span class="custom-control-label">Enabled</span>
                                    </label>
                                    <label class="custom-control custom-control-primary custom-radio">
                                        <input name="commentStatus" class="commentStatus custom-control-input" type="radio" value="Disabled" <?= $post->commentStatus == 'Disabled' ? 'checked=""' : '' ?>>
                                        <span class="custom-control-indicator"></span>
                                        <span class="custom-control-label">Disabled</span>
                                    </label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-2 text-right">Status</label>
                                <div class="col-md-6" style="margin-top: 6px;">
                                    <label class="custom-control custom-control-primary custom-radio">
                                        <input name="postStatus" class="postStatus custom-control-input" type="radio" value="Active" <?= $post->postStatus != 'Inactive' ? 'checked=""' : '' ?>>
                                        <span class="custom-control-indicator"></span>
                                        <span class="custom-control-label">Active</span>
                                    </label>
                                    <label class="custom-control custom-control-primary custom-radio">
                                        <input name="postStatus" class="postStatus custom-control-input" type="radio" value="Inactive" <?= $post->postStatus == 'Inactive' ? 'checked=""' : '' ?>>
                                        <span class="custom-control-indicator"></span>
                                        <span class="custom-control-label">Inactive</span>
                                    </label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-2 text-right"></label>
                                <div class="col-md-10" style="margin-top: 6px;">
                                    <label class="custom-control custom-control-primary custom-checkbox">
                                        <input name="sharePost" class="custom-control-input" type="checkbox" value="Yes" <?= $post->sharePost == 'Yes' ? 'checked=""' : '' ?>>
                                        <span class="custom-control-indicator"></span>
                                        <span class="custom-control-label">Share on social media</span>
                                    </label>

                                    <label class="custom-control custom-control-primary custom-checkbox">
                                        <input name="featuredPost" class="custom-control-input" type="checkbox" value="Yes" <?= $post->featuredPost == 'Yes' ? 'checked=""' : '' ?>>
                                        <span class="custom-control-indicator"></span>
                                        <span class="custom-control-label">Is featured post?</span>
                                    </label>

                                    <label class="custom-control custom-control-primary custom-checkbox">
                                        <input name="separateAds" class="separateAds custom-control-input" type="checkbox" value="Yes" <?= $post->separateAds == 'Yes' ? 'checked=""' : '' ?> onclick="adsActive()">
                                        <span class="custom-control-indicator"></span>
                                        <span class="custom-control-label">Dedicated ads active?</span>
                                    </label>
                                </div>
                            </div>
                            <div class="form-group ads-div-seperate">
                                <label class="control-label col-md-2 text-right">Ads Content</label>
                                <div class="col-md-10">
                                    <textarea class="form-control" name="adsContent" rows="5" style="resize: vertical;"><?= $post->adsContent ?></textarea>
                                </div>
                            </div>
                        	<div class="form-group">
                        		<label class="control-label col-md-2 text-right">&nbsp;</label>
                        		<div class="col-md-12">
                        			<button class="btn btn-primary pull-right" type="submit">Save</button>
                        		</div>
                        	</div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<style type="text/css">
.link-change {padding: 2px;border-radius: 3px;border: 1px solid #ccc;}
</style>
<script type="text/javascript">
var actionType = '<?= $actionType ?>'
$(document).ready(function(){
    $('[data-inputmask]').inputmask();
    var veditor = CKEDITOR.replace('ckedit', {height: 600});
    adsActive();

    var b = $(".select2-country-flag");
    b.select2({
        templateResult: w,
        templateSelection: w,
        dir: "ltr"
    });
});
var isChanged = true;
window.onbeforeunload = function(){
    if(isChanged == true){
        return 'Are you sure you want to leave?';
    }
};
function w(b) {
    var c, d, e, f;
    if ((d = b.text) && !(c = b.id)) return d;
    //e = b.element.value.toLowerCase();
    e = b.element.value;
    e = $('.select2-country-flag option[value="'+e+'"]').attr('country-iso2').toLowerCase();
    //e = e.split('--')[0];
    f = "<?= base_url() ?>assets/img/flags/4x3/" + e + ".svg";
    var g = $("<span/>", {
        text: d
    });
    return $("<img>", {
        class: "img-flag",
        src: f
    }).prependTo(g), g
}
function adsActive(){
    if($('.post-form .separateAds').is(':checked')){
        $('.ads-div-seperate').show();
    }else{
        $('.ads-div-seperate').hide();
    }
}
function updateSlug(){
    var title = $('.post-title').val();
    var vslug = $('.post-form input[name="postSlug"]').val();
    if(vslug == '' || vslug == undefined){
        var slugUrl = getUrl(title);
        $('.post-form input[name="postSlug"]').val(slugUrl);
        var slugUpdate = '<a href="javascript:;" class="pull-right" onclick="changeSlug(this)"><b>Edit</b></a>';
        $('.post-permalink').html('<?= base_url() ?>'+slugUrl+slugUpdate);
    }
    // write code here
    title = $.trim(title.replace('Download Samsung',''));

    var splitTitle = title.split(' ');
    var vlength = splitTitle.length - 1;
    for(vlength; vlength >= 0; vlength--){
        if($.trim(splitTitle[vlength]) == '-'){
            splitTitle.splice(vlength, 1);
        }
    }
    var vlength = splitTitle.length - 1;
    var vt = 1;
    //Download Samsung Galaxy Note10+ 5G 256GB SM-N976V - VZW - N976VVRU7FUHA
    for(vlength; vlength >= 0; vlength--){
        if(vt == 1 && $('.post-form input[name="version"]').val() == ''){
            $('.post-form input[name="version"]').val(splitTitle[vlength]);
            splitTitle.splice(vlength, 1);
        }
        if(vt == 2 && $('.post-form input[name="csc"]').val() == ''){
            $('.post-form input[name="csc"]').val(splitTitle[vlength]);
            splitTitle.splice(vlength, 1);
        }
        if(vt == 3 && $('.post-form input[name="model"]').val() == ''){
            $('.post-form input[name="model"]').val(splitTitle[vlength]);
            splitTitle.splice(vlength, 1);
        }
        vt++;
    }
    $('.post-form input[name="device"]').val(splitTitle.join(' '));
}
function getUrl(link){
    return $.trim(link.toLowerCase().replace(/ /g,'-').replace(/_/g,'-').replace(/[^\w-]+/g,'')).replace(/--/g,'-');
}
function changeSlug(){
    var vslug = $('.post-form input[name="postSlug"]').val();
    var slugAction = '<a href="javascript:;" class="pull-right" onclick="cancelSlug(this)">Cancel</a>';
    slugAction += '<a href="javascript:;" class="pull-right" onclick="setSlug(this)"><b>Update</b>&nbsp;|&nbsp;</a>';
    $('.post-permalink').html('<?= base_url() ?>&nbsp;<input type="text" class="link-change" style="width:200px;" value="'+vslug+'">&nbsp;'+slugAction);
}
function setSlug(){
    var vslug = $('.post-form .link-change').val();
    if(vslug == ''){
        vslug = $('.post-form input[name="postSlug"]').val();
    }
    var slugUrl = getUrl(vslug);
    $('.post-form input[name="postSlug"]').val(slugUrl);
    var slugUpdate = '<a href="javascript:;" class="pull-right" onclick="changeSlug(this)"><b>Edit</b></a>';
    $('.post-permalink').html('<?= base_url() ?>'+slugUrl+slugUpdate);
}
function cancelSlug(){
    var slugUrl = $('.post-form input[name="postSlug"]').val();
    var slugUpdate = '<a href="javascript:;" class="pull-right" onclick="changeSlug(this)"><b>Edit</b></a>';
    $('.post-permalink').html('<?= base_url() ?>'+slugUrl+slugUpdate);

}
$('form.post-form').submit(function(e){
    var ckValue = CKEDITOR.instances['ckedit'].getData();
    $('.post-form .template').val(ckValue);

    $('.post-form button[type="submit"]').addClass('spinner spinner-inverse').prop('disabled',true);

    $.ajax({
        type: 'post',
        data: $('.post-form').serialize(),
        url: '<?= base_url('adminPanel/savePost') ?>',
        success: function(response){
            isChanged = false;
            $('.post-form button[type="submit"]').removeClass('spinner spinner-inverse').prop('disabled',false);
            if($.trim(response) != 'success'){
                toastr.error(response,'',{timeOut: 5000, positionClass: 'toast-top-center'});
            }else{
                toastr.success('Action performed successfully','',{timeOut: 5000, positionClass: 'toast-top-center'});
                window.location.href = '<?= base_url(ADMIN_PATH.'/posts') ?>';
            }
        },
        error: function(err){
            toastr.error('Unable to process your request','',{timeOut: 5000, positionClass: 'toast-top-center'});
            $('.post-form button[type="submit"]').removeClass('spinner spinner-inverse').prop('disabled',false);
        }
    })
    e.preventDefault();
});
</script>