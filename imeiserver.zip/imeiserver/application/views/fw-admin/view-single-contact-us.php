<div class="layout-content">
    <div class="layout-content-body">
        <div class="title-bar">
            <h1 class="title-bar-title">
                <span class="d-ib">Contact US Request</span>
                <a href="<?= base_url(ADMIN_PATH.'/contact-us') ?>" class="btn btn-default pull-right">Back</a>
            </h1>
        </div>
        <div class="panel">
            <div class="panel-body container-fluid">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <tbody>
                                <tr>
                                    <th>Name</th>
                                    <td><?= $cus->fromName ?></td>
                                    <th>Email</th>
                                    <td><a href="mailto:<?= $cus->fromEmail.'?subject=Rep: '.substr(strip_tags($cus->description),0,100) ?>"><?= $cus->fromEmail ?></a></td>
                                </tr>
                                <tr>
                                    <th>Phone Number</th>
                                    <td><?= $cus->phoneNumber ?></td>
                                    <th>Website</th>
                                    <td><a href="<?= $cus->website ?>" target="_blank"><?= $cus->website ?></a></td>
                                </tr>
                                <tr>
                                    <th>IP Address</th>
                                    <td><?= $cus->ipAddress ?></td>
                                    <th>Created Time</th>
                                    <td><?= $cus->createdTime ?></td>
                                </tr>
                                <tr>
                                    <th>Description</th>
                                    <td colspan="3"><?= $cus->description ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<style type="text/css">
</style>
<script type="text/javascript">
$(document).ready(function(){
});
</script>