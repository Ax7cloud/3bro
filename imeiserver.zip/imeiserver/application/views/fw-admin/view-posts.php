<?php
$postSearch = $this->session->userdata('postSearch');
?>
<div class="layout-content">
    <div class="layout-content-body">
        <div class="title-bar">
            <h1 class="title-bar-title">
                <span class="d-ib">Posts</span>
                <a href="<?= base_url(ADMIN_PATH.'/posts/add') ?>" class="btn btn-primary pull-right">Add Post</a>
            </h1>
        </div>
        <div class="panel">
            <div class="panel-body container-fluid">
                <form action="<?= base_url() ?>fw-admin/posts" class="search-form" method="post">
                    <div class="col-md-6">
                        <label>Search</label>
                        <input type="text" class="form-control" name="searchIn" value="<?= $postSearch['searchIn'] ?>">
                        <p class="help-block">Search in <b>title|model|device|version</b></p>
                    </div>
                    <div class="col-md-2">
                        <label>Type</label>
                        <select class="form-control select2" name="type">
                            <option value="">All</option>
                            <option value="Uploaded" <?= $postSearch['type'] == 'Uploaded' ? 'selected=""' : '' ?>>Uploaded</option>
                            <option value="Pending" <?= $postSearch['type'] == 'Pending' ? 'selected=""' : '' ?>>Pending</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label style="display: block;">&nbsp;</label>
                        <button class="btn btn-primary" type="submit">Search</button>
                        <?php
                        if($this->session->has_userdata('postSearch')){
                            echo '<a href="'.base_url().'fw-admin/posts?reset=true" class="btn btn-info">Reset</a>';
                        }
                        ?>
                    </div>
                </form>
            </div>
        </div>
        <div class="panel">
            <div class="panel-body container-fluid">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <th>#</th>
                                <th>Title</th>
                                <th>Model</th>
                                <th>Device</th>
                                <th title="Comments"><span class="icon icon-comment"></span></th>
                                <th title="Likes"><span class="icon icon-heart"></span></th>
                                <th title="Views"><span class="icon icon-eye"></span></th>
                                <th title="Downloads"><span class="icon icon-download"></span></th>
                                <th>Last Updated</th>
                                <th>Status</th>
                                <th>Action</th>
                            </thead>
                            <tbody>
                                <?php
                                $i = $this->page_record;
                                foreach($record as $rec){
                                    $sStatus = 'success';
                                    if($rec->postStatus == 'Inactive'){ $sStatus = 'danger'; }
                                    if($rec->postStatus == 'Draft'){ $sStatus = 'info'; }
                                    $categories = '';
                                    foreach(@json_decode($rec->category,true) as $cat){
                                        $categories .= '<label class="label label-primary" style="margin: 3px;">'.$cat.'</label>';
                                    }
                                    $tags = '';
                                    foreach(@json_decode($rec->tags,true) as $tag){
                                        $tags .= '<label class="label label-warning" style="margin: 3px;">'.$tag.'</label>';
                                    }
                                    $post_link = base_url($rec->postSlug);
                                    echo '<tr id="post-'.$rec->postId.'">';
                                        echo '<td>'.++$i.'</td>';
                                        echo '<td><a href="'.$post_link.'" target="_blank">'.$rec->postTitle.'</a></td>';
                                        echo '<td>'.$rec->model.'</td>';
                                        echo '<td>'.$rec->device.'</td>';
                                        echo '<td>'.$rec->commentCount.'</td>';
                                        echo '<td>'.$rec->likesCount.'</td>';
                                        echo '<td>'.$rec->viewsCount.'</td>';
                                        echo '<td>'.$rec->downloadCount.'</td>';
                                        echo '<td>'.$rec->modifiedTime.'</td>';
                                        echo '<td><label class="label label-'.$sStatus.'">'.$rec->postStatus.'</label></td>';
                                        echo '<td>';
                                            echo '<a href="'.base_url(ADMIN_PATH.'/posts/edit/'.$rec->postId).'"><i class="icon icon-pencil"></i></a>';
                                            echo '&nbsp;&nbsp;&nbsp;';
                                            echo '<a href="javascript:;" onclick="deletePost('.$rec->postId.')"><i class="icon icon-trash"></i></a>';

                                        echo '</td>';
                                    echo '</tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                        <?= '<ul class="pagination pull-right">'.$this->pagination->create_links().'</ul>'; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<style type="text/css">
</style>
<script type="text/javascript">
function deletePost(postId){
    swal({
        type: 'warning',
        title: 'Are you sure to delete this post?',
        text: '',
        showConfirmButton: true,
        showCancelButton: true,
        confirmButtonText: 'Delete',
        confirmButtonColor: '#CD0000'
    },function(){
        $.ajax({
            type: 'post',
            data: {postId: postId},
            url: '<?= base_url('adminPanel/deletePost') ?>',
            success: function(response){
                if($.trim(response) != 'success'){
                    toastr.error(response,'',{timeOut: 5000, positionClass: 'toast-top-center'});
                }else{
                    toastr.success('Action performed successfully','',{timeOut: 5000, positionClass: 'toast-top-center'});
                    $('#post-'+postId).remove();
                }
            },
            error: function(err){
                toastr.error('Unable to process your request','',{timeOut: 5000, positionClass: 'toast-top-center'});
            }
        })
    });
}
</script>