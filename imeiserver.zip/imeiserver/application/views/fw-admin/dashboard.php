<div class="layout-content">
    <div class="layout-content-body">
        <div class="row gutter-xs">
            <div class="col-md-6">
                <div class="row gutter-xs">
                    <div class="col-xs-12 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Visitor</h4>
                            </div>
                            <div class="card-body">
                                <div class="card-chart">
                                    <canvas data-chart="bar" data-animation="false" data-labels='[<?= implode(',',$states['lables']) ?>]' data-values='[{"label": "Visitor", "backgroundColor": "#1ECCC9", "borderColor": "#c91f37", "data": [<?= implode(',',$states['values']) ?>]}]' data-tooltips='{"mode": "label"}' data-hide='["gridLinesX", "legend"]' height="150"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="row gutter-xs">
                    <div class="col-xs-12 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Recent Comment <a href="<?= base_url(ADMIN_PATH.'/comments') ?>" class="pull-right">View All</a></h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <th>#</th>
                                            <th>Post</th>
                                            <th>From</th>
                                            <th>Comment</th>
                                            <th>Time</th>
                                        </thead>
                                        <tbody>
                                            <?php
                                            foreach($comments as $rec){
                                                $sStatus = 'success';
                                                if($rec->status == 'Pending'){
                                                    $sStatus = 'warning';
                                                }
                                                $post_link = base_url($rec->postSlug);
                                                echo '<tr id="comment-'.$rec->commentId.'">';
                                                    echo '<td>'.++$i.'</td>';
                                                    echo '<td><a href="'.$post_link.'" target="_blank">'.$rec->postTitle.'</a></td>';
                                                    echo '<td>'.$rec->fromName.'<br>'.$rec->fromEmail.'</br>'.$rec->ipAddress.'</td>';
                                                    echo '<td>'.$rec->comment.'</td>';
                                                    echo '<td>'.$rec->commentTime.'</td>';
                                                echo '</tr>';
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<style type="text/css">
</style>
<script type="text/javascript">
$(document).ready(function() {
});
</script>