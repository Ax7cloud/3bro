<div class="layout-content">
    <div class="layout-content-body">
        <div class="title-bar">
            <h1 class="title-bar-title">
                <span class="d-ib">Ads Setting</span>
            </h1>
        </div>
        <div class="panel">
            <div class="panel-body container-fluid">
                <div class="row row-lg">
                    <div class="col-md-12">
                        <form method="post" class="form-horizontal ads-form">
                        	<div class="form-group">
                        		<label class="control-label col-md-3 text-right">Header</label>
                        		<div class="col-md-6">
                        			<textarea class="form-control" name="header_ads" rows="5" style="resize: vertical;"><?= $ads['header_ads'] ?></textarea>
                        		</div>
                        	</div>
                            <div class="form-group">
                                <label class="control-label col-md-3 text-right">Sidebar</label>
                                <div class="col-md-6">
                                    <textarea class="form-control" name="sidebar_ads" rows="5" style="resize: vertical;"><?= $ads['sidebar_ads'] ?></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-3 text-right">Footer</label>
                                <div class="col-md-6">
                                    <textarea class="form-control" name="footer_ads" rows="5" style="resize: vertical;"><?= $ads['footer_ads'] ?></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-3 text-right">Post Ads</label>
                                <div class="col-md-6">
                                    <textarea class="form-control" name="post_ads" rows="5" style="resize: vertical;"><?= $ads['post_ads'] ?></textarea>
                                    <p class="help-block">Will be shown above the download button</p>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-3 text-right">Latest Model Ads</label>
                                <div class="col-md-6">
                                    <textarea class="form-control" name="latest_model_ads" rows="5" style="resize: vertical;"><?= $ads['latest_model_ads'] ?></textarea>
                                    <p class="help-block">Will be shown below the latest model update panel on home page</p>
                                </div>
                            </div>
                        	<div class="form-group">
                        		<label class="control-label col-md-3 text-right">&nbsp;</label>
                        		<div class="col-md-6">
                        			<button class="btn btn-block btn-primary" type="submit">Save</button>
                        		</div>
                        	</div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
$(document).ready(function(){
    $('[data-inputmask]').inputmask();
});
//profile-form
$("form.ads-form").submit(function(e){
    var btnOnj = $('.ads-form button[type="submit"]');
    btnOnj.addClass('spinner spinner-inverse').prop('disabled',true);

    $.ajax({
        url: window.location.href,
        type: 'POST',
        data: $('.ads-form').serialize(),
        success: function(response) {
            if(response != '1'){
                toastr.error(response,'',{timeOut: 5000, positionClass: 'toast-top-center'});
            }else{
                toastr.success('Action perfrom successfully.','',{timeOut: 5000, positionClass: 'toast-top-center'});
                window.location.reload();
            }
            btnOnj.removeClass('spinner spinner-inverse').prop('disabled',false);
        },
        error: function(err){
            toastr.error('Unable to process your request','',{timeOut: 5000, positionClass: 'toast-top-center'});
            btnOnj.removeClass('spinner spinner-inverse').prop('disabled',false);
        }
    });
    e.preventDefault();
});
</script>