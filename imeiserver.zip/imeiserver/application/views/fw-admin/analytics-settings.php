<div class="layout-content">
    <div class="layout-content-body">
        <div class="title-bar">
            <h1 class="title-bar-title">
                <span class="d-ib">Analytics Setting</span>
            </h1>
        </div>
        <div class="panel">
            <div class="panel-body container-fluid">
                <div class="row row-lg">
                    <div class="col-md-12">
                        <form method="post" class="form-horizontal ana-form">
                        	<div class="form-group">
                        		<label class="control-label col-md-2 text-right">Analytics</label>
                        		<div class="col-md-8">
                        			<textarea class="form-control" name="analytics" rows="10" style="resize: vertical;"><?= $record['analytics'] ?></textarea>
                                    <p class="help-block">Place all your analytical and verification scripts here</p>
                        		</div>
                        	</div>
                        	<div class="form-group">
                        		<label class="control-label col-md-2 text-right">&nbsp;</label>
                        		<div class="col-md-8">
                        			<button class="btn btn-block btn-primary" type="submit">Save</button>
                        		</div>
                        	</div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
$(document).ready(function(){
    $('[data-inputmask]').inputmask();
});
//profile-form
$("form.ana-form").submit(function(e){
    var btnOnj = $('.ana-form button[type="submit"]');
    btnOnj.addClass('spinner spinner-inverse').prop('disabled',true);

    $.ajax({
        url: window.location.href,
        type: 'POST',
        data: $('.ana-form').serialize(),
        success: function(response) {
            if(response != '1'){
                toastr.error(response,'',{timeOut: 5000, positionClass: 'toast-top-center'});
            }else{
                toastr.success('Action perfrom successfully.','',{timeOut: 5000, positionClass: 'toast-top-center'});
                window.location.reload();
            }
            btnOnj.removeClass('spinner spinner-inverse').prop('disabled',false);
        },
        error: function(err){
            toastr.error('Unable to process your request','',{timeOut: 5000, positionClass: 'toast-top-center'});
            btnOnj.removeClass('spinner spinner-inverse').prop('disabled',false);
        }
    });
    e.preventDefault();
});
</script>