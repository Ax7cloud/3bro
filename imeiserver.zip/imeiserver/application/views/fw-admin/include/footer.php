<?php 
$web = @json_decode(@file_get_contents('resource/web-setting.info'));
?>
</div>
<div class="layout-footer">
    <div class="layout-footer-body">
        <small class="copyright"><?= date('Y') ?> &copy; <a href="<?= base_url() ?>dashboard" class="is-nav" data-is-nav="dashboard"><?= $web->webTitle; ?></a></small>
    </div>
</div>
</div>
<div class="top-loading" style="display: none;"><span class="please-wait">Please Wait</span></div>
<span class="no-connection">No Internet Connection</span>
<script src="<?= base_url() ?>assets/js/vendor.min.js"></script>
<script src="<?= base_url() ?>assets/js/elephant.min.js"></script>
<script src="<?= base_url() ?>assets/js/application.min.js"></script>
<script src="<?= base_url() ?>assets/js/compose.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/ckeditor/4.7.3/ckeditor.js"></script>
<!-- <script src="https://cdn.ckeditor.com/ckeditor5/23.0.0/classic/ckeditor.js"></script> -->
<style type="text/css">
.is-loading {cursor: wait;}
.top-loading {background-color: #e67e22;height: 6px;position: fixed;right: 0;top: 0;width: 100%;z-index: 2147483647;}
.please-wait {background-color: #e67e22;border-radius: 3px;color: #ffffff;font-style: italic;left: 47%;padding: 5px 10px;position: fixed;top: 0;z-index: 2147483647;}
.no-connection {background-color: #cd0000;border-radius: 3px;color: #ffffff;font-style: italic;left: 47%;padding: 5px 10px;position: fixed;top: 50px;z-index: 2147483650;display: none;}
@media (max-width: 700px){
	.top-loading .please-wait{left: 44%;}
	.no-connection{left: 44%;}
}
@media (max-width: 400px){
	.top-loading .please-wait{left: 38%;}
	.no-connection{left: 28%;}
}
.counter-help {
    text-align: right;
}
.counter-help > b {
    margin-right: 20px;
}
.sms-limit {
    color: red;
}
a.list-group-item.noti-active{background-color: #e5ebf1;}
.nowrap-td{ white-space: nowrap; overflow: hidden; }
.center-td{text-align: center;}
span.is-req {color: red;}
</style>
</body>
</html>
<script type="text/javascript">
var isLoading = false;
$(document).ajaxStart(function() {
    $('.top-loading').fadeIn();
    isLoading = true;
    $('body').addClass('is-loading');
});
$(document).ajaxStop(function() {
    isLoading = false;
    $('body').removeClass('is-loading');
    $('.top-loading').fadeOut();
});
$(document).ready(function(){
	$('.date-picker').datepicker({format: "yyyy-mm-dd", autoclose:true, todayHighlight: true});
	$('.select2:not(.normal)').each(function () {
        $(this).select2({
            dropdownParent: $(this).parent()
        });
    });
    var b = $(".select-tags").select2({
        tags: !0,
        tokenSeparators: [",", " "],
        dir: "ltr",
        placeholder: ""
    });
    $('.input-mask').inputmask();
    $('[data-toggle="tooltip"').tooltip();
})
function counter(msg,obj){
	var length = msg != '' ? msg.length : '1';
	var reminder = length % 160;
	var sms = Math.floor(length / 160);
	if(reminder > 0){
		sms++;
	}
	var vClass = length == 640 ? 'sms-limit' : '';

	var vParent = $(obj).parent();
	if(vParent.find('.counter-help').length){
		vParent.find('.counter-help').html('Char '+length+'/640 ('+sms+' SMS)');
		if(vClass != ''){
			vParent.find('.counter-help').addClass(vClass);
		}else{
			vParent.find('.counter-help').removeClass('sms-limit');
		}
	}else{
		vParent.append('<p class="counter-help '+vClass+'">Char '+length+'/640 ('+sms+' SMS)</p>');
	}
}
</script>