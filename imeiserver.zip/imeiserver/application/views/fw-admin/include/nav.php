<?php
$pagesArr = array('', 'dashboard', 'profile', 'settings', 'cms', 'posts', 'comments','contact-us');

$page = $this->uri->segment(3);
$nav = $this->uri->segment(2);
if($nav == ''){
    $page = 'dashboard';
}

if(!in_array($nav, $pagesArr)){
    redirect('error-404');
}
if($nav == 'contact-us'){
    $nav = 'contact';
}

$$page = 'active';
$$nav = 'active open';

if(!isLoggedIn()){
    redirect(ADMIN_PATH);
}

?>
<div class="layout-main">
<div class="layout-sidebar">
    <div class="layout-sidebar-backdrop"></div>
    <div class="layout-sidebar-body">
        <div class="custom-scrollbar">
            <nav id="sidenav" class="sidenav-collapse collapse">
                <ul class="sidenav">
                    <li class="sidenav-item <?= $dashboard ?>">
                        <a href="<?= base_url(ADMIN_PATH.'/dashboard') ?>" class="is-nav">
                            <span class="sidenav-icon icon icon-home"></span>
                            <span class="sidenav-label">Dashboard</span>
                        </a>
                    </li>
                    <li class="sidenav-item <?= $profile ?>">
                        <a href="<?= base_url(ADMIN_PATH.'/profile') ?>" class="is-nav">
                            <span class="sidenav-icon icon icon-user"></span>
                            <span class="sidenav-label">Profile</span>
                        </a>
                    </li>
                    <li class="sidenav-item has-subnav <?= $settings ?>">
                        <a href="<?= base_url(ADMIN_PATH.'settings/web') ?>" aria-haspopup="true">
                            <span class="sidenav-icon icon icon-phone"></span>
                            <span class="sidenav-label">Settings</span>
                        </a>
                        <ul class="sidenav-subnav collapse">
                            <li class="sidenav-subheading">Settings</li>
                            <li class="<?= $web ?>">
                                <a href="<?= base_url(ADMIN_PATH.'/settings/web') ?>" class="is-nav">Web Portal</a>
                            </li>
                            <li class="<?= $ads ?>">
                                <a href="<?= base_url(ADMIN_PATH.'/settings/ads') ?>" class="is-nav">Ads Setting</a>
                            </li>
                            <li class="<?= $analytics ?>">
                                <a href="<?= base_url(ADMIN_PATH.'/settings/analytics') ?>" class="is-nav">Analytics Setting</a>
                            </li>
                        </ul>
                    </li>
                    <li class="sidenav-item <?= $cms ?>">
                        <a href="<?= base_url(ADMIN_PATH.'/cms') ?>" class="is-nav">
                            <span class="sidenav-icon icon icon-tasks"></span>
                            <span class="sidenav-label">CMS</span>
                        </a>
                    </li>
                    <li class="sidenav-item <?= $posts ?>">
                        <a href="<?= base_url(ADMIN_PATH.'/posts') ?>" class="is-nav">
                            <span class="sidenav-icon icon icon-sticky-note-o"></span>
                            <span class="sidenav-label">Post</span>
                        </a>
                    </li>
                    <li class="sidenav-item <?= $comments ?>">
                        <a href="<?= base_url(ADMIN_PATH.'/comments') ?>" class="is-nav">
                            <span class="sidenav-icon icon icon-comment"></span>
                            <span class="sidenav-label">Comments</span>
                        </a>
                    </li>
                    <li class="sidenav-item <?= $contact ?>">
                        <a href="<?= base_url(ADMIN_PATH.'/contact-us') ?>" class="is-nav">
                            <span class="sidenav-icon icon icon-comments"></span>
                            <span class="sidenav-label">CONTACT US</span>
                        </a>
                    </li>
                    <li class="sidenav-item">
                        <a href="<?= base_url(ADMIN_PATH.'/logout') ?>">
                            <span class="sidenav-icon icon icon-sign-out"></span>
                            <span class="sidenav-label">Logout</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</div>
<div class="load-view-page">