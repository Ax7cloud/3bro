<?php 
$profileImage = base_url().'resource/avatar.png';
$webtrAsc = @json_decode(@file_get_contents('resource/web-setting.info'));

$webLogo = base_url().'resource/logo.png';
$favicon = base_url().'resource/favicon.ico';

if(file_exists('resource/'.$webtrAsc->webLogo)){
    $webLogo = base_url().'resource/'.$webtrAsc->webLogo;
}
if(file_exists('resource/'.$webtrAsc->webLogofavicon)){
    $favicon = base_url().'resource/'.$webtrAsc->favicon;
}
$webLogo = $webLogo.'?v='.time();
$favicon = $favicon.'?v='.time();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title><?= $webtrAsc->webTitle ?></title>
        <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
        <meta name="theme-color" content="#ffffff">
        <link rel="shortcut icon" href="<?= $favicon ?>">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,400italic,500,700">
        <link rel="stylesheet" href="<?= base_url() ?>assets/css/vendor.min.css">
        <link rel="stylesheet" href="<?= base_url() ?>assets/css/elephant.min.css">
        <link rel="stylesheet" href="<?= base_url() ?>assets/css/application.min.css">
        <link rel="stylesheet" href="<?= base_url() ?>assets/css/dashboard-3.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <link rel="stylesheet" href="<?= base_url() ?>assets/sweetalert/sweetalert.css">
        <script src="<?= base_url() ?>assets/sweetalert/sweetalert-dev.js"></script>
    </head>
    <body class="layout layout-header-fixed layout-sidebar-fixed layout-footer-fixed">
		<div class="layout-header">
            <div class="navbar navbar-default">
                <div class="navbar-header">
                    <a class="navbar-brand navbar-brand-center" href="<?= base_url(ADMIN_PATH) ?>/dashboard">
                    <img class="navbar-brand-logo" src="<?= $webLogo.'?u='.time() ?>" alt="<?= $webtrAsc->webTitle ?>">
                    </a>
                    <button class="navbar-toggler visible-xs-block collapsed" type="button" data-toggle="collapse" data-target="#sidenav">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="bars">
                    <span class="bar-line bar-line-1 out"></span>
                    <span class="bar-line bar-line-2 out"></span>
                    <span class="bar-line bar-line-3 out"></span>
                    </span>
                    <span class="bars bars-x">
                    <span class="bar-line bar-line-4"></span>
                    <span class="bar-line bar-line-5"></span>
                    </span>
                    </button>
                    <button class="navbar-toggler visible-xs-block collapsed" type="button" data-toggle="collapse" data-target="#navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="arrow-up"></span>
                    <span class="ellipsis ellipsis-vertical">
                    <img class="ellipsis-object" width="32" height="32" src="<?= $profileImage.'?u='.time() ?>" alt="<?= $this->app->first_name.' '.$this->app->last_name ?>">
                    </span>
                    </button>
                </div>
                <div class="navbar-toggleable">
                    <nav id="navbar" class="navbar-collapse collapse">
                        <button class="sidenav-toggler hidden-xs" title="Collapse sidenav ( [ )" aria-expanded="true" type="button">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="bars">
                                <span class="bar-line bar-line-1 out"></span>
                                <span class="bar-line bar-line-2 out"></span>
                                <span class="bar-line bar-line-3 out"></span>
                                <span class="bar-line bar-line-4 in"></span>
                                <span class="bar-line bar-line-5 in"></span>
                                <span class="bar-line bar-line-6 in"></span>
                            </span>
                        </button>
                        <ul class="nav navbar-nav navbar-right">
                            <li class="visible-xs-block">
                                <h4 class="navbar-text text-center">Hi, <?= $this->app->name ?></h4>
                            </li>
                            <?php
                            $contactUsArr = getContactUSHeader();
                            ?>
                            <li class="dropdown">
                                <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true">
                                    <span class="icon-with-child hidden-xs">
                                        <span class="icon icon-bell-o icon-lg"></span>
                                        <span class="badge badge-danger badge-above right"><?= $contactUsArr['ecount'] != '0' ? $contactUsArr['ecount'] : '' ?></span>
                                    </span>
                                    <span class="visible-xs-block">
                                        <span class="icon icon-bell icon-lg icon-fw"></span>
                                        <span class="badge badge-danger pull-right"><?= $contactUsArr['ecount'] != '0' ? $contactUsArr['ecount'] : '' ?></span>
                                        Contact US
                                    </span>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-lg">
                                    <div class="dropdown-header">
                                        <h5 class="dropdown-heading">Recent Contact Us</h5>
                                    </div>
                                    <div class="dropdown-body">
                                        <?php
                                        foreach($contactUsArr['record'] as $rec){
                                            echo '<a class="list-group-item '.($rec->status == '0' ? 'active' : '').'" href="'.base_url(ADMIN_PATH.'/contact-us/'.$rec->contactUsId).'">';
                                                echo '<div class="notification">';
                                                    echo '<div class="notification-media">';
                                                        echo '<span class="icon icon-exclamation-triangle bg-info rounded sq-40"></span>';
                                                    echo '</div>';
                                                    echo '<div class="notification-content">';
                                                        echo '<small class="notification-timestamp">'.timeAgo($rec->createdTime).'</small>';
                                                        echo '<h5 class="notification-heading">'.$rec->fromName.'</h5>';
                                                        echo '<p class="notification-text">';
                                                            echo '<small class="truncate">'.substr($rec->description,0,100).'</small>';
                                                        echo '</p>';
                                                    echo '</div>';
                                                echo '</div>';
                                            echo '</a>';
                                        }
                                        ?>
                                    </div>
                                    <div class="dropdown-footer">
                                        <a class="dropdown-btn" href="<?= base_url(ADMIN_PATH) ?>/contact-us">See All</a>
                                    </div>
                                </div>
                            </li>
                            <li class="dropdown hidden-xs">
                                <button class="navbar-account-btn" data-toggle="dropdown" aria-haspopup="true">
                                    <img class="rounded" width="36" height="36" src="<?= $profileImage.'?u='.time() ?>" alt="<?= $this->app->first_name ?>"> <?= $this->app->name ?>
                                    <span class="caret"></span>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-right">
                                    <li>
                                        <a href="<?= base_url(ADMIN_PATH) ?>/profile" class="is-nav" data-is-nav="profile">Profile</a>
                                    </li>
                                    <li><a href="<?= base_url(ADMIN_PATH) ?>/logout">Sign Out</a></li>
                                </ul>
                            </li>
                            <li class="visible-xs-block">
                                <a href="<?= base_url(ADMIN_PATH) ?>/logout">
                                <span class="icon icon-power-off icon-lg icon-fw"></span>Sign Out</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>