<?php 
$this->load->view('fw-admin/include/header');
$this->load->view('fw-admin/include/nav');
$this->load->view('fw-admin/'.$request);
$this->load->view('fw-admin/include/footer');
?>