<?php 
$web = @json_decode(@file_get_contents('resource/web-setting.info'));

$webLogo = base_url().'resource/logo.png';
$favicon = base_url().'resource/favicon.ico';

if(file_exists('resource/'.$web->webLogo)){
    $webLogo = base_url().'resource/'.$web->webLogo;
}
if(file_exists('resource/'.$web->webLogofavicon)){
    $favicon = base_url().'resource/'.$web->favicon;
}
$webLogo = $webLogo.'?v='.time();
$favicon = $favicon.'?v='.time();

$num1 = rand(0,19);
$num2 = rand(0,19);
$qanswer = $num1 + $num2;

$this->session->set_userdata('seq-ans',$qanswer);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Login .::. <?= $web->webTitle ?></title>
        <link rel="shortcut icon" href="<?= $favicon ?>">
        <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
        <meta name="theme-color" content="#ffffff">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,400italic,500,700">
        <link rel="stylesheet" href="<?= base_url() ?>assets/css/vendor.min.css">
        <link rel="stylesheet" href="<?= base_url() ?>assets/css/elephant.min.css">
        <link rel="stylesheet" href="<?= base_url() ?>assets/css/login-2.min.css">
    </head>
    <body>
        <div class="login">
            <div class="login-body">
                <a class="login-brand" href="<?= base_url() ?>">
                    <img class="img-responsive" src="<?= $webLogo ?>" alt="<?= $web->webTitle ?>">
                </a>
                <div class="login-form">
                    <form data-toggle="validator" method="post" action="" class="login-form">
                        <input type="hidden" name="qanswer">
                        <?php if($this->session->userdata('error')){ ?>
                            <div class="form-group">
                                <div class="alert alert-danger"><?= $this->session->userdata('error') ?></div>
                            </div>
                        <?php } $this->session->unset_userdata('error'); ?>
                        <div class="form-group">
                            <label for="email">Username</label>
                            <input id="email" class="form-control" type="text" name="username" spellcheck="false" autocomplete="off" data-msg-required="Please enter your username." required value="<?= set_value('username',$this->input->cookie('loginUsername')) ?>">
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input id="password" class="form-control" type="password" name="password" minlength="6" data-msg-minlength="Password must be 6 characters or more." data-msg-required="Please enter your password." required>
                        </div>
                        <div class="form-group">
                            <label for="password">Security Question</label>
                            <div class="input-group">
                                <span class="input-group-addon">
                                    <?= $num1.'&nbsp;&nbsp;+&nbsp;&nbsp;'.$num2  ?>&nbsp;&nbsp; = &nbsp;&nbsp; 
                                </span>
                                <input class="form-control" type="text" name="sanswer" style="text-align: center;">
                            </div>
                        </div>
                        <button class="btn btn-primary btn-block" type="submit" name="submit">Sign in</button>
                    </form>
                </div>
            </div>
        </div>
        <script src="<?= base_url() ?>assets/js/vendor.min.js"></script>
        <script src="<?= base_url() ?>assets/js/elephant.min.js"></script>
    </body>
</html>
<script type="text/javascript">
</script>