<?php
$comments = $this->session->userdata('comments');
?>
<div class="layout-content">
    <div class="layout-content-body">
        <div class="title-bar">
            <h1 class="title-bar-title">
                <span class="d-ib">Comments</span>
            </h1>
        </div>
        <div class="panel">
            <div class="panel-body container-fluid">
                <div class="col-md-row">
                    <form action="<?= base_url(ADMIN_PATH.'/comments') ?>" method="post">
                        <div class="col-md-4">
                            <label>Select Post</label>
                            <select class="form-control ajax-select" name="postId">
                                <?php
                                if($comments['postId'] != '' && $comments['postId'] != '0' && $comments['postId'] != null){
                                    echo '<option value="'.$comments['postId'].'" selected="">'.getPost($comments['postId'])->postTitle.'</option>';
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label>Status</label>
                            <select class="form-control select2" name="status">
                                <option value="All" <?= $comments['status'] == 'All' ? 'selected=""' : '' ?>>All</option>
                                <option value="Pending" <?= $comments['status'] == 'Pending' || $comments['status'] == '' ? 'selected=""' : '' ?>>Pending</option>
                                <option value="Approved" <?= $comments['status'] == 'Approved' ? 'selected=""' : '' ?>>Approved</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label style="display: block;">&nbsp;</label>
                            <button class="btn btn-primary" type="submit">Filter</button>
                            <?php
                            if($this->session->userdata('comments')){
                                echo '<a href="'.base_url(ADMIN_PATH.'/comments?reset=true').'" class="btn btn-default">Reset</a>';
                            }
                            ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="panel">
            <div class="panel-body container-fluid">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <th>#</th>
                                <th>Post</th>
                                <th>From</th>
                                <th>Comment</th>
                                <th>Time</th>
                                <th>Status</th>
                                <th>Action</th>
                            </thead>
                            <tbody>
                                <?php
                                $i = $this->page_record;
                                foreach($record as $rec){
                                    $sStatus = 'success';
                                    if($rec->status == 'Pending'){
                                        $sStatus = 'warning';
                                    }
                                    $post_link = base_url($rec->postSlug);
                                    echo '<tr id="comment-'.$rec->commentId.'">';
                                        echo '<td>'.++$i.'</td>';
                                        echo '<td><a href="'.$post_link.'" target="_blank">'.$rec->postTitle.'</a></td>';
                                        echo '<td>'.$rec->fromName.'<br>'.$rec->fromEmail.'</br>'.$rec->ipAddress.'</td>';
                                        echo '<td>'.$rec->comment.'</td>';
                                        echo '<td>'.$rec->commentTime.'</td>';
                                        echo '<td><label class="label label-'.$sStatus.'" '.($rec->status == 'Pending' ? 'onclick="approveComment(this,'.$rec->commentId.','.$rec->postId.')"' : '').'>'.$rec->status.'</label></td>';
                                        echo '<td>';
                                            if($rec->status == 'Approved'){
                                                echo '<a href="'.base_url(ADMIN_PATH.'/comments/'.$rec->commentId).'"><i class="icon icon-reply"></i></a>';
                                                echo '&nbsp;&nbsp;';
                                            }
                                            echo '<a href="javascript:;" onclick="deleteComment('.$rec->commentId.')"><i class="icon icon-trash"></i></a>';
                                        echo '</td>';
                                    echo '</tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                        <?= '<ul class="pagination">'.$this->pagination->create_links().'</ul>'; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" tabindex="-1" role="dialog" id="comment-modal" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title">Comment</h4>
            </div>
            <form action="" class="comment-form" method="post">
                <div class="modal-body">
                    <input type="hidden" name="commentId" value="">
                    <div class="form-group">
                        <textarea name="comment" cols="30" rows="10" class="form-control" required=""></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
<style type="text/css">
</style>
<script type="text/javascript">
$(document).ready(function(){
    $('.ajax-select').select2({
        allowClear: true,
        placeholder: "Search in posts",
        minimumInputLength: 3,
        delay: 250,
        ajax: {
            url: '<?= base_url('adminPanel/getPosts') ?>',
            dataType: 'json',
            data: function (params) {
                var query = {
                    search: params.term
                }
                return query;
            },
            processResults: function (data) {
                return {
                    results: data
                };
           },
        }
    });
});
function approveComment(obj,commentId,postId){
    swal({
        type: 'info',
        title: 'Are you sure to approve this?',
        text: '',
        showConfirmButton: true,
        showCancelButton: true,
        confirmButtonText: 'Approve',
    },function(){
        $.ajax({
            type: 'post',
            data: {commentId:commentId, postId:postId},
            url: '<?= base_url('adminPanel/approveComment') ?>',
            success: function(response){
                if($.trim(response) != 'success'){
                    toastr.error(response,'',{timeOut: 5000, positionClass: 'toast-top-center'});
                }else{
                    toastr.success('Action performed successfully','',{timeOut: 5000, positionClass: 'toast-top-center'});
                    $(obj).parent().html('<label class="label label-success">Approved</label>');
                }
            },
            error: function(err){
                toastr.error('Unable to process your request','',{timeOut: 5000, positionClass: 'toast-top-center'});
            }
        })
    });
}
function deleteComment(commentId){
    swal({
        type: 'warning',
        title: 'Are you sure to delete this comment?',
        text: '',
        showConfirmButton: true,
        showCancelButton: true,
        confirmButtonText: 'Delete',
        confirmButtonColor: '#CD0000'
    },function(){
        $.ajax({
            type: 'post',
            data: {commentId: commentId},
            url: '<?= base_url('adminPanel/deleteComment') ?>',
            success: function(response){
                if($.trim(response) != 'success'){
                    toastr.error(response,'',{timeOut: 5000, positionClass: 'toast-top-center'});
                }else{
                    toastr.success('Action performed successfully','',{timeOut: 5000, positionClass: 'toast-top-center'});
                    $('#comment-'+commentId).remove();
                }
            },
            error: function(err){
                toastr.error('Unable to process your request','',{timeOut: 5000, positionClass: 'toast-top-center'});
            }
        })
    });
}
</script>