<?php 
$webLogo = base_url().'resource/default/logo.png';
$favicon = base_url().'resource/default/favicon.ico';
if(file_exists('resource/'.$record->webLogo)){
	$webLogo = base_url().'resource/'.$record->webLogo;
}
if(file_exists('resource/'.$record->webLogofavicon)){
	$favicon = base_url().'resource/'.$record->favicon;
}
$webLogo = $webLogo.'?v='.time();
$favicon = $favicon.'?v='.time();
?>
<div class="layout-content">
    <div class="layout-content-body">
        <div class="title-bar">
            <h1 class="title-bar-title">
                <span class="d-ib">Website</span>
            </h1>
        </div>
        <div class="panel">
            <div class="panel-body container-fluid">
                <form method="post" class="form-horizontal web-form" enctype="multipart/form-data">
                    <input type="hidden" name="save" value="yes">
                	<div class="form-group">
                        <label class="control-label col-md-3">Website Title</label>
                		<div class="col-md-6">
                			<input type="text" class="form-control" name="webTitle" value="<?= $record->webTitle ?>" required>
                		</div>
                	</div>
                	<div class="form-group">
                        <label class="control-label col-md-3">Website Logo</label>
                		<div class="col-md-6">
							<div class="input-group input-group-file">
                                <input class="form-control w-image" readonly="" type="text">
                                <span class="input-group-btn">
                                    <label class="btn btn-primary file-upload-btn">
                                        <input name="webLogo" class="file-upload-input" type="file" onchange="getFileName(this,'w-image')">
                                        <span class="icon icon-image icon-lg"></span>
                                    </label>
                                </span>
							</div>
							<p class="help-block">Allowed format (PNG/JPG/JPEG) </p>
                		</div>
                	</div>
                	<div class="form-group">
                        <label class="control-label col-md-3">&nbsp;</label>
                		<div class="col-md-6">
                            <span style="background-color: #f8f8f8;padding: 10px;text-align: center;display: block;">
                			    <img src="<?= $webLogo ?>" alt="<?= $record->webTitle ?>" style="max-width: 120px;">
                            </span>
                		</div>
                	</div>
                	<div class="form-group">
                        <label class="control-label col-md-3">Favicon</label>
                		<div class="col-md-6">
							<div class="input-group input-group-file">
								<input class="form-control f-image" readonly="" type="text">
                                <span class="input-group-btn">
                                    <label class="btn btn-primary file-upload-btn">
                                        <input name="favicon" class="file-upload-input" type="file" onchange="getFileName(this,'f-image')">
                                        <span class="icon icon-image icon-lg"></span>
                                    </label>
                                </span>
							</div>
							<p class="help-block">Allowed format (ICO) </p>
                		</div>
                	</div>
                	<div class="form-group">
                        <label class="control-label col-md-3">&nbsp;</label>
                		<div class="col-md-6">
                            <span style="background-color: #f8f8f8;padding: 10px;text-align: center;display: block;">
                			    <img src="<?= $favicon ?>" alt="<?= $record->webTitle ?>" style="max-width: 120px;">
                            </span>
                		</div>
                	</div>
                    <div class="form-group">
                        <label class="control-label col-md-3 text-right">Meta Title</label>
                        <div class="col-md-6">
                            <input type="text" name="metaTitle" class="form-control" value="<?= $record->metaTitle ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3 text-right">Meta Tags</label>
                        <div class="col-md-6">
                            <select class="form-control select-tags" name="metaTags[]" multiple="">
                                <?php
                                $metaTags = @explode(',', $record->metaTags);
                                if($record->metaTags != ''){
                                    foreach($metaTags as $tag){
                                        echo '<option value="'.$tag.'" selected="">'.$tag.'</option>';
                                    }
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3 text-right">Meta Description</label>
                        <div class="col-md-6">
                            <textarea name="metaDesription" class="form-control" style="resize: vertical;"><?= $record->metaDesription ?></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3 text-right">header Search Title</label>
                        <div class="col-md-6">
                            <input type="text" name="headerSearchTitle" class="form-control" value="<?= $record->headerSearchTitle ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3 text-right">header Search Description</label>
                        <div class="col-md-6">
                                <textarea class="form-control" name="headerSearchDescription" rows="3" style="resize: vertical;"><?= $record->headerSearchDescription ?></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3">Twitter Link</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control input-mask" name="twitterLink" value="<?= $record->twitterLink ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3">Facebook Link</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control input-mask" name="facebookLink" value="<?= $record->facebookLink ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3">Youtube Link</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control input-mask" name="youtubeLink" value="<?= $record->youtubeLink ?>">
                        </div>
                    </div>
                	<div class="form-group">
                        <label class="control-label col-md-3">&nbsp;</label>
                		<div class="col-md-6">
                			<button class="btn btn-primary btn-block btn-sm do-save">Save</button>
                		</div>
                	</div>
                </form>
            </div>
        </div>
    </div>
</div>
<style type="text/css">
.feature-col {margin-bottom: 10px;}
.feature-col .input-group-addon {min-width: 170px;text-align: left;}
.switch.switch-primary {margin-top: 8px;}
</style>
<script type="text/javascript">
$(document).ready(function(){
    $('.input-mask').inputmask();
});
function getFileName(obj,tagClass){
    var vValue = $(obj).val();
    vValue = vValue.replace("C:\\fakepath\\",'');
    vValue = vValue.replace("C:\\fakepath\"",'');
	$('.'+tagClass).val(vValue);
}
$("form.web-form").submit(function(e){
    var formData = new FormData($(this)[0]);

    var btnOnj = $('.web-form .do-save');
    btnOnj.addClass('spinner spinner-inverse').prop('disabled',true);

    $.ajax({
        url: window.location.href,
        type: 'POST',
        data: formData,
        async: false,
        success: function(response) {
            if(response != '1'){
                toastr.error(response,'',{timeOut: 5000, positionClass: 'toast-top-center'});
            }else{
                toastr.success('Action perfrom successfully.','',{timeOut: 5000, positionClass: 'toast-top-center'});
                window.location.reload();
            }
            btnOnj.removeClass('spinner spinner-inverse').prop('disabled',false);
        },
        error: function(err){
            toastr.error('Unable to process your request','',{timeOut: 5000, positionClass: 'toast-top-center'});
            btnOnj.removeClass('spinner spinner-inverse').prop('disabled',false);
        },
        cache: false,
        contentType: false,
        processData: false
    });
    e.preventDefault();
});
</script>