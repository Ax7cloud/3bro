<?php
$actionType = $this->uri->segment(3);
?>
<div class="layout-content">
    <div class="layout-content-body">
        <div class="title-bar">
            <h1 class="title-bar-title">
                <span class="d-ib"><?= ucfirst($actionType) ?> Page</span>
                <a href="<?= base_url(ADMIN_PATH.'/cms') ?>" class="btn btn-default pull-right">Back</a>
            </h1>
        </div>
        <div class="panel">
            <div class="panel-body container-fluid">
                <div class="row row-lg">
                    <div class="col-md-12">
                        <form method="post" class="form-horizontal page-form">
                            <input type="hidden" name="pageId" value="<?= $page->pageId ?>">
                            <textarea name="template" class="template" style="display: none;"><?= $page->pageContent ?></textarea>
                        	<div class="form-group">
                        		<label class="control-label col-md-2 text-right">Page Title</label>
                        		<div class="col-md-6">
                        			<input type="text" class="form-control" name="title" value="<?= $page->pageTitle ?>" onchange="updateSlug(this.value)">
                                    <p class="hel-block page-slug"><?= $page->slugUrl != '' ? '<a href="'.base_url($page->slugUrl).'" target="_blank">'.base_url($page->slugUrl).'</a>' : '' ?></p>
                        		</div>
                        	</div>
                        	<div class="form-group">
                        		<label class="control-label col-md-2 text-right">Page Content</label>
                        		<div class="col-md-10">
                        			<textarea name="content" id="ckedit" cols="30" rows="10"><?= $page->pageContent ?></textarea>
                        		</div>
                        	</div>
                            <div class="form-group">
                                <label class="control-label col-md-2 text-right">Meta Title</label>
                                <div class="col-md-8">
                                    <input type="text" name="metaTitle" class="form-control" value="<?= $page->metaTitle ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-2 text-right">Meta Tags</label>
                                <div class="col-md-8">
                                    <select class="form-control select-tags" name="metaTags[]" multiple="">
                                        <?php
                                        $metaTags = @explode(',', $page->metaTags);
                                        if($page->metaTags != ''){
                                            foreach($metaTags as $tag){
                                                echo '<option value="'.$tag.'" selected="">'.$tag.'</option>';
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-2 text-right">Meta Description</label>
                                <div class="col-md-8">
                                    <textarea name="metaDesription" class="form-control" style="resize: vertical;"><?= $page->metaDesription ?></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-2 text-right">Position</label>
                                <div class="col-md-6" style="margin-top: 6px;">
                                    <label class="custom-control custom-control-primary custom-radio">
                                        <input name="position" class="position custom-control-input" type="radio" value="header" <?= $page->position == 'header' ? 'checked=""' : '' ?>>
                                        <span class="custom-control-indicator"></span>
                                        <span class="custom-control-label">Header</span>
                                    </label>
                                    <label class="custom-control custom-control-primary custom-radio">
                                        <input name="position" class="position custom-control-input" type="radio" value="footer" <?= $page->position != 'header' ? 'checked=""' : '' ?>>
                                        <span class="custom-control-indicator"></span>
                                        <span class="custom-control-label">Footer</span>
                                    </label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-2 text-right">Status</label>
                                <div class="col-md-6" style="margin-top: 6px;">
                                    <label class="custom-control custom-control-primary custom-radio">
                                        <input name="status" class="status custom-control-input" type="radio" value="Active" <?= $page->status != 'Inactive' ? 'checked=""' : '' ?>>
                                        <span class="custom-control-indicator"></span>
                                        <span class="custom-control-label">Active</span>
                                    </label>
                                    <label class="custom-control custom-control-primary custom-radio">
                                        <input name="status" class="status custom-control-input" type="radio" value="Inactive" <?= $page->status == 'Inactive' ? 'checked=""' : '' ?>>
                                        <span class="custom-control-indicator"></span>
                                        <span class="custom-control-label">Inactive</span>
                                    </label>
                                </div>
                            </div>
                        	<div class="form-group">
                        		<label class="control-label col-md-2 text-right">&nbsp;</label>
                        		<div class="col-md-10">
                        			<button class="btn btn-primary pull-right" type="submit">Save</button>
                        		</div>
                        	</div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
var actionType = '<?= $actionType ?>'
$(document).ready(function(){
    $('[data-inputmask]').inputmask();
    CKEDITOR.replace('ckedit',
        {height: 600}
    );
});
function updateSlug(title){
    var slugUrl = $.trim(title.toLowerCase().replace(/ /g,'-').replace(/_/g,'-').replace(/[^\w-]+/g,'')).replace(/--/g,'-');
    if(actionType == 'add'){
        $('.page-slug').text(slugUrl);
    }
}
$('form.page-form').submit(function(e){
    var ckValue = CKEDITOR.instances['ckedit'].getData();
    $('.page-form .template').val(ckValue);

    $('.page-form button[type="submit"]').addClass('spinner spinner-inverse').prop('disabled',true);

    $.ajax({
        type: 'post',
        data: $('.page-form').serialize(),
        url: '<?= base_url('adminPanel/savePage') ?>',
        success: function(response){
            $('.page-form button[type="submit"]').removeClass('spinner spinner-inverse').prop('disabled',false);
            if($.trim(response) != 'success'){
                toastr.error(response,'',{timeOut: 5000, positionClass: 'toast-top-center'});
            }else{
                toastr.success('Action performed successfully','',{timeOut: 5000, positionClass: 'toast-top-center'});
                window.location.href = '<?= base_url(ADMIN_PATH.'/cms') ?>';
            }
        },
        error: function(err){
            toastr.error('Unable to process your request','',{timeOut: 5000, positionClass: 'toast-top-center'});
            $('.page-form button[type="submit"]').removeClass('spinner spinner-inverse').prop('disabled',false);
        }
    })
    e.preventDefault();
})
</script>