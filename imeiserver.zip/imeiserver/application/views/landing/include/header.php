<?php 
$profileImage = base_url().'resource/avatar.png';
$webLogo = base_url().'resource/thq-logo.jpg';
$favicon = base_url().'resource/favicon.ico';

if(file_exists('resource/'.$this->web->webLogo)){
    $webLogo = base_url().'resource/'.$this->web->webLogo;
}
if(file_exists('resource/'.$this->web->webLogofavicon)){
    $favicon = base_url().'resource/'.$this->web->favicon;
}
$webLogo = $webLogo.'?v='.time();
$favicon = $favicon.'?v='.time();

$webTitle = $this->web->webTitle;
if($web_title != ''){
    $webTitle = $web_title;
}

$metaTitle = $this->web->metaTitle;
$metaDesription = $this->web->metaDesription;
$metaTags = $this->web->metaTags;

if($meta_tags != ''){ $metaTags = $meta_tags; }
if($meta_title != ''){ $metaTitle = $meta_title; $webTitle = $meta_title.' - '.$this->web->webTitle; }
if($meta_description != ''){ $metaDesription = $meta_description; }

$gSitekey = '6LfqvUcdAAAAAPZLWWVjLpWpKH4Gc51_cND7otGe';
$gSiteSecret = '6LfqvUcdAAAAAOjMC9ogsm35YUoNJro0qdYJ6ims';
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title><?= $webTitle ?></title>
        <meta name="description" content="<?= $metaDesription ?>">
        <meta name="keywords" content="<?= $metaTags ?>">
        <meta property="og:title" content="<?= $webTitle ?>" />
        <meta property="og:site_name" content="<?= $this->web->webTitle ?>" />
        <meta property="og:description" content="<?= $metaDesription ?>" />
        <meta property="og:keywords" content="<?= $metaTags ?>" />
        <meta property="og:url" content="<?= base_url() ?>" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="author" content="Umair">
        <link href="<?= $favicon ?>" rel="icon" type="image/png">
        <?php
        if($canonicalTags != '' && $canonicalTags != NULL){
            echo '<link rel="canonical" href="'.$canonicalTags.'" />';
        }
        ?>
        <link rel="stylesheet" href="<?= base_url('assets/landing/bootstrap.min.css') ?>">
        <link rel="stylesheet" href="<?= base_url('assets/landing/lazy.css') ?>">
        <link rel="stylesheet" href="<?= base_url('assets/landing/demo.css') ?>">
        <link rel="stylesheet" href="<?= base_url('assets/landing/autocomplete.css') ?>">
        <link rel="stylesheet" href="<?= base_url('assets/landing/flags.css') ?>">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.0/css/all.css" integrity="sha384-aOkxzJ5uQz7WBObEZcHvV5JvRW3TUc2rNPA7pe3AwnsUohiw1Vj2Rgx2KSOkF5+h" crossorigin="anonymous">
        <link rel="stylesheet" href="<?= base_url('assets/landing/font-awesome-animation.min.css') ?>">
        <style type="text/css">
            .link-click{cursor:pointer}.specs-left{width:44%;margin-right:7%;float:left}.specs-right{width:49%;float:left}.specs-center{width:100%;text-align:center;float:left;margin-top:30px}@media(max-width:600px){.specs-left,.specs-right{width:100%}}.specs-list span:first-child{font-weight:bold;width:45%;display:inline-block}.specs-list span:nth-child(2){display:inline-block;color:#333}.specs-list ul{padding:0}.specs-list ul li{list-style:none}.card-title{padding:1rem}.card-image{display:block;margin-left:auto;margin-right:auto}.post-box{cursor:pointer;position:relative}.post-title{position:absolute;bottom:3px;padding-right:15px;padding-left:15px}.post-text{color:#fff!important;text-decoration:none}.post-content img{max-width:100%}.responad{width:320px;height:100px}@media(min-width:800px){.responad{width:468px;height:60px}}@media(min-width:992px){.responad{width:468px;height:60px}}@media(min-width:1200px){.responad{width:728px;height:90px}}@media(min-width:1600px){.responad{width:970px;height:90px}}.card-header-help{background:linear-gradient(60deg,#696766,#a8a8a8);color:#fff}.card-header-primary{background:linear-gradient(60deg,#4a154b,#8f2c91);color:#fff!important}.card-header-facebook{background:linear-gradient(60deg,#36c,#03f);color:#fff!important}.h1-title{font-size:1rem;color:#fff!important;display:inline-block}.show-more:before{height:55px;margin-top:-45px;content:-webkit-gradient(linear,0% 100%,0% 0,from(#fff),color-stop(.2,#fff),to(rgba(255,255,255,0)));display:block}.show-more a{width:94px;display:block;overflow:hidden;position:relative;line-height:27px;font-size:14px;color:#f60;margin:10px auto;cursor:pointer;font-weight:600}.hidden-div{height:210px;overflow:hidden}body>tr:hover {background-color: #ff767a!important;color:#fff!important;}
        </style>
        <?= getSiteMeta('analytics')['analytics']?>
        <!-- <script async src="https://www.googletagmanager.com/gtag/js?id=UA-163898725-1"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            
            gtag('config', 'UA-163898725-1');
        </script>
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <script>
            (adsbygoogle = window.adsbygoogle || []).push({
             google_ad_client: "ca-pub-1839315362497448",
             enable_page_level_ads: true
            });
        </script> -->
    </head>
    <body class="index">
    	<div id="fb-root"></div>
        <div id="admin_panel" style="background-color: #2d0c2e; color: #fff"></div>