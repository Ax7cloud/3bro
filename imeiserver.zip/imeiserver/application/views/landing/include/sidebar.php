<div class="col-md-3 text-center">
	<div class="card no-hover">
		<h4 style="border-bottom: 1px solid #ccc;padding-bottom: 5px;">Recently Added</h4>
		<div class="card-body" style="text-align: left;font-size: 12px;">
			<?php
			foreach(recentPosts(5,$post->postId) as $pst){
				//$post_url = base_url($pst->postSlug);
				$post_url = base_url($pst->model.'/'.$pst->country.'/'.$pst->version);
				echo '<p><a href="'.$post_url.'">'.$pst->postTitle.'</a></p>';
			}
			?>
		</div>
	</div>
	<?php  if($sidebar_ads != '') { echo '<div class="col-md-12 ads-area" style="margin: 20px 0;">'.$sidebar_ads.'</div>'; } ?>
</div>