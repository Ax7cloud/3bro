<?php 
$this->load->view(LANDING_PATH.'/include/header');
$this->load->view(LANDING_PATH.'/include/nav');
$this->load->view(LANDING_PATH.'/'.$request);
$this->load->view(LANDING_PATH.'/include/sidebar');
$this->load->view(LANDING_PATH.'/include/footer');
?>