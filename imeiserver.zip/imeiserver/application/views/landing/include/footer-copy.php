</div>
<?php  if($footer_ads != '') { echo '<div class="col-md-12 ads-area" style="margin: 20px 0;">'.$footer_ads.'</div>'; } ?>
</div></div>
<footer class="footer-1 bg-light text-dark">
    <div class="container">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-center">
            <div class="links">
                <ul class="footer-menu list-unstyled d-flex flex-row text-center text-md-left">
                    <li><a href="<?= base_url() ?>">Home</a></li>
                    <?php
                    foreach(getActivePages('footer') as $pagee){
                        echo '<li><a href="'.base_url($pagee->slugUrl).'">'.$pagee->pageTitle.'</a></li>';
                    }
                    ?>
                    <li><a href="<?= base_url('contact-us') ?>">Contact us</a></li>
                    <li><a href="<?= base_url('sitemap.xml') ?>" target="_blank" style="display: none;">Sitemap</a></li>
                </ul>
            </div>
            <div class="social mt-4 mt-md-0">
                <a class="twitter btn btn-outline-primary btn-icon" href="<?= $this->web->twitterLink ?>" target="_blank">
                <i class="fab fa-twitter"></i>
                <span class="sr-only">View our twitter fan page</span>
                </a>
                <a class="facebook btn btn-outline-primary btn-icon" href="<?= $this->web->facebookLink ?>" target="_blank">
                <i class="fab fa-facebook"></i>
                <span class="sr-only">View our Facebook Fan Page
                <span>
                </a>
                <a class="github btn btn-outline-primary btn-icon" href="<?= $this->web->youtubeLink ?>" target="_blank">
                <i class="fab fa-youtube"></i>
                <span class="sr-only">View our Youtube channel</span>
                </a>
            </div>
        </div>
        <div class="copyright text-center">
            <a href="//www.dmca.com/Protection/Status.aspx?ID=cb22f566-1797-4059-a78a-3ca5e24054cb" title="DMCA.com Protection Status" class="dmca-badge"> <img src ="https://images.dmca.com/Badges/dmca-badge-w100-5x1-07.png?ID=cb22f566-1797-4059-a78a-3ca5e24054cb"  alt="DMCA.com Protection Status" /></a>
            <hr />
            <p class="small">&copy; 2020, <span class="text-danger"><i class="faa-pulse animated faa-fast fas fa-heart"></i></span> <?= $this->web->webTitle ?></p>
        </div>
    </div>
</footer>
<script src="https://images.dmca.com/Badges/DMCABadgeHelper.min.js"> </script>
<script  type="text/javascript">
    $(document).ready(function(){
    });
    
    var baseurl = "<?= base_url() ?>";
    $('#autocomplete540').autocomplete({
        minChars: 2,
        serviceUrl: baseurl+'ajax/model',
        dataType: 'json',
        autoSelectFirst: true,
        onSelect: function (suggestion) {
            //if (suggestion.data) window.location.href= baseurl +'post/'+ suggestion.postId +'/'+ suggestion.data;
            if (suggestion.data) window.location.href= baseurl + suggestion.data;
        }
    });
</script>
<div id="block-mess"><p class="blockedparagraph"> <span style="font-weight: bold;font-size: 1rem;">I am so sorry! :(</span><br><br> But please disable AdBlock. Because <b><?= $this->web->webTitle ?></b> is Free. But we need money to keep server running. Ads is only benifit for keep SamFirms running Free. Thank you!<br></p> <a class="blockedlink" style="color:#fff;" onclick="recheckAdblock()"><i class="far fa-thumbs-up"></i> Understood. I turned it off</a>  <a class="blockhowto" href="javascript:void(0)" onclick="dismissAlert()" style="color:#fff;"><i class="far fa-frown"></i> I do not want to help</a></div>
<div class="holder"></div>
<div id="cookie-msg" style="position: fixed; bottom: 0px; width: 100%; text-align: center; padding: 30px 50px; background-color: rgb(34, 34, 34); color: white; font-size: 16px;display: none;"><span class="msg">This website uses cookies. By using this website you consent to our use of these cookies. For more information visit our <a href="<?= base_url('privacy-policy') ?>" style="color: rgb(255, 255, 0); text-decoration: underline;">Privacy Policy</a>. <a href="" class="btn-aceptar" style="color: white; text-decoration: none; padding: 5px 10px; border-radius: 5px; background-color: rgb(242, 169, 32); font-size: 11px;">Got It!</a></span></div>

<style type="text/css">#block-mess{display:none;width:365px;position:fixed;top:0;right:0;border-radius:0 0 0 8px;text-align:center;background-color:#6c5ce7;z-index:1000;padding:20px 0;-webkit-box-shadow:-4px 4px 13px 2px rgba(0,0,0,.49);-moz-box-shadow:-4px 4px 13px 2px rgba(0,0,0,.49);box-shadow:-4px 4px 13px 2px rgba(0,0,0,.49)}.blockedparagraph{padding:0 10px;text-align:center;color:#fff;font-family:Roboto,arial,sans-serif;font-size:.9rem;cursor:default}.blockedlink{border-style:solid;border-width:0;cursor:pointer;font-family:"Helvetica Neue",Helvetica,Roboto,Arial,sans-serif;font-weight:400;line-height:normal;margin:0 auto 1rem;position:relative;text-decoration:none;text-align:center;-webkit-appearance:none;border-radius:0;padding-top:.5rem;padding-right:.5rem;padding-bottom:.5rem;padding-left:.5rem;font-size:1rem;background-color:#636e72;border-color:#007095;color:#fff;transition:background-color .3s ease-out;display:block;width:200px}.blockedlink:hover{background-color:#007095;color:#fff}.blockhowto{color:#ccc;font-family:Roboto,arial,sans-serif;font-size:.9rem;text-decoration:underline}.blockhowto:hover{color:#ccc;font-family:Roboto,arial,sans-serif;font-size:.9rem}.bnud{position:fixed;top:0;left:0;right:0;bottom:0;width:100%;height:100%;background-color:#000;opacity:.6;padding:0;margin:0;z-index:998}.howtomessage{display:none;width:400px;height:auto;top:0;position:fixed;right:0;background-color:#fff;font-family:arial,sans-serif;font-size:14px;cursor:default;z-index:1001;-webkit-box-shadow:-4px 4px 13px 2px rgba(0,0,0,.49);-moz-box-shadow:-4px 4px 13px 2px rgba(0,0,0,.49);box-shadow:-4px 4px 13px 2px rgba(0,0,0,.49)}.howtoheading{color:#ed4337;font-size:15px;padding-top:10px;padding-left:15px}.host{text-decoration:underline;font-size:15px;padding:0}.mmlogohowto{width:200px;display:block;margin:0 auto;padding-top:10px}.blockertype{padding:1px 15px}.howtobullets li{color:#ed4337}.howtobullets li span{color:#555}.x{color:#000;text-decoration:none;position:absolute;z-index:1002;top:15px;right:15px}.pagination a {color: black;float: left;padding: 8px 16px;text-decoration: none;}.pagination .active {background-color: #4CAF50;color: white;border-radius: 5px;}.pagination .active a{color: #fff !important;}.pagination i:hover:not(.active) {background-color: #ddd;border-radius: 5px;}.index .page-hero .credits {margin-top: 3rem;}tbody>tr:hover {background-color: #ff767a!important;color: #fff!important;}tbody>tr:hover a{color: #fff!important;}.card-header-info {background: linear-gradient(1deg, #153e4b8a, #62a47a4d);color: #fff!important;}</style>
<style type="text/css">
@media only screen and (max-width: 600px) {
  .display-2 {font-size: 2.5rem}
}
.btn, .navbar .navbar-nav>a.btn {margin: 0.2rem;}
.img-flag {display: inline-block;height: 15px;margin-right: 5px;width: 20px;}
#customers {font-family: Arial, Helvetica, sans-serif;border-collapse: collapse;width: 100%;}
#customers td, #customers th {border: 1px solid #ddd;padding: 8px;}
#customers tr:nth-child(even){background-color: #f2f2f2;}
#customers tr:hover {background-color: #ddd;}
#customers th {padding-top: 12px;padding-bottom: 12px;text-align: left;background-color: #04AA6D;color: white;width: 150px;}
.breadcrumb .breadcrumb-item a{text-decoration: none !important;border-bottom: none !important;}
</style>
<script type="text/javascript">function dismissAlert(){jQuery("p.blockedparagraph").fadeOut(0,function(){jQuery(this).html("I am so sad about that! <i class='far fa-sad-cry'></i>").fadeIn(800)}),jQuery(".blockedlink").hide(),jQuery(".blockhowto").hide(),jQuery(".holder").removeClass("bnud"),setCookie("_dAB","true",1),window.setTimeout(function(){jQuery("#block-mess").hide()},2e3)}function recheckAdblock(){jQuery("p.blockedparagraph").fadeOut(0,function(){jQuery(this).html("Thank you! <i class='fas fa-heart'></i>").fadeIn(800)}),jQuery(".blockedlink").hide(),jQuery(".blockhowto").hide(),jQuery(".holder").removeClass("bnud"),setTimeout(location.reload.bind(location),2e3)}function hideHowTo(){jQuery("div.howtomessage").hide()}function showHowTo(){var e=document.location.hostname;jQuery("div.howtomessage").show(),jQuery(".host").text(e)}function setCookie(e,o,t){var i="";if(t){var n=new Date;n.setTime(n.getTime()+24*t*60*60*1e3),i="; expires="+n.toUTCString()}document.cookie=e+"="+(o||"")+i+"; path=/"}function getCookie(e){for(var o=e+"=",t=document.cookie.split(";"),i=0;i<t.length;i++){for(var n=t[i];" "==n.charAt(0);)n=n.substring(1,n.length);if(0==n.indexOf(o))return n.substring(o.length,n.length)}return null}jQuery(document).ready(function(e){if(a=getCookie("_dAB"),"true"!=a){var o=e("<div />");o.html("&nbsp;"),o.addClass("adsbox"),e("body").append(o),window.setTimeout(function(){o.is(":hidden")&&(e("#block-mess").show(),e(".holder").addClass("bnud")),o.remove()},200)}});</script>

<script type="text/javascript">
$(document).ready(function(){
    if($('.move-to-area').length != null && $('.move-to-area').length != undefined && $('.move-to-area').length > 0){
        $('html, body').animate({ scrollTop: $(".move-to-area").offset().top }, 300);
    }
    $('.link-click').click(function(){
        var vhref = $(this).attr('data-link');
        if(vhref != '' && vhref != undefined && vhref != null){
            window.location.href = vhref;
        }
    });
    $('.move-to-area h1').addClass('card-header card-header-primary');
    $('.move-to-area h2').addClass('card-header card-header-help');
    $('.move-to-area h3').addClass('card-header card-header-info');

    if(getCookie('_cAcpt') != 'true'){
        console.log(getCookie('_cAcpt'));
        console.log('here');
        $('#cookie-msg').show();
    }
});
$('.comment-form').submit(function(e){
    var btnObj = $(this).find('button[type="submit"]');
    btnObj.prop('disabled',true).text('Please wait....');

    $.ajax({
        type: 'post',
        data: $(this).serialize(),
        url: window.location.href,
        success: function(response){
            btnObj.prop('disabled',false).text('Submit');
            if($.trim(response) != 'success'){
                alert(response);
            }else{
                $('.comment-fields').val('').text('');
                $('.success-comment').show();
                setTimeout(function(){
                    $('.success-comment').hide();
                },5000);
            }
        },
        error: function(err){
            btnObj.prop('disabled',false).text('Submit');
            alert('Unable to process your request');
        }
    });
    e.preventDefault();
});
$('.contact-us-form').submit(function(e){
    e.preventDefault();
    var btnObj = $(this).find('button[type="submit"]');
    btnObj.prop('disabled',true);

    $.ajax({
        type: 'post',
        data: $(this).serialize(),
        url: '<?= base_url('home/contactUs') ?>',
        success: function(response){
            btnObj.prop('disabled',false);
            if($.trim(response) != 'success'){
                alert(response);
            }else{
                alert('thank you for reaching us, we\'ll contact your asap.');
                setTimeout(function(){
                    window.location.reload();
                },1500);
            }
        },
        error: function(err){
            btnObj.prop('disabled',false);
        }
    });
});
$('.btn-aceptar').click(function(){
    setCookie("_cAcpt","true",1);
    setTimeout(function(){
        $('#cookie-msg').hide();
    },1000);

    return false;
});
</script>
</body>
</html>