<?php 
$webLogo = base_url().'resource/thq-logo.jpg';
$favicon = base_url().'resource/favicon.ico';
if(file_exists('resource/'.$this->web->webLogo)){
    $webLogo = base_url().'resource/'.$this->web->webLogo;
}
if(file_exists('resource/'.$this->web->webLogofavicon)){
    $favicon = base_url().'resource/'.$this->web->favicon;
}
$webLogo = $webLogo.'?v='.time();
$favicon = $favicon.'?v='.time();
?>
<nav class="navbar navbar-expand-lg  navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="<?= base_url() ?>"><img src="<?= $webLogo ?>" alt="<?= $this->web->webTitle ?>" class="mr-2" height="30"> <?= $this->web->webTitle ?></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown-17" aria-controls="navbarNavDropdown-7" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse text-center" id="navbarNavDropdown-17">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link faa-parent animated-hover" href="<?php // echo base_url() ?>">
                        <i class="faa-horizontal fas fa-home"></i> Home
                    </a>
                </li>
                <li class="nav-item">
<a href="https://t.me/samfirms_com" class="btn btn-light" target="_blank" rel="noreferrer"><i class="fab fa-telegram-plane"></i> Join our Telegram</a>
</li>
                <li class="nav-item mx-2">
                    <?php
                    foreach(getActivePages('header') as $pagee){
                        echo '<a class="btn btn-light" href="'.base_url($pagee->slugUrl).'">'.$pagee->pageTitle.'</a>';
                    }
                    ?>
                </li>
                <!-- <li class="nav-item">
                    <a class="nav-link faa-parent animated-hover" href="<?php // echo base_url('latest') ?>">
                        <i class="faa-bounce fas fa-arrow-up"></i> Lastest
                    </a>
                </li>
                &nbsp;
                <a class="btn btn-primary" href="<?php // echo base_url('login') ?>">Login</a>&nbsp;
                <a class="btn btn-success" href="<?php // echo base_url('register') ?>">Register</a> -->
            </ul>
        </div>
    </div>
</nav>
<div class="page-hero bg-primary text-white" id="banner">
    <div class="bubbles d-none d-md-block">
        <div class="bubble bubble-3 bubble-top-right bg-warning rotate-bubble"></div>
        <div class="bubble bubble-5 bg-info rotate-bubble"></div>
        <div class="bubble bubble-6 bubble-bottom-right bg-danger rotate-bubble"></div>
        <div class="bubble bubble-7 bubble-top-right bg-success rotate-bubble"></div>
        <div class="bubble bubble-9 bg-warning rotate-bubble"></div>
        <div class="bubble bubble-12 bubble-top-right bg-success rotate-bubble"></div>
        <div class="bubble bubble-13 bubble-top-left bg-success rotate-bubble"></div>
        <div class="circle circle-1 bg-light rotate-circle"></div>
        <div class="circle circle-2 bg-success rotate-circle"></div>
        <div class="circle circle-3 bg-danger rotate-circle"></div>
        <div class="circle circle-4 bg-info rotate-circle"></div>
        <div class="circle circle-7 bg-warning rotate-circle"></div>
        <div class="circle circle-8 bg-white rotate-circle"></div>
        <div class="circle circle-10 bg-danger rotate-circle"></div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-8  offset-lg-2 text-center">
                <div class="title">
                    <h3 class="display-2 text-white"><?= $this->web->headerSearchTitle ?></h3>
                    <h4 class="text-white"><?= $this->web->headerSearchDescription ?></h4>
                    <input style="font-weight: bold;" class="form-control form-control-lg flex-grow-1 mr-2" id="autocomplete540" placeholder="Enter device name or model code">
                    <div id="selction-ajax"></div>
                </div>
                <div class="credits">
                    <p class="text-white mb-0 small"><span class="text-danger"><i class="faa-pulse animated faa-fast fas fa-heart"></i></span> <?= $this->web->webTitle ?></p>
                </div>
                <?php
                /*$getCategoreisWithSlug = getCategoreisWithSlug();
                if(count($getCategoreisWithSlug) > 0){
                    echo '<div class="credits">';
                    foreach($getCategoreisWithSlug as $catt){
                        echo '<a href="'.base_url('category/'.$catt->catSlug).'"><span class="badge badge-pill badge-info" style="margin: 5px;">'.$catt->category.'</span></a>';
                    }
                    echo '</div>';
                }*/
                ?>
            </div>
        </div>
    </div>
</div>
<div class="intro bg-light" style="padding: 1rem 0;">
<?php if($header_ads != '') {
    echo '<div class="container"><div class="col-md-12 ads-area" style="margin: 20px 0;">'.$header_ads.'</div></div>';
}?>
<div class="container">
    <div class="row">