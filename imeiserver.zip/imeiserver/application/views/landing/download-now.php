<?php
$downloadButton = @json_decode($post->downloadButton,true);
$goToPostLink = base_url($post->postSlug);
?>
<div class="col-md-9 move-to-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h3 class="main-head">Preparing download link</h3>
                <div class="card no-hover">
                    <div class="card-body">
                        <?php 
                        if($post->separateAds == 'Yes' && $post->adsContent != ''){
                            echo '<p>'.$post->adsContent.'</p>';
                        }
                        if($post->downloadButton != '' && count($downloadButton) > 0 && $downloadButton['buttonUrl'] != ''){
                        ?>
                        <div class="col-md-12 text-center setup-link">
                            <h1 class="timer-count" style="font-size: 82px;">Please wait...</h1>
                        </div>
                        <?php } ?>
                    </div>
                </div>
                <div class="card no-hover">
                    <div class="card-body">
                        <div style=" padding: 0 20px 20px 20px;" class="f-desc">
                            <?php
                            // echo $downrec->pageContent;
                            
                            $pageContent = $downrec->pageContent; 
                            $ext_countries = extractCountry($pageContent);
                            if(count($ext_countries[1]) > 0){
                                foreach($ext_countries[1] as $cnt){
                                    $pageContent = str_replace('{'.strtolower($cnt).'}', '<img class="img-flag" src="'.base_url('assets/img/flags/4x3/'.($cnt).'.svg').'">', $pageContent);
                                }
                            }
                            echo $pageContent;
                            ?>
                        </div>
                    </div>
                    <?php
                    if($post_ads != ''){
                        echo '<div class="col-md-12 ads-area" style="margin: 20px 0;overflow: auto;">'.$post_ads.'</div>';
                    }
                    ?>
                    <div class="col-md-12 text-center setup-link2" style="margin-bottom: 15px;"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<style type="text/css">
</style>
<script type="text/javascript">
var startfrom = 16;
var timer = null;
setTimeout(function(){
    startTimer()
},2000);
function startTimer(){
    timer = setInterval(function(){
        if(startfrom == 0){
            clearInterval(timer);
            $('.main-head').text('Link is ready');
            var downloadLinkButton = '<a href="<?= $downloadButton['buttonUrl'] ?>" class="btn btn-success" style="max-width:250px;" onclick="proceedDownload()" target="_blank">Download Now</a>';
            $('.setup-link2').html(downloadLinkButton);
            $('.setup-link').html('');

            $('html, body').animate({ scrollTop: $(".setup-link2").offset().top }, 700);
        }else{
            startfrom = startfrom - 1;
            var vt = startfrom;
            if(parseFloat(vt) < 10){
                vt = '0'+vt;
            }
            if(startfrom != '00'){
                $('.timer-count').text(vt);
            }
            //setTimer();
        }
    },1200);
}
function proceedDownload(){
    setTimeout(function(){
        window.location.href = '<?= $goToPostLink ?>';
    },1000);
}
</script>