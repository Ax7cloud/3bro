<div class="col-md-9">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card no-hover">
                    <div class="card-body">
                        <div style=" padding: 0 20px 20px 20px;  overflow-y: scroll; max-height: 300px;" class="f-desc">
                            <?= $homePage->pageContent ?>
                        </div>
                    </div>
                </div>
                <hr />
                <?php
                foreach($record as $rec){
                    $post_link = base_url('post/'.$rec->postId.'/'.strtolower(url_title($rec->postTitle, 'dash', true)));
                    echo '<div class="card" style="margin-bottom: 15px;">';
                        echo '<div class="card-body">';
                            echo '<h2><a href="'.$post_link.'">'.$rec->postTitle.'</a></h2>';
                            echo '<p>'.word_limiter(strip_tags($rec->postContent),50).'</p>';
                            if(count(@json_decode($rec->tags)) > 0){
                                echo '<p>';
                                    foreach(@json_decode($rec->tags,true)as $tag){
                                        echo '<label class="badge badge-pill badge-success" style="margin:1px;">'.$tag.'</label>';
                                    }
                                echo '</p>';
                            }
                            echo '<p><a href="'.$post_link.'" class="btn btn-primary">Read More</a></p>';
                        echo '</div>';
                    echo '</div>';
                }
                ?>
            </div>
        </div>
    </div>
</div>
<style type="text/css">
.post-time{float: right;font-size: 14px;}
</style>