<div class="col-md-9">
    <div class="container">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url() ?>">Home</a></li>
            <?php
            if($this->uri->segment(3) == '' || $this->uri->segment(2) == null){
                echo '<li class="breadcrumb-item active">'.$this->uri->segment(2).'</li>';
            }else{
                echo '<li class="breadcrumb-item"><a href="'.base_url().'firmware/'.$this->uri->segment(2).'">'.$this->uri->segment(2).'</a></li>';
                echo '<li class="breadcrumb-item active">'.$this->uri->segment(3).'</li>';
            }
            ?>
        </ol>
        <div class="row">
            <div class="col-md-12">
                <div class="card no-hover">
                    <div class="card-header card-header-primary">
                        <h1 class="h1-title"><i class="fas fa-download"></i> &nbsp;Samsung Firmware lastest files updated</h1>
                    </div>
                    <div class="card-body">
                        <table class="table table-hover table-responsive w-100 d-block d-md-table small">
                            <thead>
                                <tr>
                                    <th>Device</th>
                                    <th>Model</th>
                                    <th>CSC</th>
                                    <th>Version</th>
                                    <th>Bit</th>
                                    <th>OS</th>
                                    <th>File Type</th>
                                    <!-- <th>Category</th> -->
                                    <th style="width: 15%;">Updated</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                foreach($record as $rec){
                                    //$post_link = base_url($rec->postSlug);
                                    //$post_link = base_url($rec->model.'/'.$rec->country.'/'.$rec->version);
                                    $post_link = postUrl($rec);
                                    echo '<tr class="text-dark bg-light link-click" data-link="'.$post_link.'">';
                                        //echo '<td>'.$rec->postTitle.'</td>';
                                        echo '<td style="color:#611f6a">'.($rec->device != '' ? $rec->device : $rec->postTitle).'</td>';
                                        echo '<td>'.$rec->model.'</td>';
                                        echo '<td><img class="img-flag" src="'.base_url('assets/img/flags/4x3/'.(strtolower(worldCountries()[$rec->country]['code'])).'.svg').'"><br>'.($rec->csc != '' ? $rec->csc : $rec->country).'</td>';
                                        echo '<td>'.$rec->version.'</td>';
                                        echo '<td class="text-success font-weight-bold">'.$rec->bit.'</td>';
                                        echo '<td class="text-success font-weight-bold">'.$rec->os.'</td>';
                                        echo '<td>'.$rec->fileType.'</td>';
                                        /*echo '<td>';
                                            if(count(@json_decode($rec->category)) > 0){
                                                foreach(@json_decode($rec->category,true) as $cat){
                                                    $catar = getCategory($cat);
                                                    echo '<a href="'.base_url('category/'.$catar->catSlug).'"><label class="badge badge-pill badge-success" style="margin:1px;">'.$catar->category.'</a></label>';
                                                }
                                            }
                                        echo '</td>';*/
                                        echo '<td>'.date('M d, Y',strtotime($rec->modifiedTime)).'</td>';
                                    echo '</tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                        <?= '<ul class="pagination">'.$this->pagination->create_links().'</ul>'; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<style type="text/css">
.post-time{float: right;font-size: 14px;}
</style>