<div class="col-md-9">
    <div class="container move-to-area">
        <div class="row">
            <div class="col-md-12">
                <!-- <h3><?= $pagee->pageTitle ?></h3> -->
                <div class="card no-hover">
                    <div class="card-body">
                        <?php
                        //echo $pagee->pageContent;

                        $pageContent = $pagee->pageContent; 
                        $ext_countries = extractCountry($pageContent);
                        if(count($ext_countries[1]) > 0){
                            foreach($ext_countries[1] as $cnt){
                                $pageContent = str_replace('{'.strtolower($cnt).'}', '<img class="img-flag" src="'.base_url('assets/img/flags/4x3/'.($cnt).'.svg').'">', $pageContent);
                            }
                        }
                        echo $pageContent;
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<style type="text/css">
.post-time{float: right;font-size: 14px;}
</style>