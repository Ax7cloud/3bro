<?php
$num1 = rand(0,19);
$num2 = rand(0,19);
$qanswer = $num1 + $num2;
$this->session->set_userdata('seq-ans',$qanswer);
?>
<div class="col-md-9">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h3 class="card-header card-header-info">Contact US</h3>
                <div class="card no-hover">
                    <div class="card-body">
                        <form action="" class="form-horizontal contact-us-form" method="post">
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" name="name" class="form-control" placeholder="Your name ..." required="">
                            </div>
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" name="email" class="form-control" placeholder="Your email ..." required="">
                            </div>
                            <div class="form-group">
                                <label>Phone Number</label>
                                <input type="text" name="phoneNumber" class="form-control" placeholder="Your phone number ...">
                            </div>
                            <div class="form-group">
                                <label>Website</label>
                                <input type="text" name="website" class="form-control" placeholder="Your website ...">
                            </div>
                            <div class="form-group">
                                <label>Description</label>
                                <textarea name="description" cols="30" rows="5" class="form-control" required="" placeholder="Question/Message ..."></textarea>
                            </div>
                            <div class="form-group">
                                <label for="password">Security Question</label>
                                <div class="input-group">
                                    <span class="input-group-addon" style="vertical-align: middle;background: #f8f8f8;padding: 5px 25px;border-radius: 3px;">
                                        <?= $num1.'&nbsp;&nbsp;+&nbsp;&nbsp;'.$num2  ?>&nbsp;&nbsp; = &nbsp;&nbsp; 
                                    </span>
                                    <input class="form-control comment-fields" type="text" name="sanswer" style="text-align: center;" required="">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>&nbsp;</label>
                                <button class="btn btn-primary btn-block" type="submit">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<style type="text/css">
.post-time{float: right;font-size: 14px;}
.form-group {margin-bottom: 0;}
</style>
<script type="text/javascript">
</script>