<?php
$num1 = rand(0,19);
$num2 = rand(0,19);
$qanswer = $num1 + $num2;

$this->session->set_userdata('seq-ans',$qanswer);
$downloadButton = @json_decode($post->downloadButton,true);

$pageLike = getvisitorLike($post->postId,$this->input->ip_address());

$post_link = base_url($post->postSlug);
?>
<div class="col-md-9">
    <div class="container move-to-area">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url() ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url().'firmware/'.$post->model ?>"><?= $post->model ?></a></li>
            <li class="breadcrumb-item"><a href="<?= base_url().'firmware/'.$post->model.'/'.$post->country ?>"><?= $post->country ?></a></li>
            <li class="breadcrumb-item active"><?= $post->version ?></li>
        </ol>
        <div class="row">
            <div class="col-md-12">
                <h3><?= $post->postTitle ?></h3>
                <div class="card no-hover">
                    <div class="card-body">
                        <?php
                        echo $qanswer;
                        $postContent = $post->postContent;
                        $contentData = innerTableContent();
                        $contentData = str_replace('{post-device}',trim($post->device),$contentData);
                        $contentData = str_replace('{post-model}',trim($post->model),$contentData);
                        $contentData = str_replace('{post-product}','SAMSUNG',$contentData);
                        $contentData = str_replace('{post-filename}',trim($post->fileType),$contentData);
                        $contentData = str_replace('{post-apversion}',trim($post->version),$contentData);
                        $contentData = str_replace('{post-os}',trim($post->os),$contentData);
                        $contentData = str_replace('{post-cscversion}',trim($post->cscversion),$contentData);
                        $cntry = strtolower($this->countries[$post->country]['code']);
                        $contentData = str_replace('{post-csc}','<img class="img-flag" src="'.base_url('assets/img/flags/4x3/'.($cntry).'.svg').'">',$contentData);
                        $contentData = str_replace('{post-bit}',trim($post->bit),$contentData);
                        $contentData = str_replace('{post-uploaddate}',substr($post->createdTime,0,10),$contentData);

                        $postContent = str_replace('{shortcode-device-data}',$contentData,$postContent);

                        $ext_countries = extractCountry($postContent);
                        if(count($ext_countries[1]) > 0){
                            foreach($ext_countries[1] as $cnt){
                                $postContent = str_replace('{'.strtolower($cnt).'}', '<img class="img-flag" src="'.base_url('assets/img/flags/4x3/'.($cnt).'.svg').'">', $postContent);
                            }
                        }
                        echo $postContent;
                        if($post->separateAds == 'Yes' && $post->adsContent != ''){
                            echo '<div class="col-md-12 ads-area" style="margin: 20px 0;overflow: auto;">'.$post->adsContent.'</div>';
                        }
                        if($post_ads != ''){
                            echo '<div class="col-md-12 ads-area" style="margin: 20px 0;overflow: auto;">'.$post_ads.'</div>';
                        }
                        if($post->downloadButton != '' && count($downloadButton) > 0 && $downloadButton['buttonUrl'] != ''){
                            echo '<form action="'.base_url('download-now').'" method="post">';
                                echo '<input type="hidden" name="postId" value="'.$post->postId.'">';
                                echo '<p class="text-center">';
                                    echo '<button class="btn btn-primary" type="submit" style="max-width:300px;">'.$downloadButton['buttonText'].'</button>';
                                    echo '<br><small>Downloaded <b>'.($post->downloadCount + 1000).'</b> times</small>';
                                echo '</p>';
                            echo '</form>';
                        }else{
                            echo '<p class="text-center"><button class="btn btn-danger" style="max-width:300px;" disabled=""><span class="uploading-area">Firmware Uploading...</span></button></p>';
                        }
                        ?>
                    </div>
                </div>
                <div style="margin-top: 10px;text-align: center;">
                    <a class="btn-post-action btn btn-outline-primary btn-icon <?= $pageLike == 'dislike' ? 'active' : ''; ?>" href="javascript:;" style="float: left;" onclick="postAction(this,'dislike',<?= $post->postId ?>)">
                        <i class="fa fa-thumbs-down"></i>
                        <span class="sr-only">Dislike this post</span>
                    </a>
                    <!-- social medial  -->
                    <a class="btn btn-info btn-icon" href="http://www.facebook.com/sharer.php?u=<?= $post_link ?>" target="_blank" title="Share on facebook">
                        <i class="fab fa-facebook"></i>
                        <span class="sr-only">Share on facebook</span>
                    </a>
                    <a class="btn btn-success btn-icon" href="http://twitter.com/share?url=<?= $post_link ?>&text=<?= $post->postTitle ?>&hashtags=<?= $this->web->webTitle ?>" target="_blank" title="Share on twitter">
                        <i class="fab fa-twitter"></i>
                        <span class="sr-only">Share on twitter</span>
                    </a>
                    <a class="btn btn-danger btn-icon" href="http://pinterest.com/pin/create/button/?url=<?= $post_link ?>" target="_blank" title="Share on pinterest">
                        <i class="fab fa-pinterest"></i>
                        <span class="sr-only">Share on pinterest</span>
                    </a>

                    <a class="btn-post-action btn btn-outline-primary btn-icon <?= $pageLike == 'like' ? 'active' : ''; ?>" href="javascript:;" style="float: right;" onclick="postAction(this,'like',<?= $post->postId ?>)">
                        <i class="fa fa-thumbs-up"></i>
                        <span class="sr-only">Like this post</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <?php if($post->commentStatus == 'Enabled'){ ?>
        <div class="container" style="padding-top: 10px; padding-bottom: 10px;">
            <h3 style="border-bottom: 1px solid #ccc;padding-bottom: 10px;">Comments</h3>
            <div class="row">
                <div class="col-md-12">
                    <?php
                    $comments = getPostComments($post->postId);
                    if(count($comments) > 0){
                        echo '<ul class="comments">';
                            foreach($comments as $comm){
                                echo '<li>';
                                    echo '<p style="margin-bottom: 5px;">';
                                        echo '<b>'.$comm->fromName.'</b>';
                                        echo '<small style="float: right;">'.timeAgo($comm->commentTime).'</small>';
                                    echo '</p>';
                                    echo '<p style="margin-bottom: 5px;">'.$comm->comment.'</p>';
                                echo '</li>';
                            }
                        echo '</ul>';
                    }
                    ?>
                </div>
            </div>
        </div>
        <div class="container" style="padding-top: 10px; padding-bottom: 10px;">
            <div class="row">
                <div class="col-md-12">
                    <p class="alert alert-success success-comment" style="display: none;">Thank you for commenting. Your review will be posted after approval</p>
                    <div class="card no-hover">
                        <div class="col-md-12">
                            <form action="" class="comment-form" method="post">
                                <input type="hidden" name="postId" value="<?= $post->postId ?>">
                                <div class="form-group">
                                    <label>Name </label>
                                    <input type="text" name="fromName" class="form-control comment-fields" placeholder="Your name ...." required="">
                                </div>
                                <div class="form-group">
                                    <label>Email</label>
                                    <input type="email" name="fromEmail" class="form-control comment-fields" placeholder="Your email ..." required="">
                                </div>
                                <div class="form-group">
                                    <label>Comment</label>
                                    <textarea name="comment" class="form-control comment-fields" rows="5" required=""></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="password">Security Question</label>
                                    <div class="input-group">
                                        <span class="input-group-addon" style="vertical-align: middle;background: #f8f8f8;padding: 5px 25px;border-radius: 3px;">
                                            <?= $num1.'&nbsp;&nbsp;+&nbsp;&nbsp;'.$num2  ?>&nbsp;&nbsp; = &nbsp;&nbsp; 
                                        </span>
                                        <input class="form-control comment-fields" type="text" name="sanswer" style="text-align: center;" required="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button class="btn btn-primary btn-block" type="submit">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>
</div>
<style type="text/css">
.post-time{float: right;font-size: 14px;}
.comments {list-style: none;padding: 5px;}
.comments li {padding: 5px 0;border-bottom: 1px solid #cccc;margin: 10px 0;}
</style>
<script type="text/javascript">
function postAction(obj,type,postId){
    if($(obj).hasClass('active')){
        return false;
    }
    var xmlhttp;
    if (window.XMLHttpRequest) {
        xmlhttp=new XMLHttpRequest();
    }else{
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }

    xmlhttp.onreadystatechange=function() {
        if(xmlhttp.readyState == 4 && xmlhttp.status == 200){
            //xmlhttp.responseText
        }
    }

    $('.btn-post-action').removeClass('active');
    $(obj).addClass('active');

    var params = 'postId='+postId+'&type='+type;
    xmlhttp.open("POST","<?= base_url('landingPages/postAction'); ?>",true);
    xmlhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xmlhttp.send(params);
}
</script>