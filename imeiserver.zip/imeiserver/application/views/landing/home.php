<div class="col-md-9">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card no-hover">
                    <div class="card-body">
                        <div style=" padding: 0 20px 20px 20px;  overflow-y: scroll; max-height: 300px;" class="f-desc">
                            <?= $homePage->pageContent ?>
                        </div>
                    </div>
                </div>

                <hr />
                <div class="card no-hover">
                    <div class="card-header card-header-primary">
                        <h1 class="h1-title"><i class="fas fa-download"></i> &nbsp;Samsung firmware lastest models added</h1>
                    </div>
                    <div class="card-body">
                        <?php
                        foreach(recentModels() as $mod){
                            echo '<a class="btn btn-warning btn-sm mt-1 mr-1" href="'.base_url('firmware/'.$mod->model).'">'.$mod->model.' / '.$mod->device.'</a>';
                        }
                        ?>
                    </div>
                </div>
                <?= $this->ads['latest_model_ads'] != '' ? '<div class="col-md-12 ads-area" style="margin: 20px 0;overflow: auto;">'.$this->ads['latest_model_ads'].'</div>' : '' ?>
                <hr />
                <div class="card no-hover">
                    <div class="card-header card-header-primary">
                        <h1 class="h1-title"><i class="fas fa-download"></i> &nbsp;Samsung latest Firmware files added</h1>
                    </div>
                    <div class="card-body">
                        <table class="table table-hover table-responsive w-100 d-block d-md-table small">
                            <thead>
                                <tr>
                                    <th>Device</th>
                                    <th>Model</th>
                                    <th>CSC</th>
                                    <th>Version</th>
                                    <th>Bit</th>
                                    <th>OS</th>
                                    <th>File Type</th>
                                    <!-- <th>Category</th> -->
                                    <th style="width: 15%;">Updated</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                foreach($record as $rec){
                                    //$post_link = base_url($rec->postSlug);
                                    //$post_link = base_url($rec->model.'/'.$rec->country.'/'.$rec->version);
                                    $post_link = postUrl($rec);
                                    echo '<tr class="text-dark bg-light link-click" data-link="'.$post_link.'">';
                                        //echo '<td>'.$rec->postTitle.'</td>';
                                        echo '<td style="color:#611f6a">'.($rec->device != '' ? $rec->device : $rec->postTitle).'</td>';
                                        echo '<td>'.$rec->model.'</td>';
                                        echo '<td><img class="img-flag" src="'.base_url('assets/img/flags/4x3/'.(strtolower(worldCountries()[$rec->country]['code'])).'.svg').'"><br>'.($rec->csc != '' ? $rec->csc : $rec->country).'</td>';
                                        echo '<td>'.$rec->version.'</td>';
                                        echo '<td class="text-success font-weight-bold">'.$rec->bit.'</td>';
                                        echo '<td class="text-success font-weight-bold">'.$rec->os.'</td>';
                                        echo '<td>'.$rec->fileType.'</td>';
                                        /*echo '<td>';
                                            if(count(@json_decode($rec->category)) > 0){
                                                foreach(@json_decode($rec->category,true) as $cat){
                                                    $catar = getCategory($cat);
                                                    echo '<a href="'.base_url('category/'.$catar->catSlug).'"><label class="badge badge-pill badge-success" style="margin:1px;">'.$catar->category.'</a></label>';
                                                }
                                            }
                                        echo '</td>';*/
                                        echo '<td>'.date('M d, Y',strtotime($rec->modifiedTime)).'</td>';
                                    echo '</tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                        <?= '<ul class="pagination">'.$this->pagination->create_links().'</ul>'; ?>
                    </div>
                </div>
                <hr />
                <blockquote class="blockquote text-right">
                    <p class="mb-0">We always strive to make ImeiServer better.If you found any error, bug. Please send us email report to <a href="<?= base_url('contact-us') ?>" target="_blank"><span class="badge badge-pill badge-warning">HERE</span></a></p>
                </blockquote>
            </div>
        </div>
    </div>
</div>
<style type="text/css">
.post-time{float: right;font-size: 14px;}
</style>
