<?php 

class AdminPanel extends CI_Controller{
	public function __construct(){
		parent::__construct();
		date_default_timezone_set(defaultTimeZone());

		$this->app = $this->session->userdata('fw');

		if(!isLoggedIn()){
		    redirect(ADMIN_PATH);
		}

		$this->load->model('home_model');

		if($_GET['record']){
			$this->page_record = $_GET['record'];
		}else{
			$this->page_record = '0';
		}
	}

	public function dashboard(){
		$data['comments'] = $this->home_model->viewComments('',5,0);
		$data['states'] = $this->home_model->getVisitorStates();
		$data['request'] = 'dashboard';
		$this->load->view(ADMIN_PATH.'/include/content',$data);
	}

	public function web(){
		if(isset($_POST['save'])){
			$webArray = @json_decode(@file_get_contents('resource/web-setting.info'),true);
			$webTitle = trim($this->input->post('webTitle'));
			$webArray['webTitle'] = $webTitle;
			
			$webArray['metaTitle'] = trim($this->input->post('metaTitle'));
			$webArray['metaDesription'] = trim($this->input->post('metaDesription'));
			$webArray['metaTags'] = @implode(',', $this->input->post('metaTags'));
			$webArray['headerSearchTitle'] = trim($this->input->post('headerSearchTitle'));
			$webArray['headerSearchDescription'] = trim($this->input->post('headerSearchDescription'));

			$webArray['twitterLink'] = trim($this->input->post('twitterLink'));
			$webArray['facebookLink'] = trim($this->input->post('facebookLink'));
			$webArray['youtubeLink'] = trim($this->input->post('youtubeLink'));

			/* website logo */
			if(isset($_FILES['webLogo']) && $_FILES['webLogo']['name'] != ''){
				$fileName = $_FILES['webLogo']['name'];
				$ext = @end(@explode('.', $fileName));
				if(!in_array(strtolower($ext), array('png','jpg','jpeg'))){
					exit('Allowed image format (PNG/JPG/JPEG)');
				}else{
					$newLogo = 'resource/logo.'.$ext;
					@move_uploaded_file($_FILES['webLogo']['tmp_name'], $newLogo);
					$webArray['webLogo'] = 'logo.'.$ext;
				}
			}
			/* website favicon */
			if(isset($_FILES['favicon']) && $_FILES['favicon']['name'] != ''){
				$fileName = $_FILES['favicon']['name'];
				$ext = @end(@explode('.', $fileName));
				if(strtolower($ext) != 'ico'){
					exit('Allowed favicon format (ICO)');
				}else{
					$newFavicon = 'resource/favicon.ico';
					@move_uploaded_file($_FILES['favicon']['tmp_name'], $newFavicon);
					$webArray['favicon'] = 'favicon.ico';
				}
			}
			if(!file_exists('resource/web-setting.info')){
				$handle = @fopen('resource/web-setting.info', 'w');
				@fclose($handle);
			}
			@file_put_contents('resource/web-setting.info', @json_encode($webArray));
			exit('1');
		}else{
			$data['record'] = @json_decode(@file_get_contents('resource/web-setting.info'));
			$data['request'] = 'web-setting';
			$this->load->view(ADMIN_PATH.'/include/content',$data);
		}
	}

	public function adsSetting(){
		if($this->input->is_ajax_request()){
			$header_ads = trim($this->input->post('header_ads'));
			$sidebar_ads = trim($this->input->post('sidebar_ads'));
			$footer_ads = trim($this->input->post('footer_ads'));
			$post_ads = trim($this->input->post('post_ads'));
			$latest_model_ads = trim($this->input->post('latest_model_ads'));

			$adsArr = array('header_ads' => $header_ads, 'sidebar_ads' => $sidebar_ads, 'footer_ads' => $footer_ads, 'post_ads' => $post_ads, 'latest_model_ads' => $latest_model_ads);

			setSiteMeta('ads',$adsArr);
			exit('1');
		}else{
			$data['ads'] = getSiteMeta('ads');
			$data['request'] = 'ads-settings';
			$this->load->view(ADMIN_PATH.'/include/content',$data);
		}
	}

	public function analyticsSetting(){
		if($this->input->is_ajax_request()){
			$analytics = trim($this->input->post('analytics'));

			$dataArr = array('analytics' => $analytics);

			setSiteMeta('analytics',$dataArr);
			exit('1');
		}else{
			$data['record'] = getSiteMeta('analytics');
			$data['request'] = 'analytics-settings';
			$this->load->view(ADMIN_PATH.'/include/content',$data);
		}
	}

	public function comments(){
		if($this->input->method() == 'post'){
			$this->session->set_userdata('comments',$_POST);
		}
		if($this->input->get('reset') == 'true'){
			$this->session->unset_userdata('comments');
		}

		$total_rows = $this->home_model->viewComments();
		$this->load->library('pagination');
		$config = pagination_initialize();
		$config['base_url'] = base_url(ADMIN_PATH.'/comments');
		$config['total_rows'] = $data['total_rows'] = $total_rows;
		$config['per_page'] = 50;

		$this->pagination->initialize($config);
		$data['record'] = $this->home_model->viewComments('',$config['per_page'],$this->page_record);

		$data['request'] = 'view-comments';
		$this->load->view(ADMIN_PATH.'/include/content',$data);
	}

	public function profile(){
		if($this->input->method() == 'post' && $this->input->is_ajax_request()){
			$name = trim($this->input->post('name'));
			$phoneNumber = trim($this->input->post('phoneNumber'));
			$email = trim($this->input->post('email'));
			$username = trim($this->input->post('username'));
			$password = trim($this->input->post('password'));
			$cnicNumber = trim($this->input->post('cnicNumber'));

			if($name == ''){
				exit('Please enter name');
			}
			if($phoneNumber == '' || (strlen($phoneNumber) < 10 || is_numeric($phoneNumber) == false)){
				exit('Please enter valid phone number');
			}
			if($password != ''){
				if(strlen($password) < 5){
					exit('Password lenght can not be less than 6 characters');
				}
			}

			if($username == '' || strlen($username) < 4){
				exit('Please enter username');
			}
			$isValid = $this->home_model->isValidUsername($username,$this->app->userId);
			if($isValid == false){
				exit('This username is already been used');
			}

			$dataArr = array('name' => $name, 'phoneNumber' => $phoneNumber, 'email' => $email, 'username' => $username);
			if($password != ''){
				$dataArr['password'] = md5($password);
			}
			$this->db->set($dataArr)->where('userId',$this->app->userId)->update('users');
			exit('1');
		}
		$data['uuser'] = getUser($this->app->userId);
		$data['request'] = 'profile';
		$this->load->view(ADMIN_PATH.'/include/content',$data);
	}

	public function viewCMS(){
		$data['record'] = $this->home_model->getCMSRecord();
		$data['request'] = 'view-cms';
		$this->load->view(ADMIN_PATH.'/include/content',$data);
	}

	public function addEditCMS(){
		$pageId = trim($this->uri->segment(4));
		if(trim($this->uri->segment(3)) == 'edit'){
			$page = $this->home_model->getCMSPage($pageId);
			if($page == 0){
				redirect('error-404');
			}
			$data['page'] = $page;
		}

		$data['request'] = 'add-edit-cms';
		$this->load->view(ADMIN_PATH.'/include/content',$data);
	}

	public function savePage(){
		if(!$this->input->is_ajax_request()){
			exit('Directory access is forbidden');
		}
		$pageId = trim($this->input->post('pageId'));
		$pageTitle = trim($this->input->post('title'));
		$status = trim($this->input->post('status'));
		$position = trim($this->input->post('position'));
		$pageContent = trim($this->input->post('template'));
		$metaTitle = trim($this->input->post('metaTitle'));
		$metaDesription = trim($this->input->post('metaDesription'));
		$metaTags = @implode(',', $this->input->post('metaTags'));

		$pageId = $pageId == '' || $pageId == null ? '0' : $pageId;

		if(trim($pageTitle) == ''){
			exit('Please enter page title/name');
		}

		if(trim($pageContent) == ''){
			exit('Please enter page content');
		}
		if($pageId != '0'){
			$slugUrl = url_title($pageTitle, 'dash', true);
			$isExist = $this->home_model->isPageSlugExist($slugUrl,$pageId);
		}

		$dataQry = array('pageTitle' => $pageTitle, 'pageContent' => $pageContent, 'status' => $status, 'metaTitle' => $metaTitle, 'metaDesription' => $metaDesription, 'metaTags' => $metaTags, 'position' => $position, 'modifiedTime' => date('Y-m-d H:i:s'));
		$dataQry = array_map(function($v){ return (is_null($v)) ? "" : $v;},$dataQry);
		if($pageId != '0'){
			$this->db->set($dataQry)->where('pageId',$pageId)->update('cms');
		}else{
			$slugUrl = url_title($pageTitle, 'dash', true);
			$isExist = $this->home_model->isPageSlugExist($slugUrl,$pageId);

			$dataQry['slugUrl'] = $slugUrl;
			$dataQry['createdTime'] = date('Y-m-d H:i:s');

			$this->db->set($dataQry)->insert('cms');
			$pageId = $this->db->insert_id();

			if($isExist == true){
				$this->db->set('slugUrl',$pageId.'-'.$slugUrl)->where('pageId',$pageId)->update('cms');
			}
		}

		exit('success');
	}

	public function deletePage(){
		if(!$this->input->is_ajax_request()){
			exit('Directory access is forbidden');
		}
		$pageId = trim($this->input->post('pageId'));

		$this->db->where('pageId',$pageId)->delete('cms');

		exit('success');
	}

	public function viewPosts(){
		if($this->input->get('reset') == 'true'){
			$this->session->unset_userdata('postSearch');
			redirect(ADMIN_PATH.'/posts');
		}
		if($this->input->method() == 'post'){
			$this->session->set_userdata('postSearch',$_POST);
		}
		$total_rows = $this->home_model->viewPosts();
		$this->load->library('pagination');
		$config = pagination_initialize();
		$config['base_url'] = base_url(ADMIN_PATH.'/posts');
		$config['total_rows'] = $data['total_rows'] = $total_rows;
		$config['per_page'] = 50;

		$this->pagination->initialize($config);
		$data['record'] = $this->home_model->viewPosts($config['per_page'],$this->page_record);

		$data['request'] = 'view-posts';
		$this->load->view(ADMIN_PATH.'/include/content',$data);
	}

	public function addEditPost(){
		$postId = trim($this->uri->segment(4));
		if(trim($this->uri->segment(3)) == 'edit'){
			$post = $this->home_model->getSinglePost($postId);
			if($post == 0){
				redirect('error-404');
			}
			$data['post'] = $post;
		}

		$data['getTags'] = getTags();
		$data['getCategoreis'] = getCategoreis();

		$data['request'] = 'add-edit-post';
		$this->load->view(ADMIN_PATH.'/include/content',$data);
	}

	public function savePost(){
		if(!$this->input->is_ajax_request()){
			exit('Directory access is forbidden');
		}
		//print_r($_POST);
		$postId = trim($this->input->post('postId'));
		$postId = $postId == '' || $postId == null ? '0' : $postId;

		$postTitle = trim($this->input->post('title'));
		$postSlug = trim($this->input->post('postSlug'));
		$postContent = trim($this->input->post('template'));
		$commentStatus = trim($this->input->post('commentStatus'));
		$postStatus = trim($this->input->post('postStatus'));
		$sharePost = trim($this->input->post('sharePost')) == 'Yes' ? 'Yes' : 'No';
		$featuredPost = trim($this->input->post('featuredPost')) == 'Yes' ? 'Yes' : 'No';
		$separateAds = trim($this->input->post('separateAds')) == 'Yes' ? 'Yes' : 'No';
		$adsContent = trim($this->input->post('adsContent'));
		$buttonUrl = trim($this->input->post('buttonUrl'));
		$buttonText = trim($this->input->post('buttonText'));
		$version = trim($this->input->post('version'));
		$cscversion = trim($this->input->post('cscversion'));
		$csc = trim($this->input->post('csc'));
		$os = trim($this->input->post('os'));
		$bit = trim($this->input->post('bit'));
		$model = trim($this->input->post('model'));
		$device = trim($this->input->post('device'));
		$isRecentModel = trim($this->input->post('isRecentModel'));
		$fileType = trim($this->input->post('fileType'));

		$metaTitle = trim($this->input->post('metaTitle'));
		$metaDesription = trim($this->input->post('metaDesription'));
		$metaTags = @implode(',', $this->input->post('metaTags'));

		$category = $this->input->post('category');
		$tags = $this->input->post('tags');

		$country = trim($this->input->post('country'));

		$isRecentModel = $isRecentModel == 'Yes' ? 'Yes' : 'No';

		if($postTitle == ''){
			exit('Please enter post title');
		}
		if($postContent == ''){
			exit('Please enter post content');
		}
		if($version == ''){
			exit('Please enter version');
		}
		if($cscversion == ''){
			exit('Please enter csc version');
		}
		if($device == ''){
			exit('Please enter device');
		}
		if($model == ''){
			exit('Please enter model');
		}
		if($separateAds == 'Yes' && $adsContent == ''){
			exit('Please enter ads content');
		}
		if($separateAds == 'No'){
			$adsContent = '';
		}

		$getTags = getTags();
		$getCategoreis = getCategoreis();
		foreach($tags as $tag){
			if(!in_array($ta, $getTags)){
				setTag($tag);
			}
		}
		foreach($category as $cat){
			if(!in_array($cat, $getCategoreis)){
				setCategory($cat);
			}
		}

		if($postSlug == ''){
			$postSlug = url_title($postTitle, 'dash', true);
		}

		$isExist = $this->home_model->isPostSlugExist($postSlug,$postId);

		$downloadButton = array();
		if($buttonUrl != ''){
			if(filter_var($buttonUrl, FILTER_VALIDATE_URL) == false){
				exit('Enter valid download button url');
			}
			$downloadButton = array('buttonUrl' => $buttonUrl, 'buttonText' => $buttonText);
		}

		$dataQry = array('postTitle' => $postTitle, 'postContent' => $postContent, 'postSlug' => $postSlug, 'sharePost' => $sharePost, 'commentStatus' => $commentStatus, 'postStatus' => $postStatus, 'featuredPost' => $featuredPost, 'separateAds' => $separateAds, 'adsContent' => $adsContent, 'category' => @json_encode($category), 'tags' => @json_encode($tags), 'metaTitle' => $metaTitle, 'metaDesription' => $metaDesription, 'metaTags' => $metaTags, 'modifiedTime' => date('Y-m-d H:i:s'), 'downloadButton' => @json_encode($downloadButton), 'version' => $version, 'cscversion' => $cscversion, 'os' => $os, 'bit' => $bit, 'device' => $device, 'model' => $model, 'fileType' => $fileType, 'isRecentModel' => $isRecentModel, 'country' => $country, 'csc' => $csc);
		$dataQry = array_map(function($v){ return (is_null($v)) ? "" : $v;},$dataQry);
		if($postId != '0'){
			$this->db->set($dataQry)->where('postId',$postId)->update('posts');
		}else{
			$dataQry['userId'] = $this->app->userId;
			$dataQry['createdTime'] = date('Y-m-d H:i:s');
			$this->db->set($dataQry)->insert('posts');
			$postId = $this->db->insert_id();
		}

		if($isExist == true){
			$this->db->set('postSlug',$postSlug.'-'.$postId)->where('postId',$postId)->update('posts');
		}

		exit('success');
	}

	public function deletePost(){
		if(!$this->input->is_ajax_request()){
			exit('Directory access is forbidden');
		}
		$postId = trim($this->input->post('postId'));

		$this->db->where('postId',$postId)->delete('posts');

		exit('success');
	}

	public function approveComment(){
		if(!$this->input->is_ajax_request()){
			exit('Directory access is forbidden');
		}
		$commentId = trim($this->input->post('commentId'));
		$postId = trim($this->input->post('postId'));

		$this->db->set('status','Approved')->where('commentId',$commentId)->update('post_comments');

		$this->db->set('commentCount','commentCount + 1',false)->where('postId',$postId)->update('posts');

		exit('success');
	}

	public function viewSingleComment(){
		$commentId = trim($this->uri->segment(3));
		$comment = $this->home_model->getSingleComment($commentId);
		if($comment == '0' || $comment->status == 'Pending'){
			redirect(ADMIN_PATH.'/comments');
		}

		$data['comment'] = $comment;
		$data['commentrecord'] = $this->home_model->getCommentThreads($commentId);

		$data['request'] = 'view-comment-threads';
		$this->load->view(ADMIN_PATH.'/include/content',$data);
	}

	public function postComment(){
		if(!$this->input->is_ajax_request()){
			exit('Directory access is forbidden');
		}
		$commentId = trim($this->input->post('commentId'));
		$commentText = trim($this->input->post('comment'));
		if($commentText == ''){
			exit('Please enter comment reply');
		}

		$comment = $this->home_model->getSingleComment($commentId);

		$commentQry = array('userId' => $this->app->userId, 'fromComment' => $commentId, 'postId' => $comment->postId, 'ipAddress' => $this->input->ip_address(), 'comment' => $commentText, 'status' => 'Approved', 'commentTime' => date('Y-m-d H:i:s'));

		$this->db->set($commentQry)->insert('post_comments');

		$this->db->set('replied','true')->where('commentId',$commentId)->update('post_comments');

		exit('success');
	}

	public function deleteComment(){
		if(!$this->input->is_ajax_request()){
			exit('Directory access is forbidden');
		}
		$commentId = trim($this->input->post('commentId'));

		$comment = $this->home_model->getSingleComment($commentId);

		$this->db->where('commentId',$commentId)->delete('post_comments');

		if($comment->status == 'Approved'){
			$this->db->set('commentCount','commentCount - 1',false)->where('postId',$postId)->update('posts');
		}

		exit('success');
	}

	public function getPosts(){
		if(!$this->input->is_ajax_request()){
			exit('Directory access is forbidden');
		}
		$search = trim($this->input->get('search'));

		$this->db->select('postId, postTitle')->from('posts')->like('postTitle',$search);
		$record = $this->db->get()->result();

		$return = array();
		foreach($record as $rec){
			$return[] = array('id' => $rec->postId, 'text' => $rec->postTitle);
        }
        echo @json_encode($return);
	}

	public function viewContactUS(){
		$total_rows = $this->home_model->viewContactUS();
		$this->load->library('pagination');
		$config = pagination_initialize();
		$config['base_url'] = base_url(ADMIN_PATH.'/contact-us');
		$config['total_rows'] = $data['total_rows'] = $total_rows;
		$config['per_page'] = 50;

		$this->pagination->initialize($config);
		$data['record'] = $this->home_model->viewContactUS($config['per_page'],$this->page_record);

		$data['request'] = 'view-contact-us';
		$this->load->view(ADMIN_PATH.'/include/content',$data);
	}

	public function viewSingleContactUS(){
		$contactUsId = trim($this->uri->segment(3));
		$cus = $this->home_model->getContactUS($contactUsId);
		if($cus == 0){
			redirect('error-404');
		}
		if($cus->status == '0'){
			$this->db->set('status','1')->where('contactUsId',$contactUsId)->update('contact_us');
		}
		$data['cus'] = $cus;

		$data['request'] = 'view-single-contact-us';
		$this->load->view(ADMIN_PATH.'/include/content',$data);
	}

	public function deleteContactUS(){
		if(!$this->input->is_ajax_request()){
			exit('Directory access is forbidden');
		}
		$contactUsId = trim($this->input->post('contactUsId'));

		$this->db->where('contactUsId',$contactUsId)->delete('contact_us');

		exit('success');
	}

}
?>
