<?php 
if(substr_count(@$_SERVER['HTTP_HOST'], 'localhost') == 0){
	include 'application/third_party/oauth2/vendor/autoload.php';
}
class Home extends CI_Controller{
	public function __construct(){
		parent::__construct();
		date_default_timezone_set(defaultTimeZone());

		$this->app = $this->session->userdata('fw');

		$this->load->model('home_model');

		if($_GET['record']){
			$this->page_record = $_GET['record'];
		}else{
			$this->page_record = '0';
		}
	}

	public function fwIndex(){
		if($this->session->userdata('fw')){
			redirect(ADMIN_PATH.'/dashboard');
		}else{
			redirect(ADMIN_PATH.'/login');
		}
	}

	public function noRecordFound(){
		echo $this->load->view('page-notfound',array(),true);
	}

	public function doLogin(){
		if(isLoggedIn()){
			redirect(ADMIN_PATH);
		}
		if(isset($_POST['submit'])){
			extract(array_map('trim', $_POST));
			if($this->session->userdata('seq-ans') != $this->input->post('sanswer')){
				$this->session->set_userdata('error','Security answer is not valid');
				unset($_POST['submit']);
				$this->doLogin();
			}else{
				$record = $this->home_model->doLogin();
				if($record != '0'){
					$this->session->set_userdata('fw',$record);

					$hashToken = encrypt($record->userId.'::'.time());
					$this->input->set_cookie('rememberme',$hashToken,2592000);
					$this->db->set('hashToken',md5($hashToken))->where('userId',$record->userId)->update('users');

					$this->input->set_cookie('loginUsername',$record->username,2592000);
					redirect(ADMIN_PATH);
				}else{
					$this->session->set_userdata('error','Username / Password Invalid');
					unset($_POST['submit']);
					$this->doLogin();
				}
			}
		}else{
			if($this->session->userdata('fw')){
				redirect(ADMIN_PATH);
			}else{
				$this->load->view(ADMIN_PATH.'/login-page');
			}
		}
	}

	public function doLogout(){
		delete_cookie('rememberme');
		$this->session->unset_userdata('fw');
		$this->session->sess_destroy();
		session_unset();
		session_destroy();
		redirect(ADMIN_PATH);
	}

	public function notfound(){
		$this->load->view('error-404');
	}

	public function sitemap(){
		error_reporting(1);
		$urls = array(); 

		$item = new stdClass();
		$item->loc = base_url();
		$item->lastmod = date('Y-m-d', time());
		$item->changefreq = 'monthly';
		$item->priority = '1';
		$urls[] = $item;

		$record = $this->home_model->viewPosts(1000000);
		foreach($record as $rec){ if($rec->postStatus == 'Active'){
			$item = new stdClass();
			$item->loc = base_url().$rec->postSlug;
			$item->lastmod = date('Y-m-d', strtotime($rec->modifiedTime));
			$item->changefreq = 'daily';
			$item->priority = '0.8';
			$urls[] = $item;
		}}

		$xml = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8" ?><urlset/>');
		$xml->addAttribute('xmlns', 'http://www.sitemaps.org/schemas/sitemap/0.9');
		
		foreach ($urls as $url) {
			$child = $xml->addChild('url');
			$child->addChild('loc', strtolower($url->loc));
			if (isset($url->lastmod)) $child->addChild('lastmod', $url->lastmod);
			if (isset($url->changefreq)) $child->addChild('changefreq', $url->changefreq);
			if (isset($url->priority)) $child->addChild('priority', number_format($url->priority, 1));
		}

		$this->output->set_content_type('application/xml')->set_output($xml->asXml());
	}

	public function contactUs(){
		if(!$this->input->is_ajax_request()){
			exit('Directory access is forbidden');
		}
		$name = trim($this->input->post('name'));
		$email = trim($this->input->post('email'));
		$phoneNumber = trim($this->input->post('phoneNumber'));
		$website = trim($this->input->post('website'));
		$description = trim($this->input->post('description'));
		$sanswer = trim($this->input->post('sanswer'));

		$qanswer = $this->session->userdata('seq-ans');

		if($phoneNumber == '' || strlen($phoneNumber) < 9 || !is_numeric($phoneNumber)){
			exit('Enter valid phone number');
		}
		if($website != ''){
			if(substr_count($website, 'https://') == 0 && substr_count($website, 'http://') == 0 && substr_count($website, 'www.') == 0){
				exit('Please enter valid website address');
			}
		}

		if($qanswer != $sanswer){
			exit('Security question answer is not valid');
		}

		$dataQry = array('fromName' => $name, 'fromEmail' => $email, 'phoneNumber' => $phoneNumber, 'website' => $website, 'description' => $description, 'createdTime' => date('Y-m-d H:i:s'), 'ipAddress' => $this->input->ip_address());

		$this->db->set($dataQry)->insert('contact_us');

		exit('success');
	}

	public function authDrive(){
		$client_id = '63486905486-784p38h4j8rt8kbddtcl0css74n3ppt2.apps.googleusercontent.com';
		$client_secret = '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';

		if($_GET['code']){
			if(!file_exists('resource/auth-resource.info')){
				$handle = @fopen('resource/auth-resource.info', 'w');
				@fclose($handle);
			}

			$oauth2 = array('client_id' => $client_id, 'client_secret' => $client_secret);
			$redirect_uri = 'https://samfirms.com/home/authDrive';
			try {
	            $provider = new \League\OAuth2\Client\Provider\GenericProvider([
	                'clientId'                => $client_id,   
	                'clientSecret'            => $client_secret,
	                'redirectUri'             => $redirect_uri, 
	                'urlAuthorize'            => 'https://www.googleapis.com/oauth2/v4/authorize',
	                'urlAccessToken'          => 'https://www.googleapis.com/oauth2/v4/token',
	                'urlResourceOwnerDetails' => ''
	            ]);

	            $accessToken = $provider->getAccessToken('authorization_code', ['code' => $_GET['code']]);

	            $access_token = $accessToken->getToken();
	            $tokenExpire = $accessToken->getExpires();
	            $refresh_token = $accessToken->getRefreshToken();
	            $hasExpired = ($accessToken->hasExpired() ? 'expired' : 'not expired');

	            $oauth2['hasError'] = 'false';
	            $oauth2['access_token'] = $access_token;
	            $oauth2['expires_in'] = $tokenExpire;
	            $oauth2['timeIn'] = time();
	            $oauth2['refresh_token'] = $refresh_token;
	            $isSuccess = true;
	        }catch(\League\OAuth2\Client\Provider\Exception\IdentityProviderException $e){
	        	 $oauth2['hasError'] = 'true';
	        }
	        @file_put_contents('resource/auth-resource.info', @json_encode($oauth2));
		}else{
			$redirect_uri = 'https://samfirms.com/home/authDrive';
			$url = 'https://accounts.google.com/o/oauth2/v2/auth/oauthchooseaccount?redirect_uri='.$redirect_uri.'&prompt=consent&response_type=code&client_id='.$client_id.'&scope=https://www.googleapis.com/auth/drive&access_type=offline';
			header('Location: '.$url);
		}
	}

	public function ping(){
		//@mail('mu.cp15@gmail.com','testing','testing');
		$oauth2 = @json_decode(@file_get_contents('resource/auth-resource.info'),true);
		$timeDiff = $oauth2['expires_in'] - $oauth2['timeIn'];
		$return = 'false';
		if(time() > ($oauth2['timeIn'] + $timeDiff)){
			$oauth2 = $this->refreshAuth();
			$return = 'true';
		}
		echo $return;
		//echo json_encode($oauth2);
	}

	public function refreshAuth(){
		$client_id = '63486905486-784p38h4j8rt8kbddtcl0css74n3ppt2.apps.googleusercontent.com';
		$client_secret = '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';

		$oauth2 = @json_decode(@file_get_contents('resource/auth-resource.info'),true);
		$redirect_uri = 'https://samfirms.com/home/authDrive';
		try {
            $provider = new \League\OAuth2\Client\Provider\GenericProvider([
                'clientId'                => $oauth2['client_id'],   
                'clientSecret'            => $oauth2['client_secret'],
                'redirectUri'             => $redirect_uri, 
                'urlAuthorize'            => 'https://www.googleapis.com/oauth2/v4/authorize',
                'urlAccessToken'          => 'https://www.googleapis.com/oauth2/v4/token',
                'urlResourceOwnerDetails' => ''
            ]);

            $accessToken = $provider->getAccessToken('refresh_token', ['refresh_token' => $oauth2['refresh_token']]);

            $access_token = $accessToken->getToken();
            $tokenExpire = $accessToken->getExpires();
            $refresh_token = $accessToken->getRefreshToken();
            if($refresh_token == '' || $refresh_token == null){
            	$refresh_token = $oauth2['refresh_token'];
            }
            $hasExpired = ($accessToken->hasExpired() ? 'expired' : 'not expired');

            $oauth2['hasError'] = 'false';
            $oauth2['access_token'] = $access_token;
            $oauth2['expires_in'] = $tokenExpire;
            $oauth2['timeIn'] = time();
            $oauth2['refresh_token'] = $refresh_token;
            $isSuccess = true;
        }catch(\League\OAuth2\Client\Provider\Exception\IdentityProviderException $e){
        	 $oauth2['hasError'] = 'true';
        }
        //echo '<pre>'; print_r($oauth2);exit;
        @file_put_contents('resource/auth-resource.info', @json_encode($oauth2));

        return $oauth2;
	}

	public function downloadnow(){
		$postId = trim($_REQUEST['id']);
		$token = trim($_REQUEST['token']);

		$gSiteSecret = '6LfqvUcdAAAAAOjMC9ogsm35YUoNJro0qdYJ6ims';

		$response = json_decode(file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".$gSiteSecret."&response=".$token."&remoteip=".$_SERVER['REMOTE_ADDR']), true);
		if($response['success'] == false){
		    $dataArr = array('code' => 604);
		}else{
			$oauth2 = @json_decode(@file_get_contents('resource/auth-resource.info'),true);
			$timeDiff = $oauth2['expires_in'] - $oauth2['timeIn'];
			if(time() > ($oauth2['timeIn'] + $timeDiff)){
				$oauth2 = $this->refreshAuth();
			}
			$access_token = $oauth2['access_token'];

			if($oauth2['hasError'] == 'false'){
				$postd = $this->home_model->getSinglePost($postId);
				$code = 404;
				$fileName = '';
				$url = '';
				if($postd != '0'){
					$code = 200;
					$fileName = 'firmware-'.$postd->model.'-'.$postd->country.'-'.$postd->version.'.zip';
					$downloadButton = @json_decode($postd->downloadButton,true);
					$urlArr = explode('/',$downloadButton['buttonUrl']);
					$count = count($urlArr);
					$url = $urlArr[($count-2)];
					//$url = '1h_TNIfj6jgih5q9yfD42k1GjrPrj915I';
				}
				$dataArr = array('code' => $code, 'access_token' => $access_token, 'url' => $url, 'filename' => $fileName);

				$this->db->set('downloadCount','downloadCount + 1',false)->where('postId',$postId)->update('posts');
			}else{
				$dataArr = array('code' => 602);
			}
		}
		echo @json_encode($dataArr);

	}
}
?>
