<?php 

class LandingPages extends CI_Controller{
	public function __construct(){
		parent::__construct();
		date_default_timezone_set(defaultTimeZone());

		$this->app = $this->session->userdata('fw');

		$this->web = @json_decode(@file_get_contents('resource/web-setting.info'));

		$this->load->model('home_model');

		$this->load->helper('text');

		if($_GET['record']){
			$this->page_record = $_GET['record'];
		}else{
			$this->page_record = '0';
		}

		$this->ads = getSiteMeta('ads');

		$this->countries = worldCountries();

		setVisitor($this->input->ip_address());
	}

	public function index(){
		$homePage = getPageByArea('home');

		$total_rows = $this->home_model->getRecentPosts();
		$this->load->library('pagination');
		$config = pagination_initialize();
		$config['base_url'] = base_url();
		$config['total_rows'] = $data['total_rows'] = $total_rows;
		$config['per_page'] = 15;

		$this->pagination->initialize($config);
		$data['record'] = $this->home_model->getRecentPosts($config['per_page'],$this->page_record);

		$data['header_ads'] = $this->ads['header_ads'];
		$data['sidebar_ads'] = $this->ads['sidebar_ads'];
		$data['footer_ads'] = $this->ads['footer_ads'];
		$data['meta_tags'] = $homePage->metaTags;
		$data['meta_title'] = $homePage->metaTitle;
		$data['meta_description'] = $homePage->metaDesription;
		$data['web_title'] = $homePage->metaTitle.' - '.$this->web->webTitle;

		$data['homePage'] = $homePage;
		$data['request'] = 'home';
		$this->load->view(LANDING_PATH.'/include/content',$data);
	}

	public function postSearch(){
		$query = trim($this->input->get('query'));

		$this->db->select('*')->from('posts');
		$this->db->group_start();
			$this->db->like('model',$query)->or_like('device',$query);
		$this->db->group_end();
		$this->db->group_by('model');
		$record = $this->db->get();

		$return = array('suggestions' => array());
		foreach($record->result() as $rec){
			$ptitle = $rec->model != '' ? $rec->model.' / '.$rec->device : $rec->postTitle;
			//$slugUrl = $rec->postSlug;
			$slugUrl = 'firmware/'.$rec->model;
			$return['suggestions'][] = array('postId' => $rec->postId, 'data' => $slugUrl, 'value' => $ptitle);
		}

		echo @json_encode($return);
	}

	public function viewPost(){
		$keySub = trim($this->uri->segment(1));
		if($keySub == 'firmware'){
			$model = trim($this->uri->segment(2));
			$country = trim($this->uri->segment(3));
			$version = trim($this->uri->segment(4));
		}else{
			$model = trim($this->uri->segment(1));
			$country = trim($this->uri->segment(2));
			$version = trim($this->uri->segment(3));
		}

		$this->db->select('*')->from('posts')->where('model',$model)->where('country',$country)->where('version',$version);
		$record = $this->db->get();
		//echo $this->db->last_query();exit;
		$postCount = $record->num_rows();
		if($postCount == 0){
			$this->load->view('error-404');
		}else{
			$post = $record->row();
			$this->showPost($post,$postCount);
		}
	}

	public function showPost($post,$postCount){
		if($this->input->is_ajax_request()){
			$postId = trim($this->input->post('postId'));
			$fromName = trim($this->input->post('fromName'));
			$fromEmail = trim($this->input->post('fromEmail'));
			$comment = trim($this->input->post('comment'));
			$sanswer = trim($this->input->post('sanswer'));

			if($fromName == ''){
				exit('Please enter your name');
			}
			if($fromEmail == ''){
				exit('Please enter your email');
			}
			if($comment == ''){
				exit('Please enter your comment');
			}

			if($this->session->userdata('seq-ans') != $sanswer){
				//exit('Security answer is not valid');
			}

			$dataArr = array('postId' => $postId, 'ipAddress' => $this->input->ip_address(), 'fromName' => $fromName, 'fromEmail' => $fromEmail, 'comment' => $comment, 'commentTime' => date('Y-m-d H:i:s'));
			$this->db->set($dataArr)->insert('post_comments');

			exit('success');
		}

		setVisitor($this->input->ip_address(),$post->postId);

		$data['header_ads'] = $this->ads['header_ads'];
		$data['sidebar_ads'] = $this->ads['sidebar_ads'];
		$data['footer_ads'] = $this->ads['footer_ads'];
		$data['post_ads'] = $this->ads['post_ads'];

		$data['meta_tags'] = $post->metaTags;
		$data['meta_title'] = $post->metaTitle;
		$data['meta_description'] = $post->metaDesription;
		$data['web_title'] = $post->postTitle.' - '.$this->web->webTitle;
		if($postCount > 1){
			$data['canonicalTags'] = postUrl($post);
		}

		$data['post'] = $post;
		$data['request'] = 'view-post';
		$this->load->view(LANDING_PATH.'/include/content',$data);
	}

	public function contactUs(){
		$homePage = getPageByArea('home');

		$data['header_ads'] = $this->ads['header_ads'];
		$data['sidebar_ads'] = $this->ads['sidebar_ads'];
		$data['footer_ads'] = $this->ads['footer_ads'];
		$data['meta_tags'] = $homePage->metaTags;
		$data['meta_title'] = $homePage->metaTitle;
		$data['meta_description'] = $homePage->metaDesription;
		$data['web_title'] = 'Contact US - '.$this->web->webTitle;

		//$data['post'] = $post;
		$data['request'] = 'contact-us';
		$this->load->view(LANDING_PATH.'/include/content',$data);
	}

	public function viewPage(){
		$slugUrl = trim($this->uri->segment(1));

		$post = getPostBySlug($slugUrl);
		if(count($post) == 0){
			$pagee = getPageBySlug($slugUrl);
			if(count($pagee) == 0){
				redirect('error-404');
			}

			$data['header_ads'] = $this->ads['header_ads'];
			$data['sidebar_ads'] = $this->ads['sidebar_ads'];
			$data['footer_ads'] = $this->ads['footer_ads'];
			$data['meta_tags'] = $pagee->metaTags;
			$data['meta_title'] = $pagee->metaTitle;
			$data['meta_description'] = $pagee->metaDesription;
			$data['web_title'] = $pagee->pageTitle.' - '.$this->web->webTitle;

			$data['pagee'] = $pagee;
			$data['request'] = 'view-cms-page';
			$this->load->view(LANDING_PATH.'/include/content',$data);
		}else{
			$this->showPost($post,1);
		}
	}

	public function categoryPosts(){
		$homePage = getPageByArea('home');
		
		$catSlug = trim($this->uri->segment(2));
		$cat = getCategory($catSlug);
		if($cat == '0'){
			$this->load->view('error-404');
		}else{
			$total_rows = $this->home_model->getCategoryPosts($cat->category);
			$this->load->library('pagination');
			$config = pagination_initialize();
			$config['base_url'] = base_url().'category/'.$catSlug;
			$config['total_rows'] = $data['total_rows'] = $total_rows;
			$config['per_page'] = 50;

			$this->pagination->initialize($config);
			$data['record'] = $this->home_model->getCategoryPosts($cat->category,$config['per_page'],$this->page_record);

			$data['header_ads'] = $this->ads['header_ads'];
			$data['sidebar_ads'] = $this->ads['sidebar_ads'];
			$data['footer_ads'] = $this->ads['footer_ads'];
			$data['meta_tags'] = $homePage->metaTags;
			$data['meta_title'] = $homePage->metaTitle;
			$data['meta_description'] = $homePage->metaDesription;
			$data['web_title'] = $homePage->metaTitle.' - '.$this->web->webTitle;

			$data['request'] = 'category-posts';
			$this->load->view(LANDING_PATH.'/include/content',$data);
		}
	}

	public function firmwarePosts(){
		$homePage = getPageByArea('home');

		$model = trim($this->uri->segment(2));
		
		$total_rows = $this->home_model->getModelPosts($model);
		$this->load->library('pagination');
		$config = pagination_initialize();
		$config['base_url'] = base_url().'firmware/'.$model;
		$config['total_rows'] = $data['total_rows'] = $total_rows;
		$config['per_page'] = 10;

		$this->pagination->initialize($config);
		$data['record'] = $this->home_model->getModelPosts($model,$config['per_page'],$this->page_record);

		$data['header_ads'] = $this->ads['header_ads'];
		$data['sidebar_ads'] = $this->ads['sidebar_ads'];
		$data['footer_ads'] = $this->ads['footer_ads'];
		$data['meta_tags'] = $homePage->metaTags;
		$data['meta_title'] = $homePage->metaTitle;
		$data['meta_description'] = $homePage->metaDesription;
		$data['web_title'] = $homePage->metaTitle.' - '.$this->web->webTitle;

		$data['request'] = 'model-posts';
		$this->load->view(LANDING_PATH.'/include/content',$data);
	}

	public function downloadNow(){
		$postId = trim($this->input->post('postId'));

		$post = getPost($postId);

		if(count($post) == '0'){
			$this->load->view('error-404');
		}else{
			$this->db->set('downloadCount','downloadCount + 1',false)->where('postId',$postId)->update('posts');
			
			$data['header_ads'] = $this->ads['header_ads'];
			$data['sidebar_ads'] = $this->ads['sidebar_ads'];
			$data['footer_ads'] = $this->ads['footer_ads'];
			$data['post_ads'] = $this->ads['post_ads'];

			$data['meta_tags'] = '';
			$data['meta_title'] = '';
			$data['meta_description'] = '';
			$data['web_title'] = 'Download Now';

			$data['post'] = $post;
			$data['downrec'] = getPageByArea('download');
			$data['request'] = 'download-now';
			$this->load->view(LANDING_PATH.'/include/content',$data);
		}

	}

	public function postAction(){
		$postId = trim($this->input->post('postId'));
		$type = trim($this->input->post('type'));
		$ipAddress = $this->input->ip_address();

		$this->db->select('likeId')->from('post_likes');
		$this->db->where('postId',$postId)->where('ipAddress',$ipAddress);
		$record = $this->db->get();
		if($record->num_rows() == 0){
			$dataArr = array('postId' => $postId, 'type' => $type, 'ipAddress' => $ipAddress, 'likeTime' => date('Y-m-d H:i:s'));
			$this->db->set($dataArr)->insert('post_likes');

			if($type == 'like'){
				$this->db->set('likesCount','likesCount + 1',false)->where('postId',$postId)->update('posts');
			}
		}else{
			$likeId = $record->row()->likeId;

			$dataArr = array('postId' => $postId, 'type' => $type, 'ipAddress' => $ipAddress, 'likeTime' => date('Y-m-d H:i:s'));
			$this->db->where('likeId',$likeId)->set($dataArr)->update('post_likes');
		}

		$this->db->select('likeId')->from('post_likes');
		$this->db->where('postId',$postId)->where('type','like')->where('ipAddress',$ipAddress);
		$likesCount  = $this->db->get()->num_rows();
		

		$this->db->set('likesCount',$likesCount)->where('postId',$postId)->update('posts');
	}

}
?>
