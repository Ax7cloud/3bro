<?php
include 'application/third_party/phpmailer/vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class Mailer {
	public function __construct(){
		$this->obj = &get_instance();
	}

	public function send($toEmail,$subject,$body){
		$webtrAsc = @json_decode(@file_get_contents('resource/web-setting.info'));
		//echo '<pre>'; print_r($this->smtp);exit;
		$fromEmail = 'noreply@wormingtonlegal.com';
		$fromName = $webtrAsc->webTitle;

		$mail = new PHPMailer(true);

		try {
		    $mail->setFrom($fromEmail, $fromName);

		    //Recipients
		    $mail->addAddress($toEmail, $toEmail);

		    // Content
		    $mail->isHTML(true);
		    $mail->Subject = $subject;
		    $mail->Body    = $body;
		    $mail->AltBody = strip_tags($body);

		    $mail->send();
		    $mail->ClearAllRecipients();
		    $return = array('status' => 'success', 'msgId' => $mail->GetLastMessageID());
		} catch (Exception $e) {
			$return = array('status' => 'failed', 'errorMsg' => $mail->ErrorInfo);
		}
		return $return;
	}

}

?>