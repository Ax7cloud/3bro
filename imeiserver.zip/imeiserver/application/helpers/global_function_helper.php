<?php 
//error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');

if(!function_exists('pagination_initialize')){
	function pagination_initialize(){
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['page_query_string'] = true;
		$config['query_string_segment']='record';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a href="javascript:;">';
		$config['cur_tag_close'] = '</a></li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['num_links'] = 5;
		return $config;
	}
}

if(!function_exists('time_zones')){
	function time_zones(){
		//Africa
		$sub_zone = 
		array('Africa/Abidjan','Africa/Accra','Africa/Addis_Ababa','Africa/Algiers','Africa/Asmara','
		Africa/Asmera','Africa/Bamako','Africa/Bangui','Africa/Banjul','Africa/Bissau','
		Africa/Blantyre','Africa/Brazzaville','Africa/Bujumbura','Africa/Cairo','Africa/Casablanca','
		Africa/Ceuta','Africa/Conakry','Africa/Dakar','Africa/Dar_es_Salaam','Africa/Djibouti','
		Africa/Douala','Africa/El_Aaiun','Africa/Freetown','Africa/Gaborone','Africa/Harare','
		Africa/Johannesburg','Africa/Juba','Africa/Kampala','Africa/Khartoum','Africa/Kigali','
		Africa/Kinshasa','Africa/Lagos','Africa/Libreville','Africa/Lome','Africa/Luanda','
		Africa/Lubumbashi','Africa/Lusaka','Africa/Malabo','Africa/Maputo','Africa/Maseru','
		Africa/Mbabane','Africa/Mogadishu','Africa/Monrovia','Africa/Nairobi','Africa/Ndjamena','
		Africa/Niamey','Africa/Nouakchott','Africa/Ouagadougou','Africa/Porto-Novo','Africa/Sao_Tome','
		Africa/Timbuktu','Africa/Tripoli','Africa/Tunis','Africa/Windhoek','America/Adak','America/Anchorage','America/Anguilla','America/Antigua','America/Araguaina','
		America/Argentina/Buenos_Aires','America/Argentina/Catamarca','America/Argentina/ComodRivadavia','America/Argentina/Cordoba','	America/Argentina/Jujuy','
		America/Argentina/La_Rioja','America/Argentina/Mendoza','America/Argentina/Rio_Gallegos','	America/Argentina/Salta','	America/Argentina/San_Juan','
		America/Argentina/San_Luis','	America/Argentina/Tucuman','	America/Argentina/Ushuaia','	America/Aruba','	America/Asuncion','
		America/Atikokan','	America/Atka','	America/Bahia','	America/Bahia_Banderas','	America/Barbados','
		America/Belem','	America/Belize','	America/Blanc-Sablon','	America/Boa_Vista','	America/Bogota
		America/Boise','	America/Buenos_Aires','	America/Cambridge_Bay','	America/Campo_Grande','	America/Cancun','
		America/Caracas','	America/Catamarca','	America/Cayenne','	America/Cayman','	America/Chicago','
		America/Chihuahua','	America/Coral_Harbour','	America/Cordoba','	America/Costa_Rica','	America/Creston','
		America/Cuiaba','	America/Curacao','	America/Danmarkshavn','	America/Dawson','	America/Dawson_Creek','
		America/Denver','	America/Detroit','	America/Dominica','	America/Edmonton','	America/Eirunepe','
		America/El_Salvador','	America/Ensenada','	America/Fort_Wayne','	America/Fortaleza','	America/Glace_Bay','
		America/Godthab','	America/Goose_Bay','	America/Grand_Turk','	America/Grenada','	America/Guadeloupe','
		America/Guatemala','	America/Guayaquil','	America/Guyana','	America/Halifax','	America/Havana','
		America/Hermosillo','	America/Indiana/Indianapolis','	America/Indiana/Knox','	America/Indiana/Marengo','	America/Indiana/Petersburg','
		America/Indiana/Tell_City','	America/Indiana/Vevay','	America/Indiana/Vincennes','	America/Indiana/Winamac','	America/Indianapolis','
		America/Inuvik','	America/Iqaluit','	America/Jamaica','	America/Jujuy','	America/Juneau','
		America/Kentucky/Louisville','	America/Kentucky/Monticello','America/Knox_IN','	America/Kralendijk','	America/La_Paz','
		America/Lima','America/Los_Angeles','	America/Las_Vegas','	America/Louisville','	America/Lower_Princes','	America/Maceio','
		America/Managua','America/Manaus','	America/Marigot','	America/Martinique','	America/Matamoros','
		America/Mazatlan','America/Mendoza','	America/Menominee','	America/Merida','	America/Metlakatla','
		America/Mexico_City','America/Miquelon','	America/Moncton','	America/Monterrey','	America/Montevideo','
		America/Montreal','	America/Montserrat','	America/Nassau','	America/New_York','	America/Nipigon','
		America/Nome','	America/Noronha','	America/North_Dakota/Beulah','	America/North_Dakota/Center','	America/North_Dakota/New_Salem','
		America/Ojinaga','	America/Panama','	America/Pangnirtung','	America/Paramaribo','	America/Phoenix','
		America/Port-au-Prince','	America/Port_of_Spain','	America/Porto_Acre','	America/Porto_Velho','	America/Puerto_Rico','
		America/Rainy_River','	America/Rankin_Inlet','	America/Recife','	America/Regina','	America/Resolute','
		America/Rio_Branco','	America/Rosario','	America/Santa_Isabel','	America/Santarem','	America/Santiago','
		America/Santo_Domingo','	America/Sao_Paulo','	America/Scoresbysund','	America/Shiprock','	America/Sitka','
		America/St_Barthelemy','	America/St_Johns','	America/St_Kitts','	America/St_Lucia','	America/St_Thomas','
		America/St_Vincent','	America/Swift_Current','	America/Tegucigalpa','	America/Thule','	America/Thunder_Bay','
		America/Tijuana','	America/Toronto','	America/Tortola','	America/Vancouver','	America/Virgin','
		America/Whitehorse','	America/Winnipeg','	America/Yakutat','	America/Yellowknife','Antarctica/Casey','	Antarctica/Davis','	Antarctica/DumontDUrville','	Antarctica/Macquarie','	Antarctica/Mawson','
		Antarctica/McMurdo','	Antarctica/Palmer','	Antarctica/Rothera','	Antarctica/South_Pole','	Antarctica/Syowa','
		Antarctica/Vostok','Arctic/Longyearbyen','Asia/Aden','	Asia/Almaty','Asia/Amman','Asia/Anadyr','Asia/Aqtau','
		Asia/Aqtobe','	Asia/Ashgabat','	Asia/Ashkhabad','	Asia/Baghdad','	Asia/Bahrain','
		Asia/Baku','	Asia/Bangkok','	Asia/Beirut','	Asia/Bishkek','	Asia/Brunei','
		Asia/Calcutta','	Asia/Choibalsan','	Asia/Chongqing','	Asia/Chungking','	Asia/Colombo','
		Asia/Dacca','	Asia/Damascus','	Asia/Dhaka','	Asia/Dili','	Asia/Dubai','
		Asia/Dushanbe','	Asia/Gaza','	Asia/Harbin','	Asia/Hebron','	Asia/Ho_Chi_Minh','
		Asia/Hong_Kong','	Asia/Hovd','	Asia/Irkutsk','	Asia/Istanbul','	Asia/Jakarta','
		Asia/Jayapura','	Asia/Jerusalem','	Asia/Kabul','	Asia/Kamchatka','	Asia/Karachi','
		Asia/Kashgar','	Asia/Kathmandu','	Asia/Katmandu','	Asia/Kolkata','	Asia/Krasnoyarsk','
		Asia/Kuala_Lumpur','	Asia/Kuching','	Asia/Kuwait','	Asia/Macao','	Asia/Macau','
		Asia/Magadan','	Asia/Makassar','	Asia/Manila','	Asia/Muscat','	Asia/Nicosia','
		Asia/Novokuznetsk','	Asia/Novosibirsk','	Asia/Omsk','	Asia/Oral','	Asia/Phnom_Penh','
		Asia/Pontianak','	Asia/Pyongyang','	Asia/Qatar','	Asia/Qyzylorda','	Asia/Rangoon','
		Asia/Riyadh','	Asia/Saigon','	Asia/Sakhalin','	Asia/Samarkand','	Asia/Seoul','
		Asia/Shanghai','	Asia/Singapore','	Asia/Taipei','	Asia/Tashkent','	Asia/Tbilisi','
		Asia/Tehran','	Asia/Tel_Aviv','	Asia/Thimbu','	Asia/Thimphu','	Asia/Tokyo','
		Asia/Ujung_Pandang','	Asia/Ulaanbaatar','	Asia/Ulan_Bator','	Asia/Urumqi','	Asia/Vientiane','
		Asia/Vladivostok','	Asia/Yakutsk','	Asia/Yekaterinburg','	Asia/Yerevan','Atlantic/Azores','Atlantic/Bermuda','	Atlantic/Canary','Atlantic/Cape_Verde','Atlantic/Faeroe','
		Atlantic/Faroe','Atlantic/Jan_Mayen','Atlantic/Madeira','Atlantic/Reykjavik','Atlantic/South_Georgia','
		Atlantic/St_Helena','Atlantic/Stanley','Australia/ACT','	Australia/Adelaide','	Australia/Brisbane','	Australia/Broken_Hill','	Australia/Canberra','
		Australia/Currie','	Australia/Darwin','	Australia/Eucla','	Australia/Hobart','	Australia/LHI','
		Australia/Lindeman','	Australia/Lord_Howe','	Australia/Melbourne','	Australia/North','	Australia/NSW','
		Australia/Perth','	Australia/Queensland','	Australia/South','	Australia/Sydney','	Australia/Tasmania','
		Australia/Victoria','	Australia/West','	Australia/Yancowinna','Europe/Amsterdam','	Europe/Andorra','	Europe/Athens','	Europe/Belfast','	Europe/Belgrade','
		Europe/Berlin','	Europe/Bratislava','	Europe/Brussels','	Europe/Bucharest','	Europe/Budapest','
		Europe/Chisinau','	Europe/Copenhagen','	Europe/Dublin','	Europe/Gibraltar','	Europe/Guernsey','
		Europe/Helsinki','	Europe/Isle_of_Man','	Europe/Istanbul','	Europe/Jersey','	Europe/Kaliningrad','
		Europe/Kiev','	Europe/Lisbon','	Europe/Ljubljana','	Europe/London','	Europe/Luxembourg','
		Europe/Madrid','	Europe/Malta','	Europe/Mariehamn','	Europe/Minsk','	Europe/Monaco','
		Europe/Moscow','	Europe/Nicosia','	Europe/Oslo','	Europe/Paris','	Europe/Podgorica','
		Europe/Prague','	Europe/Riga','	Europe/Rome','	Europe/Samara','	Europe/San_Marino','
		Europe/Sarajevo','	Europe/Simferopol','	Europe/Skopje','	Europe/Sofia','	Europe/Stockholm','
		Europe/Tallinn','	Europe/Tirane','	Europe/Tiraspol','	Europe/Uzhgorod','	Europe/Vaduz','
		Europe/Vatican','	Europe/Vienna','	Europe/Vilnius','	Europe/Volgograd','	Europe/Warsaw','
		Europe/Zagreb','	Europe/Zaporozhye','	Europe/Zurich','Indian/Antananarivo','	Indian/Chagos','	Indian/Christmas','	Indian/Cocos','	Indian/Comoro','
		Indian/Kerguelen','	Indian/Mahe','	Indian/Maldives','	Indian/Mauritius','	Indian/Mayotte','
		Indian/Reunion','Pacific/Apia','	Pacific/Auckland','	Pacific/Chatham','	Pacific/Chuuk','	Pacific/Easter','
		Pacific/Efate','	Pacific/Enderbury','	Pacific/Fakaofo','	Pacific/Fiji','	Pacific/Funafuti','
		Pacific/Galapagos','	Pacific/Gambier','	Pacific/Guadalcanal','	Pacific/Guam','	Pacific/Honolulu','
		Pacific/Johnston','	Pacific/Kiritimati','	Pacific/Kosrae','	Pacific/Kwajalein','	Pacific/Majuro','
		Pacific/Marquesas','	Pacific/Midway','	Pacific/Nauru','	Pacific/Niue','	Pacific/Norfolk','
		Pacific/Noumea','	Pacific/Pago_Pago','	Pacific/Palau','	Pacific/Pitcairn','	Pacific/Pohnpei','
		Pacific/Ponape','	Pacific/Port_Moresby','	Pacific/Rarotonga','	Pacific/Saipan','	Pacific/Samoa','
		Pacific/Tahiti','	Pacific/Tarawa','	Pacific/Tongatapu','	Pacific/Truk','	Pacific/Wake','
		Pacific/Wallis','	Pacific/Yap','Brazil/Acre','	Brazil/DeNoronha','	Brazil/East','	Brazil/West','	Canada/Atlantic','
		Canada/Central','	Canada/East-Saskatchewan','	Canada/Eastern','	Canada/Mountain','	Canada/Newfoundland','
		Canada/Pacific','	Canada/Saskatchewan','	Canada/Yukon','	CET','	Chile/Continental','
		Chile/EasterIsland','	CST6CDT','	Cuba','	EET','	Egypt','
		Eire','	EST','	EST5EDT','	Etc/GMT','	Etc/GMT+0','
		Etc/GMT+1','	Etc/GMT+10','	Etc/GMT+11','Etc/GMT+12','	Etc/GMT+2','
		Etc/GMT+3','	Etc/GMT+4','	Etc/GMT+5','Etc/GMT+6','	Etc/GMT+7','
		Etc/GMT+8','	Etc/GMT+9','	Etc/GMT-0','Etc/GMT-1','	Etc/GMT-10','
		Etc/GMT-11','	Etc/GMT-12','	Etc/GMT-13','Etc/GMT-14','	Etc/GMT-2','
		Etc/GMT-3','	Etc/GMT-4','	Etc/GMT-5','Etc/GMT-6','	Etc/GMT-7','
		Etc/GMT-8','	Etc/GMT-9','	Etc/GMT0','Etc/Greenwich','	Etc/UCT','
		Etc/Universal','	Etc/UTC','	Etc/Zulu','Factory','	GB','
		GB-Eire','	GMT','	GMT+0','	GMT-0','	GMT0','
		Greenwich','	Hongkong','	HST','	Iceland','	Iran','
		Israel','	Jamaica','	Japan','	Kwajalein','	Libya','
		MET','	Mexico/BajaNorte','	Mexico/BajaSur','	Mexico/General','	MST','
		MST7MDT','	Navajo','	NZ','	NZ-CHAT','	Poland','
		Portugal','	PRC','	PST8PDT','	ROC','	ROK','
		Singapore','	Turkey','	UCT','	Universal','	US/Alaska','
		US/Aleutian','	US/Arizona','	US/Central','	US/East-Indiana','	US/Eastern','
		US/Hawaii','	US/Indiana-Starke','	US/Michigan','	US/Mountain','	US/Pacific','
		US/Pacific-New','	US/Samoa','	UTC','	W-SU','	WET','
		Zulu');
		
		return $sub_zone;

	}
}

if(!function_exists('isLoggedIn')){
	function isLoggedIn(){
		/*$obj = &get_instance();
		if($obj->session->userdata('fw')){
			return true;
		}else{
			return false;
		}*/
		$obj = &get_instance();
		if($obj->session->userdata('fw')){
			return true;
		}else{
			if($obj->input->cookie('rememberme') && $obj->input->cookie('rememberme') != ''){
				if($obj->session->userdata('fw')){
					return true;
				}else{
					$decode = decrypt($obj->input->cookie('rememberme'));
					$deArr = @explode('::', $decode);

					$obj->db->select('*')->from('users');
					$obj->db->where('status','Active')->where('userId',$deArr[0]);
					$obj->db->where('hashToken',md5($obj->input->cookie('rememberme')));
					$rec = $obj->db->get();
					if($rec->num_rows() > 0){
						$record = $rec->row();
						$obj->session->set_userdata('fw',$record);
						$hashToken = encrypt($record->userId.'::'.time());
						$obj->input->set_cookie('rememberme',$hashToken,2592000);
						$obj->db->set('hashToken',md5($hashToken))->where('userId',$record->userId)->update('users');
						return true;
					}else{
						return false;
					}
				}
			}
			return false;
		}
	}
}

if(!function_exists("encrypt")){
	function encrypt($string){
		$key	=	"s1a1j1j1a2d0r1i3zzwaamn";
		$result = '';
		for($i = 0; $i < strlen($string); $i++){
			$char = substr($string, $i, 1);
			$keychar = substr($key, ($i % strlen($key))-1, 1);
			$char = chr(ord($char)+ord($keychar));
			$result.=$char;
		}
		return str_replace(" ","",base64_encode($result));
	}
}
if(!function_exists("decrypt")){
	function decrypt($string){
		$key	=	"s1a1j1j1a2d0r1i3zzwaamn";
		$result = '';
		$string = base64_decode($string);
		for($i = 0; $i < strlen($string); $i++){
			$char = substr($string, $i, 1);
			$keychar = substr($key, ($i % strlen($key))-1, 1);
			$char = chr(ord($char)-ord($keychar));
			$result.=$char;
		}
		return $result;
	}
}

if(!function_exists('userName')){
	function userName($userId){
		$obj = &get_instance();
		$obj->db->select('name')->from('users')->where('userId',$userId);
		return $obj->db->get()->row()->name;
	}
}

if(!function_exists('userEmail')){
	function userEmail($userId){
		$obj = &get_instance();
		$obj->db->select('email')->from('users')->where('userId',$userId);
		return $obj->db->get()->row()->email;
	}
}

if(!function_exists('getUser')){
	function getUser($userId){
		$obj = &get_instance();
		$obj->db->select('*')->from('users')->where('userId',$userId);
		return $obj->db->get()->row();
	}
}

if(!function_exists('cleanNumber')){
	function cleanNumber($number){
		$number = str_replace(array(' ',')','(','_','-','+','.'), '', $number);
		if(strlen($number) == 10){
			$number = '1'.$number;
		}
		return $number;
	}
}

if(!function_exists('cleanEmail')){
	function cleanEmail($email){
		return strtolower(str_replace(array(' ',')','(',',','"','`','!','|','#','&','%','^'),'',$email));
	}
}

if(!function_exists('validEmail')){
	function validEmail($email){
		if(!filter_var($email, FILTER_VALIDATION_EMAIL)){
			return false;
		}else{
			return true;
		}
	}
}

if(!function_exists('reportTime')){
	function reportTime($time){
		return date('M d Y, h:i A',strtotime($time));
	}
}

if(!function_exists('reportDate')){
	function reportDate($time){
		return date('M d, Y',strtotime($time));
	}
}

if(!function_exists('timeAgo')){
	function timeAgo($ptime){
		$sec = 'seconds'; $mint = 'minutes'; $hr = 'hours'; $day = 'days'; $month = 'months'; $yr = 'years';

		if($ptime=='0000-00-00 00:00:00'){
			return 'x days ago';exit;
		}
		$etime = time() - strtotime($ptime);
		if ($etime < 1) { return 'just now'; } 
		$interval = array( 12 * 30 * 24 * 60 * 60 =>  $yr,
				30 * 24 * 60 * 60       =>  $month,
				24 * 60 * 60            =>  $day,
				60 * 60                 =>  $hr,
				60                      =>  $mint,
				1                       =>  $sec
			);
		
		foreach ($interval as $secs => $str) {
			$d = $etime / $secs;
			if ($d >= 1) {
				$r = round($d);
				if($str == 'seconds' || $r == '0'){
					return  'just now';
				}else{
					return $r . ' ' . $str . ' ago';
				}
			}
		}
	}
}

if(!function_exists('defaultTimeZone')){
	function defaultTimeZone(){
		$return = 'Asia/Karachi';
		return trim($return);
	}
}

if(!function_exists('emojis')){
	function emojis(){
		$array = array("&#128512","&#128513","&#128514","&#128515","&#128516","&#128517","&#128518","&#128519","&#128520","&#128521","&#128522","&#128523","&#128524","&#128525","&#128526","&#128527","&#128528","&#128529","&#128530","&#128531","&#128532","&#128533","&#128534","&#128535","&#128536","&#128537","&#128538","&#128539","&#128540","&#128541","&#128542","&#128543","&#128544","&#128545","&#128546","&#128547","&#128548","&#128549","&#128550","&#128551","&#128552","&#128553","&#128554","&#128555","&#128556","&#128557","&#128558","&#128559","&#128560","&#128561","&#128562","&#128563","&#128564","&#128565","&#128566","&#128567","&#128568","&#128569","&#128570","&#128571","&#128572","&#128573","&#128574","&#128575","&#128576","&#128577","&#128578","&#128579","&#128580","&#129296","&#129297","&#129298","&#129299","&#129300","&#129301","&#129302","&#129303","&#129304","&#129305","&#129306","&#129307","&#129308","&#129309","&#129310","&#129311","&#129312","&#129313","&#129314","&#129315","&#129316","&#129317","&#129318","&#129319","&#129320","&#129321","&#129322","&#129323","&#129324","&#129325","&#129326","&#129327","&#129488");
		return $array;
	}
}

if(!function_exists('getTags')){
	function getTags($tagId = 0){
		$obj = &get_instance();
		$obj->db->select('tag')->from('tags')->order_by('tag','asc');
		if($tagId != 0){
			$obj->db->where('tagId',$tagId);
		}
		$return = array();
		foreach($obj->db->get()->result() as $rec){
			$return[] = $rec->tag;
		}
		return $return;
	}
}

if(!function_exists('setTag')){
	function setTag($tag){
		$obj = &get_instance();
		$obj->db->select('tagId')->from('tags')->where('tag',$tag);
		$record = $obj->db->get();
		if($record->num_rows() == 0){
			$dataArr = array('tag' => $tag, 'createdTime' => date('Y-m-d H:i:s'));
			$obj->db->set($dataArr)->insert('tags');
		}
	}
}

if(!function_exists('getCategoreis')){
	function getCategoreis($catId = 0){
		$obj = &get_instance();
		$obj->db->select('category')->from('categoreis')->order_by('category','asc');
		if($catId != 0){
			$obj->db->where('catId',$catId);
		}
		$return = array();
		foreach($obj->db->get()->result() as $rec){
			$return[] = $rec->category;
		}
		return $return;
	}
}

if(!function_exists('getCategoreisWithSlug')){
	function getCategoreisWithSlug(){
		$obj = &get_instance();
		$obj->db->select('category,catSlug')->from('categoreis')->order_by('category','asc');
		$record = $obj->db->get();
		return $record->result();
	}
}

if(!function_exists('getCategory')){
	function getCategory($category){
		$obj = &get_instance();
		$obj->db->select('*')->from('categoreis');
		$obj->db->where('catSlug',$category)->or_where('category',$category);
		$record = $obj->db->get();
		if($record->num_rows() > 0){
			$return = $record->row();
		}else{
			$return = '0';
		}
		return $return;
	}
}

if(!function_exists('setCategory')){
	function setCategory($category){
		$obj = &get_instance();
		$obj->db->select('catId')->from('categoreis')->where('category',$category);
		$record = $obj->db->get();
		if($record->num_rows() == 0){
			$dataArr = array('category' => $category, 'catSlug' => url_title($category, 'dash', true), 'createdTime' => date('Y-m-d H:i:s'));
			$obj->db->set($dataArr)->insert('categoreis');
		}
	}
}

if(!function_exists('getActivePages')){
	function getActivePages($position = 'all'){
		$obj = &get_instance();
		$obj->db->select('*')->from('cms')->where('status','Active')->where('pageType','1');
		if($position != 'all'){
			$obj->db->where('position',$position);
		}
		$record = $obj->db->get();
		return $record->result();
	}
}
if(!function_exists('getPage')){
	function getPage($pageId){
		$obj = &get_instance();
		$obj->db->select('*')->from('cms')->where('pageId',$pageId);
		$record = $obj->db->get();
		return $record->row();
	}
}

if(!function_exists('getPageByArea')){
	function getPageByArea($page_area){
		$obj = &get_instance();
		$obj->db->select('*')->from('cms')->where('page_area',$page_area);
		$record = $obj->db->get();
		return $record->row();
	}
}

if(!function_exists('getPageBySlug')){
	function getPageBySlug($slugUrl){
		$obj = &get_instance();
		$obj->db->select('*')->from('cms')->where('slugUrl',$slugUrl)->where('status','Active')->where('pageType','1');
		$record = $obj->db->get();
		return $record->row();
	}
}

if(!function_exists('getPostBySlug')){
	function getPostBySlug($postSlug){
		$obj = &get_instance();
		$obj->db->select('*')->from('posts')->where('postSlug',$postSlug)->where('postStatus','Active');
		$record = $obj->db->get();
		return $record->row();
	}
}

if(!function_exists('getPost')){
	function getPost($postId){
		$obj = &get_instance();
		$obj->db->select('*')->from('posts')->where('postId',$postId);
		$record = $obj->db->get();
		return $record->row();
	}
}

if(!function_exists('setSiteMeta')){
	function setSiteMeta($metaType,$metaValue){
		$obj = &get_instance();
		$obj->db->select('metaId')->from('site_meta')->where('metaType',$metaType);
		$record = $obj->db->get();
		if($record->num_rows() == 0){
			$obj->db->set('metaType',$metaType)->set('metaValue',@json_encode($metaValue))->set('updatedTime',date('Y-m-d H:i:s'));
			$obj->db->insert('site_meta');
		}else{
			$obj->db->set('metaValue',@json_encode($metaValue))->where('metaType',$metaType)->update('site_meta');
		}
	}
}

if(!function_exists('getSiteMeta')){
	function getSiteMeta($metaType = ''){
		$obj = &get_instance();
		$obj->db->select('metaType,metaValue')->from('site_meta');
		if($metaType != ''){
			$obj->db->where('metaType',$metaType);
			$record = $obj->db->get()->row();
			$return = @json_decode($record->metaValue,true);
		}else{
			$record = $obj->db->get();
			$return = array();
			foreach($record->result() as $rec){
				$return[$rec->metaType] = @json_decode($rec->metaValue,true);
			}
		}
		return $return;
	}
}

if(!function_exists('recentPosts')){
	function recentPosts($limit = '10', $postId = ''){
		$obj = &get_instance();
		$obj->db->select('*')->from('posts');
		if($postId != ''){
			$obj->db->where('postId <> ', $postId);
		}
		$obj->db->order_by('modifiedTime','desc');
		$obj->db->limit($limit);
		$record = $obj->db->get()->result();
		return $record;
	}
}

if(!function_exists('getPostComments')){
	function getPostComments($postId){
		$obj = &get_instance();
		$obj->db->select('*')->from('post_comments')->where('status','Approved');
		$obj->db->where('postId', $postId)->order_by('commentTime','asc');
		$obj->db->limit($limit);
		$record = $obj->db->get()->result();
		return $record;
	}
}

if(!function_exists('setVisitor')){
	function setVisitor($ipAddress = '', $postId = 0){
		$obj = &get_instance();
		$dateTime = date('Y-m-d H:i:s',strtotime('-30 Minutes'));
		//$obj->db->select('viewId')->from('post_view')->where('postId',$postId)->where('ipAddress',$ipAddress)->like('viewTime',date('Y-m-d'));
		$obj->db->select('viewId')->from('post_view')->where('postId',$postId)->where('ipAddress',$ipAddress)->where('viewTime >= ',$dateTime);
		$record = $obj->db->get();
		if($record->num_rows() == 0){
			$obj->db->set('postId',$postId)->set('ipAddress',$ipAddress)->set('viewTime',date('Y-m-d H:i:s'))->insert('post_view');
			if($postId != 0){
				$obj->db->set('viewsCount','viewsCount + 1',false)->where('postId',$postId)->update('posts');
			}
		}
	}
}

if(!function_exists('getvisitorLike')){
	function getvisitorLike($postId, $ipAddress){
		$obj = &get_instance();
		$obj->db->select('type')->from('post_likes')->where('ipAddress',$ipAddress)->where('postId',$postId);
		$record = $obj->db->get();
		return $record->row()->type;
	}
}

if(!function_exists('getContactUSHeader')){
	function getContactUSHeader(){
		$obj = &get_instance();
		$obj->db->select('*')->from('contact_us')->order_by('contactUsId','desc')->limit(20);
		$record = $obj->db->get();

		$return = array('ecount' => '0', 'record' => array());
		foreach($record->result() as $rec){
			$return['ecount'] = $return['ecount'] + ($rec->status == '0' ? 1 : 0);
			$return['record'][] = $rec;
		}

		return $return;
	}
}

if(!function_exists('recentModels')){
	function recentModels($limit = 5){
		$obj = &get_instance();
		$obj->db->select('*')->from('posts')->where('model <> ', '')->where('isRecentModel','Yes');
		$obj->db->group_by('model')->order_by('modifiedTime','desc')->limit($limit);
		$record = $obj->db->get()->result();

		return $record;
	}
}

if(!function_exists('worldCountries')){
	function worldCountries(){
		$obj = &get_instance();
		if($obj->session->userdata('countryList')){
			return $obj->session->userdata('countryList');
		}else{
			$obj->db->select('iso2,iso3,country,call_countrycode')->from('world_country');
			$obj->db->order_by('country','asc');
			$record = $obj->db->get()->result();

			$return = array();
			foreach($record as $rec){
				$return[$rec->iso3] = array('code' => $rec->iso2, 'name' => $rec->country, 'callingCode' => $rec->call_countrycode);
			}

			$obj->session->set_userdata('countryList',$return);
			return $return;
		}
	}
}

if(!function_exists('extractCountry')){
	function extractCountry($str){
		/*$start  = strpos($str, '{');
		$end    = strpos($str, '}', $start + 1);
		$length = $end - $start;
		return substr($str, $start + 1, $length - 1);*/

		preg_match_all('/\{([^}]+)\}/', $str, $matches);

		return $matches;
	}
}

if(!function_exists('postUrl')){
	function postUrl($post){
		$obj = &get_instance();
		
		$post_link = base_url('firmware/'.$post->model.'/'.$post->country.'/'.$post->version);

		return $post_link;
	}
}

if(!function_exists('innerTableContent')){
	function innerTableContent(){
		$vhtml = '<table id="customers"><tr><th>Device</th><td>{post-device}</td><th>Model</th><td>{post-model}</td></tr><tr><th>Product</th><td>{post-product}</td><th>File Name</th><td>{post-filename}</td></tr><tr><th>AP Version</th><td>{post-apversion}</td><th>OS</th><td>{post-os}</td></tr><tr><th>CSC Version</th><td>{post-cscversion}</td><th>CSC</th><td>{post-csc}</td></tr><tr><th>Binary (BIT/U)</th><td>{post-bit}</td><th>Upload Date</th><td>{post-uploaddate}</td></tr></table>';

		return $vhtml;
	}
}
?>
