
<!DOCTYPE html>
<html>
<head>
	<title>Audio Player</title>
	<link rel="stylesheet" type="text/css" href="360player.css" />

	<!-- Apache-licensed animation library -->
	<script type="text/javascript" src="script/berniecode-animator.js"></script>

	<!-- the core stuff -->
	<script type="text/javascript" src="soundmanager2.js"></script>
	<script type="text/javascript" src="script/360player.js"></script>
</head>
<body>
<div class="ui360" style="margin-top:-0.55em"><a href="_mp3/rain.mp3">Rain</a></div>
</body>
</html>
<script type="text/javascript">
soundManager.setup({
  // path to directory containing SM2 SWF
  url: 'swf/'
});
</script>